SELECT count(*) FROM singer;	concert_singer
SELECT count(*) FROM singer;	concert_singer
SELECT Name, Country, Age FROM singer ORDER BY Age DESC;	concert_singer
SELECT Name, Country, Age FROM singer ORDER BY Age DESC;	concert_singer
SELECT avg(Age), min(Age), max(Age) FROM singer WHERE Country = 'France';	concert_singer
SELECT avg(Age), min(Age), max(Age) FROM singer WHERE Country = 'France';	concert_singer
SELECT Song_Name, Song_release_year FROM singer WHERE Age = ( SELECT min(Age) FROM singer);	concert_singer
SELECT Song_Name, Song_release_year FROM singer WHERE Age = ( SELECT min(Age) FROM singer );	concert_singer
SELECT DISTINCT Country FROM singer WHERE Age > 20;	concert_singer
SELECT DISTINCT Country FROM singer WHERE Age > 20;	concert_singer
SELECT Country, COUNT(*) FROM singer GROUP BY Country;	concert_singer
SELECT Country, COUNT(*) FROM singer GROUP BY Country;	concert_singer
SELECT Song_Name FROM singer WHERE Age > ( SELECT AVG(Age) FROM singer);	concert_singer
SELECT Song_Name FROM singer WHERE Age > ( SELECT AVG(Age) FROM singer);	concert_singer
SELECT LOCATION, NAME FROM stadium WHERE capacity BETWEEN 5000 AND 10000;	concert_singer
SELECT LOCATION, NAME FROM stadium WHERE capacity BETWEEN 5000 AND 10000;	concert_singer
SELECT max(capacity), average FROM stadium;	concert_singer
SELECT AVG(capacity), max(capacity) FROM stadium;	concert_singer
SELECT Name, Capacity FROM stadium ORDER BY Average DESC LIMIT 1;	concert_singer
SELECT Name, Capacity FROM stadium ORDER BY Average DESC LIMIT 1;	concert_singer
SELECT count(*) FROM concert WHERE YEAR = 2014 OR YEAR = 2015;	concert_singer
SELECT count(*) FROM concert WHERE YEAR = 2014 OR YEAR = 2015;	concert_singer
SELECT T1.Name, COUNT(*) FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID GROUP BY T1.Name;	concert_singer
SELECT count(*), Stadium_ID FROM CONCERT GROUP BY Stadium_ID ;	concert_singer
SELECT T2.Name, T2.Capacity FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T1.Year >= 2014 GROUP BY T1.Stadium_ID ORDER BY count(*) DESC LIMIT 1;	concert_singer
SELECT T2.Name, T2.Capacity FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T1.Year > 2013 GROUP BY T1.Stadium_ID ORDER BY count(*) DESC LIMIT 1;	concert_singer
SELECT YEAR FROM concert GROUP BY YEAR ORDER BY count(*) DESC LIMIT 1;	concert_singer
SELECT YEAR FROM concert ORDER BY YEAR DESC LIMIT 1;	concert_singer
SELECT Name FROM stadium WHERE Stadium_ID NOT IN ( SELECT Stadium_ID FROM concert );	concert_singer
SELECT Name FROM stadium WHERE Stadium_ID NOT IN ( SELECT Stadium_ID FROM concert );	concert_singer
SELECT Country FROM singer WHERE Age > 40 UNION SELECT Country WHERE Age < 30;	concert_singer
SELECT Name FROM stadium EXCEPT SELECT T1.Name FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.Year = 2014;	concert_singer
SELECT Name FROM stadium WHERE Stadium_ID NOT IN ( SELECT Stadium_ID FROM concert WHERE YEAR = 2014 );	concert_singer
SELECT T1.concert_Name, T1.Theme, COUNT(*) FROM concert AS T1 JOIN singer_in_concert AS T2 ON T1.concert_ID = T2.concert_ID GROUP BY T1.concert_ID;	concert_singer
SELECT T1.concert_Name, T1.Theme, COUNT(*) FROM concert AS T1 JOIN singer_in_concert AS T2 ON T1.concert_ID = T2.concert_ID GROUP BY T1.concert_ID;	concert_singer
SELECT T2.Name, COUNT(*) FROM singer_in_concert AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Singer_ID;	concert_singer
SELECT T1.Name, COUNT(*) FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T2.Singer_ID;	concert_singer
SELECT T3.Name FROM concert AS T1 JOIN singer_in_concert AS T2 ON T1.concert_ID = T2.concert_ID JOIN singer AS T3 ON T2.Singer_ID = T3.Singer_ID WHERE T1.Year = 2014;	concert_singer
SELECT T1.Name FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID JOIN concert AS T3 ON T2.concert_ID = T3.concert_ID WHERE T3.Year = 2014;	concert_singer
SELECT Name, Country FROM singer WHERE Song_Name LIKE '%Hey%';	concert_singer
SELECT Name, Country FROM singer WHERE Song_Name LIKE '%Hey%';	concert_singer
SELECT T1.name, T1.location FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year = 2014 INTERSECT SELECT T1.name, T1.location FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year = 2015;	concert_singer
SELECT T1.Name, T1.Location FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID GROUP BY T2.Stadium_ID HAVING count(*) = 2;	concert_singer
SELECT count(*) FROM concert AS T1 JOIN stadium AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.capacity = ( SELECT max(capacity) FROM stadium);	concert_singer
SELECT count(*) FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.Capacity = ( SELECT max(Capacity) FROM stadium);	concert_singer
SELECT count(*) FROM PETS WHERE weight > 10;	pets_1
SELECT count(*) FROM PETS WHERE weight > 10;	pets_1
SELECT weight FROM pets WHERE pet_age = ( SELECT min(pet_age) FROM pets WHERE pettype = "dog" );	pets_1
SELECT weight FROM pets WHERE pet_age = ( SELECT min(pet_age) FROM pets WHERE pettype = "dog" );	pets_1
SELECT max(weight), pettype FROM PETS GROUP BY pettype;	pets_1
SELECT max(weight), pettype FROM PETS GROUP BY pettype;	pets_1
SELECT count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID WHERE T1.age > 20;	pets_1
SELECT count(*) FROM Student AS T1 JOIN has_pet AS T2 ON T1.StuID = T2.StuID WHERE T1.age > 20;	pets_1
SELECT count(*) FROM Student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T1.sex = "F" AND T3.pettype = "dog";	pets_1
SELECT count(*) FROM Student AS T1 JOIN has_pet AS T2 ON T1.StuID = T2.StuID JOIN pets AS T3 ON T2.PetID = T3.PetID WHERE T1.sex = "F" AND T3.pettype = "dog";	pets_1
SELECT count(DISTINCT pettype) FROM pets;	pets_1
SELECT count(DISTINCT pettype) FROM pets;	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat" OR T3.pettype = "dog";	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat" OR T3.pettype = "dog";	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat" INTERSECT SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "dog";	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat" INTERSECT SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "dog";	pets_1
SELECT major, age FROM student EXCEPT SELECT T1.major, T1.age FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat";	pets_1
SELECT T1.major, T1.age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.stuid = T2.stuid JOIN Pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype!= 'cat';	pets_1
SELECT StuID FROM Has_Pet EXCEPT SELECT StuID FROM Pets WHERE pettype = "cat";	pets_1
SELECT StuID FROM Has_Pet EXCEPT SELECT StuID FROM Pets WHERE PetType = "cat";	pets_1
SELECT T1.fname, T1.age FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "dog" EXCEPT SELECT T1.fname, T1.age FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat";	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "dog" EXCEPT SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat";	pets_1
SELECT pettype, weight FROM PETS ORDER BY pet_age LIMIT 1;	pets_1
SELECT pettype, weight FROM PETS WHERE pet_age = ( SELECT min(pet_age) FROM PETS );	pets_1
SELECT petid, weight FROM PETS WHERE pet_age > 1;	pets_1
SELECT petid, weight FROM PETS WHERE pet_age > 1;	pets_1
SELECT avg(pet_age), max(pet_age), pettype FROM PETS GROUP BY pettype;	pets_1
SELECT avg(pet_age), max(pet_age), pettype FROM PETS GROUP BY pettype;	pets_1
SELECT pet_age, avg(weight) FROM PETS GROUP BY pet_age;	pets_1
SELECT pet_age, avg(weight) FROM PETS GROUP BY pet_age;	pets_1
SELECT T1.fname, T1.age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID;	pets_1
SELECT DISTINCT T1.fname, T1.age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID;	pets_1
SELECT T2.petid FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid WHERE T1.lname = 'Smith';	pets_1
SELECT T2.petid FROM Student AS T1 JOIN Has_pet AS T2 ON T1.stuid = T2.stuid WHERE T1.lname = 'Smith';	pets_1
SELECT count(*), StuID FROM Has_Pet GROUP BY StuID;	pets_1
SELECT count(*), StuID FROM Has_Pet GROUP BY StuID;	pets_1
SELECT T1.fname, T1.sex FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.stuid = T2.stuid GROUP BY T1.stuid HAVING count(*) > 1;	pets_1
SELECT T1.fname, T1.sex FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.stuid = T2.stuid GROUP BY T1.stuid HAVING count(*) > 1;	pets_1
SELECT T1.lname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat" AND T3.pet_age = 3;	pets_1
SELECT T1.lname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = "cat" AND T3.pet_age = 3;	pets_1
SELECT avg(T1.age) FROM student AS T1 LEFT JOIN has_pet AS T2 ON T1.stuid = T2.stuid WHERE T2.petid IS NULL;	pets_1
SELECT avg(T1.age) FROM student AS T1 LEFT JOIN has_pet AS T2 ON T1.stuid = T2.stuid WHERE T2.petid IS NULL;	pets_1
SELECT count(*) FROM continents;	car_1
SELECT count(*) FROM continents;	car_1
SELECT contid, continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.contid = T2.continent GROUP BY contid;	car_1
SELECT contid, continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.contid = T2.continent GROUP BY contid;	car_1
SELECT count(*) FROM countries;	car_1
SELECT count(*) FROM countries;	car_1
SELECT T1.FullName, T1.Id, count(*) FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.Id;	car_1
SELECT id, fullname, count(*) FROM car_makers GROUP BY id;	car_1
SELECT T1.model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.ModelId = T2.Id ORDER BY T2.horsepower LIMIT 1;	car_1
SELECT model FROM cars_data ORDER BY horsepower LIMIT 1;	car_1
SELECT model FROM cars_data WHERE weight < ( SELECT avg(weight) FROM cars_data );	car_1
SELECT model FROM cars_data WHERE weight < ( SELECT avg(weight) FROM cars_data );	car_1
SELECT T1.make FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.year = 1970;	car_1
SELECT DISTINCT T1.make FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.year = 1970;	car_1
SELECT T1.make, T2.year FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.year = ( SELECT MIN(year) FROM cars_data );	car_1
SELECT T2.make, T1.year FROM cars_data AS T1 JOIN car_names AS T2 ON T1.id = T2.makeid WHERE T1.year = ( SELECT MIN(year) FROM cars_data);	car_1
SELECT DISTINCT T1.model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.modelid = T2.id WHERE T2.year > 1980;	car_1
SELECT DISTINCT T1.model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.modelid = T2.id WHERE T2.year > 1980;	car_1
SELECT T1.continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.ContId = T2.Continent GROUP BY T1.continent;	car_1
SELECT T2.continent, count(*) FROM countries AS T1 JOIN continents AS T2 ON T1.continent = T2.contid JOIN car_makers AS T3 ON T1.countryid = T3.country GROUP BY T2.continent;	car_1
SELECT T1.countryname FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T1.countryname ORDER BY count(*) DESC LIMIT 1;	car_1
SELECT T1.countryname FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T1.countryname ORDER BY count(*) DESC LIMIT 1;	car_1
SELECT count(*), T1.fullname FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.maker GROUP BY T1.fullname;	car_1
SELECT count(*), T1.id, T1.FullName FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.Maker GROUP BY T1.id;	car_1
SELECT T1.accelerate FROM cars_data AS T1 JOIN car_names AS T2 ON T1.id = T2.makeid WHERE T2.make = 'amc' AND T2.model = 'amc hornet sportabout (sw)';	car_1
SELECT T2.accelerate FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T1.make = 'amc hornet sportabout (sw)';	car_1
SELECT count(*) FROM car_makers AS T1 JOIN countries AS T2 ON T1.country = T2.countryid WHERE T2.countryname = "france";	car_1
SELECT count(*) FROM car_makers AS T1 JOIN countries AS T2 ON T1.country = T2.countryid WHERE T2.countryname = "france";	car_1
SELECT count(*) FROM car_makers AS T1 JOIN countries AS T2 ON T1.country = T2.countryid WHERE T2.countryname = 'usa';	car_1
SELECT count(*) FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.maker WHERE T1.country = "usa";	car_1
SELECT avg(mpg) FROM cars_data WHERE cylinders = 4;	car_1
SELECT avg(MPG) FROM cars_data WHERE cylinders = 4;	car_1
SELECT min(weight) FROM cars_data WHERE YEAR = 1974 AND cylinders = 8;	car_1
SELECT min(T1.weight) FROM cars_data AS T1 JOIN car_names AS T2 ON T1.id = T2.makeid WHERE T1.year = 1974 AND T1.cylinders = 8;	car_1
SELECT T1.make, T2.Model FROM car_names AS T1 JOIN model_list AS T2 ON T1.MakeId = T2.ModelId;	car_1
SELECT T1.make, T2.Model FROM car_names AS T1 JOIN model_list AS T2 ON T1.MakeId = T2.ModelId;	car_1
SELECT T1.countryname, T1.countryid FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T1.countryid HAVING count(*) >= 1;	car_1
SELECT T1.countryname, T1.countryid FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T1.countryid HAVING count(*) >= 1;	car_1
SELECT count(*) FROM cars_data WHERE horsepower > 150;	car_1
SELECT count(*) FROM cars_data WHERE horsepower > 150;	car_1
SELECT YEAR, avg(weight) FROM cars_data GROUP BY YEAR;	car_1
SELECT avg(weight), YEAR FROM cars_data GROUP BY YEAR ;	car_1
SELECT T1.countryname FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T2.country HAVING count(*) >= 3;	car_1
SELECT T1.countryname FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T2.country HAVING count(*) >= 3;	car_1
SELECT max(T1.horsepower), T2.make FROM cars_data AS T1 JOIN car_names AS T2 ON T1.id = T2.makeid WHERE T1.cylinders = 3;	car_1
SELECT max(T1.horsepower), T2.make FROM cars_data AS T1 JOIN car_names AS T2 ON T1.id = T2.makeid WHERE T1.cylinders = 3;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.MPG DESC LIMIT 1;	car_1
SELECT T1.model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.modelid = T2.id ORDER BY T2.MPG DESC LIMIT 1;	car_1
SELECT avg(horsepower) FROM cars_data WHERE YEAR < 1980;	car_1
SELECT avg(horsepower) FROM cars_data WHERE YEAR < 1980;	car_1
SELECT avg(T1.edispl) FROM cars_data AS T1 JOIN car_names AS T2 ON T1.id = T2.makeid WHERE T2.model = 'volvo';	car_1
SELECT avg(T1.Edispl) FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T2.Make = 'volvo';	car_1
SELECT max(accelerate), cylinders FROM cars_data GROUP BY cylinders ;	car_1
SELECT max(accelerate), cylinders FROM cars_data GROUP BY cylinders ;	car_1
SELECT model FROM car_names GROUP BY model ORDER BY count(*) DESC LIMIT 1;	car_1
SELECT model FROM car_names GROUP BY model ORDER BY count(*) DESC LIMIT 1;	car_1
SELECT count(*) FROM cars_data WHERE cylinders > 4;	car_1
SELECT count(*) FROM cars_data WHERE cylinders > 4;	car_1
SELECT count(*) FROM cars_data WHERE YEAR = 1980;	car_1
SELECT count(*) FROM cars_data WHERE YEAR = 1980;	car_1
SELECT count(*) FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.maker WHERE T1.fullname = 'American Motor Company';	car_1
SELECT count(*) FROM car_names AS T1 JOIN model_list AS T2 ON T1.makeid = T2.modelid JOIN car_makers AS T3 ON T2.Maker = T3.id WHERE T3.Maker = 'American Motor Company';	car_1
SELECT T1.FullName, T1.Id FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.Id HAVING count(*) > 3;	car_1
SELECT T1.makeid, T1.make FROM car_names AS T1 JOIN model_list AS T2 ON T1.makeid = T2.modelid GROUP BY T1.makeid HAVING count(*) > 3;	car_1
SELECT T1.Model FROM model_list AS T1 JOIN car_names AS T2 ON T1.ModelId = T2.MakeId JOIN cars_data AS T3 ON T2.MakeId = T3.Id WHERE T1.FullName = 'General Motors' OR T3.Weight > 3500;	car_1
SELECT T1.Model FROM model_list AS T1 JOIN car_names AS T2 ON T1.ModelId = T2.MakeId JOIN cars_data AS T3 ON T2.MakeId = T3.Id WHERE T2.Make = 'general motors' OR T3.weight > 3500;	car_1
SELECT YEAR FROM cars_data WHERE WEIGHT BETWEEN 3000 AND 4000;	car_1
SELECT YEAR FROM cars_data WHERE weight < 4000 UNION SELECT YEAR FROM cars_data WHERE weight > 3000;	car_1
SELECT horsepower FROM cars_data ORDER BY accelerate DESC LIMIT 1;	car_1
SELECT horsepower FROM cars_data WHERE accelerate = ( SELECT max(accelerate) FROM cars_data );	car_1
SELECT T2.cylinders FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T1.model = 'volvo' ORDER BY T2.accelerate LIMIT 1;	car_1
SELECT T2.cylinders FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T1.make = 'volvo' ORDER BY T2.accelerate LIMIT 1;	car_1
SELECT count(*) FROM cars_data WHERE accelerate > ( SELECT max(horsepower) FROM cars_data);	car_1
SELECT count(*) FROM cars_data WHERE accelerate > ( SELECT max(horsepower) FROM cars_data );	car_1
SELECT count(*) FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T1.countryid HAVING count(*) > 2;	car_1
SELECT count(*) FROM ( SELECT T1.country FROM car_makers AS T1 JOIN countries AS T2 ON T1.country = T2.countryId GROUP BY T1.country HAVING count(*) > 2 );	car_1
SELECT count(*) FROM cars_data WHERE cylinders > 6;	car_1
SELECT count(*) FROM cars_data WHERE cylinders > 6;	car_1
SELECT T2.model FROM cars_data AS T1 JOIN model_list AS T2 ON T1.id = T2.modelid WHERE T1.cylinders = 4 ORDER BY T1.horsepower LIMIT 1;	car_1
SELECT T2.model FROM cars_data AS T1 JOIN model_list AS T2 ON T1.id = T2.modelid WHERE T1.cylinders = 4 ORDER BY T1.horsepower LIMIT 1;	car_1
SELECT T1.makeid, T2.make FROM cars_data AS T1 JOIN car_names AS T2 ON T1.id = T2.makeid WHERE T1.horsepower > ( SELECT min(horsepower) FROM cars_data ) AND T1.cylinders < 3;	car_1
SELECT T1.makeid, T1.make FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.cylinders < 4 AND T2.horsepower > ( SELECT min(horsepower) FROM cars_data ) GROUP BY T1.makeid;	car_1
SELECT max(MPG) FROM cars_data WHERE cylinders = 8 OR YEAR < 1980;	car_1
SELECT max(MPG) FROM cars_data WHERE cylinders = 8 OR YEAR < 1980;	car_1
SELECT T2.model FROM car_names AS T1 JOIN model_list AS T2 ON T1.makeid = T2.modelid JOIN cars_data AS T3 ON T1.makeid = T3.id WHERE T3.weight < 3500 EXCEPT SELECT T2.model FROM car_names AS T1 JOIN model_list AS T2 ON T1.makeid = T2.modelid JOIN cars_data AS T3 ON T1.makeid = T3.id WHERE T1.make = 'Ford Motor Company';	car_1
SELECT T1.model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.modelid = T2.id WHERE T2.weight < 3500 EXCEPT SELECT T1.model FROM model_list AS T1 JOIN car_names AS T2 ON T1.makeid = T2.makeid WHERE T2.make = "ford";	car_1
SELECT country FROM countries WHERE countryid NOT IN ( SELECT country FROM car_makers );	car_1
SELECT countryname FROM countries WHERE countryid NOT IN ( SELECT country FROM car_makers );	car_1
SELECT id, make FROM car_names GROUP BY make HAVING count(*) >= 2 AND count(*) > 3;	car_1
SELECT id, maker FROM car_makers WHERE id IN ( SELECT maker FROM model_list GROUP BY maker HAVING count(*) >= 2 ) AND id IN ( SELECT MakeId FROM cars_data );	car_1
SELECT country FROM car_makers GROUP BY country HAVING count(*) > 3 UNION SELECT T1.country FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.Maker WHERE T2.model = 'fiat';	car_1
SELECT T1.countryid, T1.countryname FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country GROUP BY T1.countryid HAVING count(*) > 3 UNION SELECT T1.countryid, T1.countryname FROM countries AS T1 JOIN car_names AS T2 ON T1.countryid = T2.make WHERE T2.make = 'fiat';	car_1
SELECT Country FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Country FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Abbreviation FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Abbreviation FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Airline, Abbreviation FROM airlines WHERE Country = 'USA';	flight_2
SELECT Airline, Abbreviation FROM airlines WHERE Country = 'USA';	flight_2
SELECT AirportCode, AirportName FROM airports WHERE City = 'Anthony';	flight_2
SELECT AirportCode, AirportName FROM airports WHERE City = 'Anthony';	flight_2
SELECT count(*) FROM airlines;	flight_2
SELECT count(*) FROM airlines;	flight_2
SELECT count(*) FROM airports;	flight_2
SELECT count(*) FROM airports;	flight_2
SELECT count(*) FROM flights;	flight_2
SELECT count(*) FROM flights;	flight_2
SELECT Airline FROM airlines WHERE Abbreviation = 'UAL';	flight_2
SELECT Airline FROM airlines WHERE Abbreviation = 'UAL';	flight_2
SELECT COUNT(*) FROM airlines WHERE Country = 'USA';	flight_2
SELECT count(*) FROM airlines WHERE Country = 'USA';	flight_2
SELECT City, Country FROM airports WHERE AirportName = 'Alton';	flight_2
SELECT City, Country FROM airports WHERE AirportName = 'Alton';	flight_2
SELECT AirportName FROM airports WHERE AirportCode = 'AKO';	flight_2
SELECT AirportName FROM airports WHERE AirportCode = 'AKO';	flight_2
SELECT AirportName FROM airports WHERE City = 'Aberdeen';	flight_2
SELECT AirportName FROM airports WHERE City = 'Aberdeen';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT count(*) FROM flights WHERE DestAirport = 'ATO';	flight_2
SELECT count(*) FROM flights WHERE DestAirport = 'ATO';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport JOIN airports AS T3 ON T3.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen' AND T3.City = 'Ashley';	flight_2
SELECT COUNT(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport JOIN airports AS T3 ON T3.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen'AND T3.City = 'Ashley';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airlines AS T2 ON T1.airline = T2.uid WHERE T2.airline = 'JetBlue Airways';	flight_2
SELECT count(*) FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T1.Airline = 'JetBlue Airways';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode JOIN airlines AS T3 ON T1.Airline = T3.uid WHERE T3.Airline = 'United Airlines' AND T2.AirportName = 'ASY';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode JOIN airlines AS T3 ON T1.Airline = T3.uid WHERE T3.Airline = 'United Airlines' AND T2.AirportCode = 'ASY';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode JOIN airlines AS T3 ON T1.Airline = T3.uid WHERE T3.Airline = 'United Airlines' AND T2.AirportName = 'AHD';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode JOIN airlines AS T3 ON T1.Airline = T3.uid WHERE T3.Airline = 'United Airlines' AND T2.AirportName = 'AHD Airport';	flight_2
SELECT COUNT(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode JOIN airlines AS T3 ON T1.Airline = T3.uid WHERE T3.Airline = 'United Airlines' AND T2.City = 'Aberdeen ';	flight_2
SELECT COUNT(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode JOIN airlines AS T3 ON T1.Airline = T3.uid WHERE T3.Airline = 'United Airlines' AND T2.City = 'Aberdeen ';	flight_2
SELECT T2.city FROM flights AS T1 JOIN airports AS T2 ON T1.destairport = T2.airportcode GROUP BY T2.city ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.city FROM flights AS T1 JOIN airports AS T2 ON T1.destairport = T2.airportcode GROUP BY T2.city ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.city FROM flights AS T1 JOIN airports AS T2 ON T1.sourceairport = T2.airportcode GROUP BY T2.city ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.City FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode GROUP BY T2.City ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T1.airportcode FROM airports AS T1 JOIN flights AS T2 ON T1.airportcode = T2.sourceairport GROUP BY T1.airportcode ORDER BY count(*) LIMIT 1;	flight_2
SELECT T1.airportcode FROM airports AS T1 JOIN flights AS T2 ON T1.airportcode = T2.sourceairport GROUP BY T1.airportcode ORDER BY count(*) LIMIT 1;	flight_2
SELECT T1.airportcode FROM airports AS T1 JOIN flights AS T2 ON T1.airportcode = T2.sourceairport GROUP BY T1.airportcode ORDER BY count(*) LIMIT 1;	flight_2
SELECT T1.airportcode FROM airports AS T1 JOIN flights AS T2 ON T1.airportcode = T2.sourceairport GROUP BY T1.airportcode ORDER BY count(*) LIMIT 1;	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Airline ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Airline ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T1.Abbreviation, T1.Country FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.uid ORDER BY count(*) LIMIT 1;	flight_2
SELECT T1.Abbreviation, T1.Country FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.uid ORDER BY count(*) LIMIT 1;	flight_2
SELECT T2.Airline FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.AirportCode = 'AHD';	flight_2
SELECT T2.Airline FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.AirportCode = 'AHD';	flight_2
SELECT T2.Airline FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.AirportCode = 'AHD';	flight_2
SELECT T2.Airline FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.AirportCode = 'AHD';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'APG' INTERSECT SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'CVO';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'APG' INTERSECT SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'CVO';	flight_2
SELECT T1.airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.airline WHERE T2.SourceAirport = 'CVO' INTERSECT SELECT T1.airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.airline WHERE T2.SourceAirport = 'APG';	flight_2
SELECT T2.Airline FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.AirportCode = 'CVO' INTERSECT SELECT T2.Airline FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.AirportCode = 'APG';	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T1.Airline HAVING count(*) >= 10;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline HAVING count(*) >= 10;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline HAVING count(*) < 200;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline HAVING count(*) < 200;	flight_2
SELECT T2.FlightNo FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T1.Airline = 'United Airlines';	flight_2
SELECT T2.FlightNo FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T1.Airline = 'United Airlines';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE DestAirport = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE DestAirport = 'APG';	flight_2
SELECT T2.FlightNo FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen ';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT T2.FlightNo FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen ';	flight_2
SELECT FlightNo FROM flights WHERE DestAirport = 'APG';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City IN ('Aberdeen ', 'Abilene ');	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City IN ('Aberdeen ', 'Abilene ');	flight_2
SELECT airportname FROM airports WHERE airportcode NOT IN ( SELECT sourceairport FROM flights ) UNION SELECT airportname FROM airports WHERE airportcode NOT IN ( SELECT destairport FROM flights );	flight_2
SELECT AirportName FROM airports WHERE AirportCode NOT IN ( SELECT DISTINCT SourceAirport FROM flights UNION SELECT DISTINCT DestAirport FROM flights );	flight_2
SELECT count(*) FROM employee;	employee_hire_evaluation
SELECT count(*) FROM employee;	employee_hire_evaluation
SELECT name FROM employee ORDER BY age;	employee_hire_evaluation
SELECT name FROM employee ORDER BY age;	employee_hire_evaluation
SELECT count(*), city FROM employee GROUP BY city;	employee_hire_evaluation
SELECT count(*), city FROM employee GROUP BY city;	employee_hire_evaluation
SELECT city FROM employee WHERE age < 30 GROUP BY city HAVING count(*) > 1;	employee_hire_evaluation
SELECT city FROM employee WHERE age < 30 GROUP BY city HAVING count(*) > 1;	employee_hire_evaluation
SELECT count(*), LOCATION FROM shop GROUP BY LOCATION;	employee_hire_evaluation
SELECT count(*), LOCATION FROM shop GROUP BY LOCATION;	employee_hire_evaluation
SELECT manager_name, district FROM shop WHERE number_products = ( SELECT max(number_products) FROM shop );	employee_hire_evaluation
SELECT manager_name, district FROM shop ORDER BY number_products DESC LIMIT 1;	employee_hire_evaluation
SELECT min(number_products), max(number_products) FROM shop;	employee_hire_evaluation
SELECT min(number_products), max(number_products) FROM shop;	employee_hire_evaluation
SELECT name, LOCATION, district FROM shop ORDER BY number_products DESC;	employee_hire_evaluation
SELECT name, LOCATION, district FROM shop ORDER BY number_products DESC;	employee_hire_evaluation
SELECT name FROM shop WHERE number_products > ( SELECT avg(number_products) FROM shop );	employee_hire_evaluation
SELECT name FROM shop WHERE number_products > ( SELECT avg(number_products) FROM shop );	employee_hire_evaluation
SELECT T2.name FROM evaluation AS T1 JOIN employee AS T2 ON T1.employee_id = T2.employee_id GROUP BY T1.employee_id ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T2.name FROM evaluation AS T1 JOIN employee AS T2 ON T1.employee_id = T2.employee_id GROUP BY T1.employee_id ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T2.name FROM evaluation AS T1 JOIN employee AS T2 ON T1.employee_id = T2.employee_id ORDER BY T1.bonus DESC LIMIT 1;	employee_hire_evaluation
SELECT T2.name FROM evaluation AS T1 JOIN employee AS T2 ON T1.employee_id = T2.employee_id ORDER BY T1.bonus DESC LIMIT 1;	employee_hire_evaluation
SELECT name FROM employee WHERE employee_id NOT IN ( SELECT employee_id FROM evaluation );	employee_hire_evaluation
SELECT name FROM employee WHERE employee_id NOT IN ( SELECT employee_id FROM evaluation );	employee_hire_evaluation
SELECT T2.name FROM hiring AS T1 JOIN shop AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.shop_id ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T2.name FROM hiring AS T1 JOIN shop AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.shop_id ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT name FROM shop WHERE shop_id NOT IN ( SELECT shop_id FROM hiring );	employee_hire_evaluation
SELECT name FROM shop WHERE shop_id NOT IN ( SELECT shop_id FROM hiring );	employee_hire_evaluation
SELECT count(*), T2.name FROM hiring AS T1 JOIN shop AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.shop_id;	employee_hire_evaluation
SELECT count(*), T2.name FROM hiring AS T1 JOIN shop AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.shop_id;	employee_hire_evaluation
SELECT sum(bonus) FROM evaluation;	employee_hire_evaluation
SELECT sum(bonus) FROM evaluation;	employee_hire_evaluation
SELECT * FROM hiring;	employee_hire_evaluation
SELECT * FROM hiring;	employee_hire_evaluation
SELECT DISTINCT district FROM shop WHERE Number_products < 3000 INTERSECT SELECT DISTINCT district FROM shop WHERE Number_products > 10000;	employee_hire_evaluation
SELECT district FROM shop WHERE number_products < 3000 INTERSECT SELECT district WHERE number_products > 10000;	employee_hire_evaluation
SELECT count(DISTINCT LOCATION) FROM shop;	employee_hire_evaluation
SELECT count(DISTINCT LOCATION) FROM shop;	employee_hire_evaluation
SELECT count(*) FROM documents;	cre_Doc_Template_Mgt
SELECT count(*) FROM documents;	cre_Doc_Template_Mgt
SELECT document_id, document_name, document_description FROM documents;	cre_Doc_Template_Mgt
SELECT document_id, document_name, document_description FROM documents;	cre_Doc_Template_Mgt
SELECT document_name, template_id FROM documents WHERE document_description LIKE '%w%';	cre_Doc_Template_Mgt
SELECT document_name, template_id FROM documents WHERE document_description LIKE '%w%';	cre_Doc_Template_Mgt
SELECT document_id, template_id, document_description FROM documents WHERE document_name = "Robbin CV";	cre_Doc_Template_Mgt
SELECT document_id, template_id, document_description FROM documents WHERE document_name = "Robbin CV";	cre_Doc_Template_Mgt
SELECT count(DISTINCT template_id) FROM documents;	cre_Doc_Template_Mgt
SELECT count(DISTINCT template_id) FROM documents;	cre_Doc_Template_Mgt
SELECT count(*) FROM templates WHERE template_type_code = 'PPT';	cre_Doc_Template_Mgt
SELECT count(*) FROM templates AS T1 JOIN ref_template_types AS T2 ON T1.template_type_code = T2.template_type_code WHERE T2.template_type_code = "PPT";	cre_Doc_Template_Mgt
SELECT template_id, count(*) FROM documents GROUP BY template_id;	cre_Doc_Template_Mgt
SELECT template_id, count(*) FROM documents GROUP BY template_id ;	cre_Doc_Template_Mgt
SELECT t1.template_id, t1.template_type_code FROM templates AS t1 JOIN documents AS t2 ON t1.template_id = t2.template_id GROUP BY t1.template_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT t1.template_id, t1.template_type_code FROM templates AS t1 JOIN documents AS t2 ON t1.template_id = t2.template_id GROUP BY t1.template_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_id FROM documents GROUP BY template_id HAVING count(*) > 1;	cre_Doc_Template_Mgt
SELECT template_id FROM documents GROUP BY template_id HAVING count(*) > 1;	cre_Doc_Template_Mgt
SELECT template_id FROM templates WHERE template_id NOT IN ( SELECT template_id FROM documents);	cre_Doc_Template_Mgt
SELECT template_id FROM templates WHERE template_id NOT IN ( SELECT template_id FROM documents );	cre_Doc_Template_Mgt
SELECT count(*) FROM templates;	cre_Doc_Template_Mgt
SELECT count(*) FROM templates;	cre_Doc_Template_Mgt
SELECT template_id, version_number, template_type_code FROM templates;	cre_Doc_Template_Mgt
SELECT template_id, version_number, template_type_code FROM templates;	cre_Doc_Template_Mgt
SELECT DISTINCT template_type_code FROM templates;	cre_Doc_Template_Mgt
SELECT template_type_code FROM ref_template_types;	cre_Doc_Template_Mgt
SELECT template_id FROM templates WHERE template_type_code = "PP" OR template_type_code = "PPT";	cre_Doc_Template_Mgt
SELECT template_id FROM templates WHERE template_type_code = "PP" OR template_type_code = "PPT";	cre_Doc_Template_Mgt
SELECT count(*) FROM templates WHERE template_type_code = "CV";	cre_Doc_Template_Mgt
SELECT count(*) FROM templates AS T1 JOIN ref_template_types AS T2 ON T1.template_type_code = T2.template_type_code WHERE T2.template_type_code = "CV";	cre_Doc_Template_Mgt
SELECT version_number, template_type_code FROM templates WHERE version_number > 5;	cre_Doc_Template_Mgt
SELECT version_number, template_type_code FROM templates WHERE version_number > 5;	cre_Doc_Template_Mgt
SELECT template_type_code, count(*) FROM templates GROUP BY template_type_code;	cre_Doc_Template_Mgt
SELECT template_type_code, count(*) FROM templates GROUP BY template_type_code;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code HAVING count(*) < 3;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code HAVING count(*) < 3;	cre_Doc_Template_Mgt
SELECT min(version_number), template_type_code FROM templates;	cre_Doc_Template_Mgt
SELECT min(version_number), template_type_code FROM templates ORDER BY version_number LIMIT 1;	cre_Doc_Template_Mgt
SELECT t1.template_type_code FROM templates AS t1 JOIN documents AS t2 ON t1.template_id = t2.template_id WHERE t2.document_name = "Data base";	cre_Doc_Template_Mgt
SELECT t1.template_type_code FROM templates AS t1 JOIN documents AS t2 ON t1.template_id = t2.template_id WHERE t2.document_name = "Data base";	cre_Doc_Template_Mgt
SELECT T2.document_name FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id WHERE T1.template_type_code = "BK";	cre_Doc_Template_Mgt
SELECT T1.document_name FROM documents AS T1 JOIN templates AS T2 ON T1.template_id = T2.template_id WHERE T2.template_type_code = "BK";	cre_Doc_Template_Mgt
SELECT t2.template_type_code, count(*) FROM templates AS t1 JOIN ref_template_types AS t2 ON t1.template_type_code = t2.template_type_code JOIN documents AS t3 ON t1.template_id = t3.template_id GROUP BY t2.template_type_code;	cre_Doc_Template_Mgt
SELECT t2.template_type_code, count(*) FROM documents AS t1 JOIN templates AS t2 ON t1.template_id = t2.template_id GROUP BY t2.template_type_code ;	cre_Doc_Template_Mgt
SELECT t1.template_type_code FROM ref_template_types AS t1 JOIN templates AS t2 ON t1.template_type_code = t2.template_type_code JOIN documents AS t3 ON t2.template_id = t3.template_id GROUP BY t1.template_type_code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT t1.template_type_code FROM templates AS t1 JOIN documents AS t2 ON t1.template_id = t2.template_id GROUP BY t1.template_type_code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates EXCEPT SELECT template_type_code FROM templates INNER JOIN documents ON templates.template_id = documents.template_id;	cre_Doc_Template_Mgt
SELECT template_type_code FROM ref_template_types WHERE template_type_code NOT IN ( SELECT template_type_code FROM templates);	cre_Doc_Template_Mgt
SELECT template_type_code, template_type_description FROM ref_template_types;	cre_Doc_Template_Mgt
SELECT template_type_code, template_type_description FROM ref_template_types;	cre_Doc_Template_Mgt
SELECT template_type_description FROM ref_template_types WHERE template_type_code = "AD";	cre_Doc_Template_Mgt
SELECT template_type_description FROM ref_template_types WHERE template_type_code = "AD";	cre_Doc_Template_Mgt
SELECT template_type_code FROM ref_template_types WHERE template_type_description = "Book";	cre_Doc_Template_Mgt
SELECT template_type_code FROM ref_template_types WHERE template_type_description = "Book";	cre_Doc_Template_Mgt
SELECT DISTINCT t3.template_type_description FROM documents AS t1 JOIN templates AS t2 ON t1.template_id = t2.template_id JOIN ref_template_types AS t3 ON t2.template_type_code = t3.template_type_code;	cre_Doc_Template_Mgt
SELECT DISTINCT t1.document_description FROM documents AS t1 JOIN templates AS t2 ON t1.template_id = t2.template_id;	cre_Doc_Template_Mgt
SELECT t1.template_id FROM templates AS t1 JOIN ref_template_types AS t2 ON t1.template_type_code = t2.template_type_code WHERE t2.template_type_description = "Presentation";	cre_Doc_Template_Mgt
SELECT template_id FROM templates WHERE template_type_code = ( SELECT template_type_code FROM ref_template_types WHERE template_type_description = 'Presentation' );	cre_Doc_Template_Mgt
SELECT count(*) FROM paragraphs;	cre_Doc_Template_Mgt
SELECT count(*) FROM paragraphs;	cre_Doc_Template_Mgt
SELECT count(*) FROM paragraphs AS T1 JOIN documents AS T2 ON T1. document_id = T2. document_id WHERE T2. document_name = 'Summer Show';	cre_Doc_Template_Mgt
SELECT count(*) FROM paragraphs AS T1 JOIN documents AS T2 ON T1. document_id = T2. document_id WHERE T2. document_name = 'Summer Show';	cre_Doc_Template_Mgt
SELECT paragraph_text FROM paragraphs WHERE paragraph_text = 'Korea ';	cre_Doc_Template_Mgt
SELECT other_details FROM paragraphs WHERE paragraph_text LIKE '%Korea%';	cre_Doc_Template_Mgt
SELECT t1.paragraph_id, t1.paragraph_text FROM paragraphs AS t1 JOIN documents AS t2 ON t1.document_id = t2.document_id WHERE t2.document_name = 'Welcome to NY';	cre_Doc_Template_Mgt
SELECT t1.paragraph_id, t1.paragraph_text FROM paragraphs AS t1 JOIN documents AS t2 ON t1.document_id = t2.document_id WHERE t2.document_name = 'Welcome to NY';	cre_Doc_Template_Mgt
SELECT T2.paragraph_text FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T1.document_name = "Customer reviews";	cre_Doc_Template_Mgt
SELECT T2.paragraph_text FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T1.document_name = 'Customer reviews';	cre_Doc_Template_Mgt
SELECT document_id, count(*) FROM paragraphs GROUP BY document_id ORDER BY document_id;	cre_Doc_Template_Mgt
SELECT document_id, count(*) FROM paragraphs GROUP BY document_id ORDER BY document_id;	cre_Doc_Template_Mgt
SELECT document_id, document_name, count(*) FROM documents AS t1 JOIN paragraphs AS t2 ON t1.document_id = t2.document_id GROUP BY t1.document_id;	cre_Doc_Template_Mgt
SELECT document_id, document_name, count(*) FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id GROUP BY document_id;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) >= 2;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) >= 2;	cre_Doc_Template_Mgt
SELECT t1.document_id, t1.document_name FROM documents AS t1 JOIN paragraphs AS t2 ON t1.document_id = t2.document_id GROUP BY t1.document_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT t1.document_id, t1.document_name FROM documents AS t1 JOIN paragraphs AS t2 ON t1.document_id = t2.document_id GROUP BY t1.document_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id ORDER BY count(*) LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id ORDER BY count(*) LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) BETWEEN 1 AND 2;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) BETWEEN 1 AND 2;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs WHERE paragraph_text = 'Brazil' OR paragraph_text = 'Ireland';	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs WHERE paragraph_text = 'Brazil' UNION SELECT document_id FROM paragraphs WHERE paragraph_text = 'Ireland';	cre_Doc_Template_Mgt
SELECT count(*) FROM teacher;	course_teach
SELECT count(*) FROM teacher;	course_teach
SELECT Name FROM teacher ORDER BY Age;	course_teach
SELECT Name FROM teacher ORDER BY Age;	course_teach
SELECT Age, Hometown FROM teacher;	course_teach
SELECT Age, Hometown FROM teacher;	course_teach
SELECT Name FROM teacher WHERE Hometown <> 'Little Lever Urban District';	course_teach
SELECT Name FROM teacher WHERE Hometown <> 'Little Lever Urban District';	course_teach
SELECT Name FROM teacher WHERE Age = 32 OR Age = 33;	course_teach
SELECT Name FROM teacher WHERE Age = 32 OR Age = 33;	course_teach
SELECT Hometown FROM teacher ORDER BY Age LIMIT 1;	course_teach
SELECT Hometown FROM teacher ORDER BY Age LIMIT 1;	course_teach
SELECT Hometown, COUNT(*) FROM teacher GROUP BY Hometown;	course_teach
SELECT Hometown, COUNT(Teacher_ID) FROM teacher GROUP BY Hometown ;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown ORDER BY COUNT(*) DESC LIMIT 1;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown ORDER BY COUNT(*) DESC LIMIT 1;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown HAVING COUNT(*) >= 2;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown HAVING COUNT(*) >= 2;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID ORDER BY T1.Name ASC;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID ORDER BY T1.Name ASC;	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID WHERE T3.Course = "Math";	course_teach
SELECT T2.Name FROM course_arrange AS T1 JOIN teacher AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T1.Course_ID = T3.Course_ID WHERE T3.Course = "Math";	course_teach
SELECT T1.Name, COUNT(*) FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T1.Name;	course_teach
SELECT T1.Name, COUNT(*) FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T1.Name;	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T2.Teacher_ID HAVING COUNT(*) >= 2;	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T2.Teacher_ID HAVING COUNT(*) >= 2;	course_teach
SELECT Name FROM teacher WHERE Teacher_ID NOT IN ( SELECT Teacher_ID FROM course_arrange);	course_teach
SELECT Name FROM teacher WHERE Teacher_ID NOT IN ( SELECT Teacher_ID FROM course_arrange);	course_teach
SELECT count(*) FROM visitor WHERE Age < 30;	museum_visit
SELECT name FROM visitor WHERE level_of_membership > 4 ORDER BY level_of_membership DESC;	museum_visit
SELECT avg(Age) FROM visitor WHERE Level_of_membership <= 4;	museum_visit
SELECT name, level_of_membership FROM visitor WHERE level_of_membership > 4 ORDER BY age DESC;	museum_visit
SELECT Museum_ID, Name FROM museum ORDER BY Num_of_Staff DESC LIMIT 1;	museum_visit
SELECT avg(Num_of_Staff) FROM museum WHERE open_year < 2009;	museum_visit
SELECT Open_Year, Num_of_Staff FROM museum WHERE Name = 'Plaza Museum';	museum_visit
SELECT name FROM museum WHERE num_of_staff > ( SELECT min(num_of_staff) FROM museum WHERE open_year > 2010 );	museum_visit
SELECT T1.id, T1.name, T1.age FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id GROUP BY T2.visitor_id HAVING count(*) > 1;	museum_visit
SELECT T1.id, T1.name, T1.level_of_membership FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id ORDER BY T2.total_spent DESC LIMIT 1;	museum_visit
SELECT T1.Museum_ID, T1.Name FROM museum AS T1 JOIN visit AS T2 ON T1.Museum_ID = T2.Museum_ID GROUP BY T1.Museum_ID ORDER BY count(*) DESC LIMIT 1;	museum_visit
SELECT name FROM museum WHERE museum_id NOT IN ( SELECT museum_id FROM visit);	museum_visit
SELECT T2.name, T2.age FROM visit AS T1 JOIN visitor AS T2 ON T1.visitor_id = T2.id ORDER BY T1.num_of_ticket DESC LIMIT 1;	museum_visit
SELECT avg(Num_of_Ticket), max(Num_of_Ticket) FROM visit;	museum_visit
SELECT sum(Total_spent) FROM visit AS T1 JOIN visitor AS T2 ON T1.visitor_ID = T2.ID WHERE T2.Level_of_membership = 1;	museum_visit
SELECT T1.name FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id JOIN museum AS T3 ON T2.museum_id = T3.museum_id WHERE T3.open_year < 2009 INTERSECT SELECT T1.name FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id JOIN museum AS T3 ON T2.museum_id = T3.museum_id WHERE T3.open_year > 2011;	museum_visit
SELECT count(*) FROM visitor WHERE ID NOT IN ( SELECT visitor_ID FROM visit AS T1 JOIN museum AS T2 ON T1.Museum_ID = T2.Museum_ID WHERE T2.Open_Year > '2010' );	museum_visit
SELECT count(*) FROM museum WHERE open_year > 2013 OR open_year < 2008;	museum_visit
SELECT count(*) FROM players;	wta_1
SELECT count(*) FROM players;	wta_1
SELECT count(*) FROM matches;	wta_1
SELECT count(*) FROM matches;	wta_1
SELECT first_name, birth_date FROM players WHERE country_code = "USA";	wta_1
SELECT first_name, birth_date FROM players WHERE country_code = "USA";	wta_1
SELECT avg(loser_age), avg(winner_age) FROM matches;	wta_1
SELECT avg(loser_age), avg(winner_age) FROM matches;	wta_1
SELECT avg(winner_rank) FROM matches;	wta_1
SELECT avg(winner_rank) FROM matches;	wta_1
SELECT max(loser_rank) FROM matches;	wta_1
SELECT min(loser_rank) FROM matches;	wta_1
SELECT count(DISTINCT country_code) FROM players;	wta_1
SELECT count(DISTINCT country_code) FROM players;	wta_1
SELECT COUNT(DISTINCT loser_name) FROM matches;	wta_1
SELECT count(DISTINCT loser_name) FROM matches;	wta_1
SELECT tourney_name FROM matches GROUP BY tourney_name HAVING count(*) > 10;	wta_1
SELECT DISTINCT t1.tourney_name FROM matches AS t1 JOIN rankings AS t2 ON t1.winner_id = t2.player_id WHERE t1.match_num > 10;	wta_1
SELECT winner_name FROM matches WHERE year = 2013 INTERSECT SELECT winner_name FROM matches WHERE year = 2016;	wta_1
SELECT winner_name FROM matches WHERE year = 2013 UNION SELECT winner_name FROM matches WHERE year = 2016;	wta_1
SELECT count(*) FROM matches WHERE YEAR = 2013 OR YEAR = 2016;	wta_1
SELECT count(*) FROM matches WHERE YEAR = 2013 OR YEAR = 2016;	wta_1
SELECT T1.country_code, T1.first_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = "WTA Championships" INTERSECT SELECT T1.country_code, T1.first_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = "Australian Open";	wta_1
SELECT DISTINCT T1.first_name, T1.country_code FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = "WTA Championships" INTERSECT SELECT DISTINCT T1.first_name, T1.country_code FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = "Australian Open";	wta_1
SELECT first_name, country_code FROM players ORDER BY birth_date LIMIT 1;	wta_1
SELECT first_name, country_code FROM players ORDER BY birth_date LIMIT 1;	wta_1
SELECT first_name, last_name FROM players ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players WHERE hand = "L" ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players WHERE hand = "L" ORDER BY birth_date;	wta_1
SELECT T1.first_name, T1.country_code FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.player_id ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.country_code FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.player_id ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT year FROM matches GROUP BY year ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT YEAR FROM matches GROUP BY YEAR ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.last_name, T1.winner_rank_points FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id ORDER BY T2.best_of DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.last_name, T2.ranking_points FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id ORDER BY T2.ranking_points DESC LIMIT 1;	wta_1
SELECT T1.winner_name FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T1.tourney_name = "Australian Open" AND T1.winner_rank_points = ( SELECT MAX(winner_rank_points) FROM matches WHERE tourney_name = "Australian Open" );	wta_1
SELECT T1.winner_name FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id WHERE T1.tourney_name = "Australian Open" ORDER BY T2.ranking_points LIMIT 1;	wta_1
SELECT T1.loser_name, T1.winner_name FROM matches AS T1 JOIN players AS T2 ON T1.loser_id = T2.player_id JOIN players AS T3 ON T1.winner_id = T3.player_id ORDER BY T1.minutes DESC LIMIT 1;	wta_1
SELECT T1.winner_name, T1.loser_name FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id JOIN players AS T3 ON T1.loser_id = T3.player_id ORDER BY T1.minutes DESC LIMIT 1;	wta_1
SELECT avg(T1.ranking), T2.first_name FROM rankings AS T1 JOIN players AS T2 ON T1.player_id = T2.player_id GROUP BY T2.first_name;	wta_1
SELECT T1.first_name, avg(T2.ranking) FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT T1.first_name, sum(T2.ranking_points) FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT T1.first_name, sum(T2.ranking_points) FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT count(*), country_code FROM players GROUP BY country_code ;	wta_1
SELECT count(*), country_code FROM players GROUP BY country_code ;	wta_1
SELECT country_code FROM players GROUP BY country_code ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT country_code FROM players GROUP BY country_code ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT country_code FROM players GROUP BY country_code HAVING count(*) > 50;	wta_1
SELECT country_code FROM players GROUP BY country_code HAVING count(*) > 50;	wta_1
SELECT ranking_date, SUM(tours) FROM rankings GROUP BY ranking_date ;	wta_1
SELECT ranking_date, SUM(tours) FROM rankings GROUP BY ranking_date ;	wta_1
SELECT COUNT(*), YEAR FROM matches GROUP BY YEAR ;	wta_1
SELECT COUNT(*), YEAR FROM matches GROUP BY YEAR ;	wta_1
SELECT winner_name, winner_rank FROM matches ORDER BY winner_age LIMIT 3;	wta_1
SELECT T1.first_name, T1.last_name, T1.rank FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id ORDER BY T2.winner_age LIMIT 3;	wta_1
SELECT COUNT(DISTINCT T1.winner_id) FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T1.tourney_name = "WTA Championships" AND T2.hand = "L";	wta_1
SELECT count(*) FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T1.tourney_name = "WTA Championships" AND T2.hand = "L";	wta_1
SELECT T1.first_name, T1.country_code, T1.birth_date FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id ORDER BY T2.winner_rank_points DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.country_code, T1.birth_date FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id ORDER BY T2.winner_rank_points DESC LIMIT 1;	wta_1
SELECT count(*), hand FROM players GROUP BY hand ;	wta_1
SELECT count(*), hand FROM players GROUP BY hand ;	wta_1
SELECT COUNT(*) FROM ship WHERE disposition_of_ship = 'Captured';	battle_death
SELECT name, tonnage FROM ship ORDER BY name DESC ;	battle_death
SELECT name, date, result FROM battle;	battle_death
SELECT max(killed), min(killed) FROM death;	battle_death
SELECT avg(injured) FROM death;	battle_death
SELECT T2.killed, T2.injured FROM ship AS T1 JOIN death AS T2 ON T1.id = T2.caused_by_ship_id WHERE T1.tonnage = 't';	battle_death
SELECT name, result FROM battle WHERE bulgarian_commander NOT LIKE 'Boril';	battle_death
SELECT DISTINCT T1.id, T1.name FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.ship_type = 'Brig';	battle_death
SELECT T1.id, T1.name FROM battle AS T1 JOIN death AS T2 ON T2.caused_by_ship_id = T1.id WHERE T2.killed > 10;	battle_death
SELECT T1.id, T1.name FROM ship AS T1 JOIN death AS T2 ON T1.id = T2.caused_by_ship_id GROUP BY T1.id ORDER BY count(*) DESC LIMIT 1;	battle_death
SELECT DISTINCT name FROM battle WHERE bulgarian_commander = 'Kaloyan' AND latin_commander = 'Baldwin I';	battle_death
SELECT count(DISTINCT result) FROM battle;	battle_death
SELECT count(*) FROM ship WHERE tonnage = 225 AND id NOT IN ( SELECT id FROM death );	battle_death
SELECT T1.name, T1.date FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.name = 'Lettice' OR T2.name = 'HMS Atalanta';	battle_death
SELECT T1.name, T1.result, T1.bulgarian_commander FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.lost_in_battle IS NULL AND T2.location = 'English Channel';	battle_death
SELECT note FROM death WHERE note LIKE '%East%';	battle_death
SELECT line_1, line_2 FROM Addresses;	student_transcripts_tracking
SELECT line_1, line_2 FROM Addresses;	student_transcripts_tracking
SELECT count(*) FROM COURSES;	student_transcripts_tracking
SELECT count(*) FROM Courses;	student_transcripts_tracking
SELECT course_description FROM Courses WHERE course_name = "math";	student_transcripts_tracking
SELECT course_description FROM Courses WHERE course_name = "math";	student_transcripts_tracking
SELECT zip_postcode FROM Addresses WHERE city = "Port Chelsea";	student_transcripts_tracking
SELECT zip_postcode FROM Addresses WHERE city = "Port Chelsea";	student_transcripts_tracking
SELECT T1.department_name, T1.department_id FROM DEPARTMENTS AS T1 JOIN DEGREE_PROGRAMS AS T2 ON T1.department_id = T2.department_id GROUP BY T1.department_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.department_name, T1.department_id FROM DEPARTMENTS AS T1 JOIN Degree_Programs AS T2 ON T1.department_id = T2.department_id GROUP BY T1.department_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT count(DISTINCT department_id) FROM DEGREE_PROGRAMS;	student_transcripts_tracking
SELECT count(DISTINCT department_id) FROM DEGREE_PROGRAMS;	student_transcripts_tracking
SELECT count(DISTINCT degree_summary_name) FROM degree_programs;	student_transcripts_tracking
SELECT count(DISTINCT degree_summary_name) FROM degree_programs;	student_transcripts_tracking
SELECT count(*) FROM DEGREE_PROGRAMS AS T1 JOIN DEPARTMENTS AS T2 ON T1.department_id = T2.department_id WHERE T2.department_name = "engineering";	student_transcripts_tracking
SELECT count(*) FROM DEGREE_PROGRAMS AS T1 JOIN DEPARTMENTS AS T2 ON T1.department_id = T2.department_id WHERE T2.department_name = "engineering";	student_transcripts_tracking
SELECT T1.section_name, T1.section_description FROM Sections AS T1 JOIN Courses AS T2 ON T1.course_id = T2.course_id;	student_transcripts_tracking
SELECT T1.section_name, T1.section_description FROM Sections AS T1 JOIN Courses AS T2 ON T1.course_id = T2.course_id;	student_transcripts_tracking
SELECT T2.course_name, T1.course_id FROM Sections AS T1 JOIN Courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_id HAVING count(*) <= 2;	student_transcripts_tracking
SELECT T1.course_name, T1.course_id FROM Courses AS T1 JOIN Sections AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_id HAVING count(*) < 2;	student_transcripts_tracking
SELECT section_name FROM Sections ORDER BY section_name DESC;	student_transcripts_tracking
SELECT section_name FROM Sections ORDER BY section_name DESC;	student_transcripts_tracking
SELECT T1.semester_name, T1.semester_id FROM SEMESTERS AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id GROUP BY T1.semester_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.semester_name, T1.semester_id FROM SEMESTERS AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id GROUP BY T1.semester_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT department_description FROM Departments WHERE department_name LIKE "%computer%";	student_transcripts_tracking
SELECT department_description FROM DEPARTMENTS WHERE department_name LIKE "%computer%";	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T1.student_id FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id HAVING count(*) = 2;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T1.student_id FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id HAVING count(*) = 2;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = "Bachelor";	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = "Bachelor";	student_transcripts_tracking
SELECT T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_summary_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_summary_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT degree_program_id, degree_summary_name FROM degree_programs AS T1 JOIN student_enrollment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY degree_program_id ORDER BY count(*) LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_program_id, T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_program_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.student_id, T1.first_name, T1.middle_name, T1.last_name, count(*), T1.student_id FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T1.student_id, count(*) FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id ORDER BY count(*) LIMIT 1;	student_transcripts_tracking
SELECT semester_name FROM SEMESTERS WHERE semester_id NOT IN ( SELECT semester_id FROM Student_Enrolment );	student_transcripts_tracking
SELECT semester_name FROM SEMESTERS WHERE semester_id NOT IN ( SELECT semester_id FROM Student_Enrolment );	student_transcripts_tracking
SELECT T1.course_name FROM Courses AS T1 JOIN Student_Enrolment_Courses AS T2 ON T1.course_id = T2.course_id;	student_transcripts_tracking
SELECT T1.course_name FROM COURSES AS T1 JOIN Student_Enrolment_Courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name;	student_transcripts_tracking
SELECT T1.course_name FROM Courses AS T1 JOIN Student_Enrolment_Courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.course_name FROM Courses AS T1 JOIN Student_Enrolment_Courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT last_name FROM students WHERE state_province_county = "North Carolina" AND student_id NOT IN ( SELECT student_id FROM student_enrolment );	student_transcripts_tracking
SELECT last_name FROM students WHERE state_province_county = "North Carolina" AND student_id NOT IN ( SELECT student_id FROM student_enrolment );	student_transcripts_tracking
SELECT T2.transcript_date, T2.transcript_id FROM Transcript_contents AS T1 JOIN Transcripts AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id HAVING count(*) >= 2;	student_transcripts_tracking
SELECT T2.transcript_date, T2.transcript_id FROM Transcript_contents AS T1 JOIN Transcripts AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id HAVING count(*) >= 2;	student_transcripts_tracking
SELECT cell_mobile_number FROM students WHERE first_name = "Timmothy" AND last_name = "Ward";	student_transcripts_tracking
SELECT cell_mobile_number FROM students WHERE first_name = "Timmothy" AND last_name = "ward";	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM students WHERE date_left = ( SELECT min(date_left) FROM students );	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM students WHERE date_left IS NOT NULL ORDER BY date_left LIMIT 1;	student_transcripts_tracking
SELECT first_name FROM students WHERE permanent_address_id <> current_address_id;	student_transcripts_tracking
SELECT first_name FROM students WHERE permanent_address_id <> current_address_id;	student_transcripts_tracking
SELECT T1.address_id, T1.line_1, T1.line_2, T1.line_3 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.current_address_id GROUP BY T1.address_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.address_id, T1.line_1, T1.line_2 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.current_address_id GROUP BY T1.address_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT avg(transcript_date) FROM transcripts;	student_transcripts_tracking
SELECT avg(transcript_date) FROM transcripts;	student_transcripts_tracking
SELECT transcript_date, other_details FROM transcripts ORDER BY transcript_date LIMIT 1;	student_transcripts_tracking
SELECT transcript_date, other_details FROM transcripts ORDER BY transcript_date LIMIT 1;	student_transcripts_tracking
SELECT count(*) FROM TRANSCRIPTS;	student_transcripts_tracking
SELECT count(*) FROM TRANSCRIPTS;	student_transcripts_tracking
SELECT transcript_date FROM transcripts ORDER BY transcript_date DESC LIMIT 1;	student_transcripts_tracking
SELECT transcript_date FROM transcripts ORDER BY transcript_date DESC LIMIT 1;	student_transcripts_tracking
SELECT max(count(*)), T1.student_course_id FROM Transcript_contents AS T1 JOIN TRANSCRIPTS AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.student_course_id;	student_transcripts_tracking
SELECT T1.course_id, count(*) FROM Transcript_Contents AS T1 JOIN Transcripts AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.course_id ORDER BY count(*) LIMIT 1;	student_transcripts_tracking
SELECT transcript_date, transcript_id FROM TRANSCRIPTS ORDER BY transcript_id LIMIT 1;	student_transcripts_tracking
SELECT T2.transcript_date, T2.transcript_id FROM Transcript_contents AS T1 JOIN Transcripts AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id ORDER BY count(*) LIMIT 1;	student_transcripts_tracking
SELECT T1.semester_name FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = "Master" INTERSECT SELECT T1.semester_name FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = "Bachelor";	student_transcripts_tracking
SELECT T1.semester_id FROM Student_Enrolment AS T1 JOIN Degree_Programs AS T2 ON T1.degree_program_id = T2.degree_program_id WHERE T2.degree_summary_name = "Master" INTERSECT SELECT T1.semester_id FROM Student_Enrolment AS T1 JOIN Degree_Programs AS T2 ON T1.degree_program_id = T2.degree_program_id WHERE T2.degree_summary_name = "Bachelor";	student_transcripts_tracking
SELECT count(DISTINCT current_address_id) FROM students;	student_transcripts_tracking
SELECT DISTINCT T1.line_1, T1.line_2, T1.line_3 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.current_address_id;	student_transcripts_tracking
SELECT other_student_details FROM STUDENTS ORDER BY other_student_details DESC;	student_transcripts_tracking
SELECT other_student_details FROM students ORDER BY first_name DESC;	student_transcripts_tracking
SELECT section_description FROM SECTIONS WHERE section_name = "h";	student_transcripts_tracking
SELECT T2.course_description FROM Sections AS T1 JOIN Courses AS T2 ON T1.course_id = T2.course_id WHERE T1.section_name = "h";	student_transcripts_tracking
SELECT first_name FROM students WHERE country = "Haiti" OR cell_mobile_number = "09700166582";	student_transcripts_tracking
SELECT first_name FROM students WHERE country = "Haiti" OR cell_mobile_number = "09700166582";	student_transcripts_tracking
SELECT Title FROM cartoon ORDER BY Title;	tvshow
SELECT Title FROM cartoon ORDER BY Title;	tvshow
SELECT Title FROM cartoon WHERE Directed_by = "Ben Jones";	tvshow
SELECT title FROM cartoon WHERE directed_by = 'Ben Jones';	tvshow
SELECT count(*) FROM cartoon WHERE written_by = "Joseph Kuhr";	tvshow
SELECT count(*) FROM cartoon WHERE written_by = 'Joseph Kuhr';	tvshow
SELECT Title, Directed_by FROM cartoon ORDER BY Original_air_date;	tvshow
SELECT T1.Title, T2Directed_by FROM cartoon AS T1 JOIN TV_series AS T2 ON T1.Channel = T2.Channel ORDER BY T2.Air_Date;	tvshow
SELECT title FROM cartoon WHERE directed_by = "Ben Jones" OR directed_by = "Brandon Vietti";	tvshow
SELECT title FROM cartoon WHERE directed_by = 'Ben Jones' OR directed_by = 'Brandon Vietti';	tvshow
SELECT Country, COUNT(*) FROM TV_Channel GROUP BY Country ORDER BY COUNT(*) DESC LIMIT 1;	tvshow
SELECT Country, count(*) FROM TV_Channel GROUP BY Country ORDER BY count(*) DESC LIMIT 1;	tvshow
SELECT count(DISTINCT series_name), count(DISTINCT CONTENT) FROM TV_Channel;	tvshow
SELECT count(DISTINCT series_name), count(DISTINCT Content) FROM TV_Channel;	tvshow
SELECT Content FROM TV_Channel WHERE series_name = "Sky Radio";	tvshow
SELECT Content FROM TV_Channel WHERE series_name = "Sky Radio";	tvshow
SELECT Package_Option FROM TV_Channel WHERE series_name = "Sky Radio";	tvshow
SELECT Package_Option FROM TV_Channel WHERE series_name = 'Sky Radio';	tvshow
SELECT COUNT(*) FROM TV_Channel WHERE Language = 'English';	tvshow
SELECT count(*) FROM TV_Channel WHERE Language = 'English';	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language ORDER BY COUNT(*) LIMIT 1;	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language ORDER BY COUNT(*) LIMIT 1;	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language;	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language;	tvshow
SELECT T1.series_name FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Title = "The Rise of the Blue Beetle!";	tvshow
SELECT T1.series_name FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Title = "The Rise of the Blue Beetle!";	tvshow
SELECT T2.Title FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T1.series_name = "Sky Radio";	tvshow
SELECT T2.Title FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T1.series_name = "Sky Radio";	tvshow
SELECT Episode FROM TV_series ORDER BY Rating;	tvshow
SELECT Episode FROM TV_series ORDER BY Rating;	tvshow
SELECT Episode, Rating FROM TV_series ORDER BY Rating DESC LIMIT 3;	tvshow
SELECT Episode, Rating FROM TV_series ORDER BY Rating DESC LIMIT 3;	tvshow
SELECT min(Share), max(Share) FROM TV_series;	tvshow
SELECT max(Share), min(Share) FROM TV_series;	tvshow
SELECT Air_Date FROM TV_series WHERE Episode = "A Love of a Lifetime";	tvshow
SELECT Air_Date FROM TV_series WHERE Episode = 'A Love of a Lifetime';	tvshow
SELECT Weekly_Rank FROM TV_series WHERE Episode = "A Love of a Lifetime";	tvshow
SELECT Weekly_Rank FROM TV_series WHERE Episode = "A Love of a Lifetime";	tvshow
SELECT T1.series_name FROM TV_Channel AS T1 JOIN TV_series AS T2 ON T1.id = T2.Channel WHERE T2.Episode = "A Love of a Lifetime";	tvshow
SELECT T1.series_name FROM TV_Channel AS T1 INNER JOIN TV_series AS T2 ON T1.id = T2.Channel WHERE T2.Episode = "A Love of a Lifetime";	tvshow
SELECT T2.Episode FROM TV_Channel AS T1 JOIN TV_series AS T2 ON T1.id = T2.Channel WHERE T1.series_name = "Sky Radio";	tvshow
SELECT T2.Episode FROM TV_Channel AS T1 JOIN TV_series AS T2 ON T1.id = T2.Channel WHERE T1.series_name = "Sky Radio";	tvshow
SELECT count(*), Directed_by FROM cartoon GROUP BY Directed_by;	tvshow
SELECT Directed_by, count(*) FROM cartoon GROUP BY Directed_by;	tvshow
SELECT Production_code, Channel FROM cartoon ORDER BY original_air_date DESC LIMIT 1;	tvshow
SELECT Production_code, Channel FROM cartoon ORDER BY original_air_date DESC LIMIT 1;	tvshow
SELECT Package_Option, series_name FROM TV_Channel WHERE Hight_definition_TV = 'yes';	tvshow
SELECT Package_Option, series_name FROM TV_Channel WHERE Hight_definition_TV = 'yes';	tvshow
SELECT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = "Todd Casey";	tvshow
SELECT DISTINCT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = "Todd Casey";	tvshow
SELECT Country FROM TV_Channel WHERE id NOT IN ( SELECT Channel FROM Cartoon WHERE Written_by = 'Todd Casey' );	tvshow
SELECT Country FROM TV_Channel WHERE id NOT IN ( SELECT Channel FROM Cartoon WHERE Written_by = 'Todd Casey' );	tvshow
SELECT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.directed_by = 'Ben Jones' OR T2.directed_by = 'Michael Chang';	tvshow
SELECT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.directed_by = 'Ben Jones' OR T2.directed_by = 'Michael Chang';	tvshow
SELECT Pixel_aspect_ratio_PAR, Country FROM TV_Channel WHERE Language!= "English";	tvshow
SELECT Pixel_aspect_ratio_PAR, Country FROM TV_Channel WHERE Language <> 'English';	tvshow
SELECT Country FROM TV_Channel GROUP BY Country HAVING count(*) > 2;	tvshow
SELECT id FROM TV_Channel GROUP BY id HAVING count(*) > 2;	tvshow
SELECT id FROM TV_Channel WHERE id NOT IN ( SELECT channel FROM cartoon WHERE directed_by = 'Ben Jones' );	tvshow
SELECT id FROM TV_Channel WHERE id NOT IN ( SELECT channel FROM cartoon WHERE directed_by = 'Ben Jones' );	tvshow
SELECT Package_Option FROM TV_Channel WHERE id NOT IN ( SELECT Channel FROM Cartoon WHERE Directed_by = 'Ben Jones' );	tvshow
SELECT Package_Option FROM TV_Channel WHERE id NOT IN ( SELECT channel FROM cartoon WHERE directed_by = 'Ben Jones' );	tvshow
SELECT count(*) FROM poker_player;	poker_player
SELECT count(*) FROM poker_player;	poker_player
SELECT Earnings FROM poker_player ORDER BY Earnings DESC;	poker_player
SELECT Earnings FROM poker_player ORDER BY Earnings DESC;	poker_player
SELECT Final_Table_Made, Best_Finish FROM poker_player;	poker_player
SELECT Final_Table_Made, Best_Finish FROM poker_player;	poker_player
SELECT avg(Earnings) FROM poker_player;	poker_player
SELECT avg(Earnings) FROM poker_player;	poker_player
SELECT Money_Rank FROM poker_player ORDER BY Earnings DESC LIMIT 1;	poker_player
SELECT Money_Rank FROM poker_player ORDER BY Earnings DESC LIMIT 1;	poker_player
SELECT max(Final_Table_Made) FROM poker_player WHERE Earnings < 200000;	poker_player
SELECT max(Final_Table_Made) FROM poker_player WHERE Earnings < 200000;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID;	poker_player
SELECT T1.Name FROM People AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Earnings > 300000;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T1.Earnings > 300000;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Final_Table_Made ASC;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Final_Table_Made ASC;	poker_player
SELECT T2.Birth_Date FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Earnings LIMIT 1;	poker_player
SELECT T2.Birth_Date FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Earnings LIMIT 1;	poker_player
SELECT T1.Money_Rank FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Height DESC LIMIT 1;	poker_player
SELECT T1.Money_Rank FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Height DESC LIMIT 1;	poker_player
SELECT avg(T1.Earnings) FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Height > 200;	poker_player
SELECT avg(T1.Earnings) FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Height > 200;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Earnings DESC;	poker_player
SELECT T1.Name FROM People AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Earnings DESC;	poker_player
SELECT Nationality, COUNT(*) FROM People GROUP BY Nationality;	poker_player
SELECT Nationality, COUNT(*) FROM People GROUP BY Nationality;	poker_player
SELECT Nationality FROM people GROUP BY Nationality ORDER BY COUNT(*) DESC LIMIT 1;	poker_player
SELECT Nationality FROM People GROUP BY Nationality ORDER BY COUNT(*) DESC LIMIT 1;	poker_player
SELECT Nationality FROM People GROUP BY Nationality HAVING count(*) >= 2;	poker_player
SELECT Nationality FROM People GROUP BY Nationality HAVING count(*) >= 2;	poker_player
SELECT Name, Birth_Date FROM people ORDER BY Name ASC;	poker_player
SELECT Name, Birth_Date FROM people ORDER BY Name;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID WHERE T1.Nationality <> "Russia";	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Nationality <> "Russia";	poker_player
SELECT Name FROM people WHERE People_ID NOT IN ( SELECT People_ID FROM poker_player );	poker_player
SELECT Name FROM people WHERE People_ID NOT IN ( SELECT People_ID FROM poker_player );	poker_player
SELECT count(DISTINCT Nationality) FROM people;	poker_player
SELECT count(DISTINCT Nationality) FROM people;	poker_player
SELECT count(*) FROM area_code_state;	voter_1
SELECT contestant_number, contestant_name FROM contestants ORDER BY contestant_name DESC;	voter_1
SELECT vote_id, phone_number, state FROM VOTES;	voter_1
SELECT max(area_code), min(area_code) FROM area_code_state;	voter_1
SELECT max(created) FROM votes WHERE state = "CA";	voter_1
SELECT contestant_name FROM contestants WHERE contestant_name NOT LIKE 'Jessie Alloway';	voter_1
SELECT DISTINCT state, created FROM VOTES;	voter_1
SELECT T1.contestant_number, T1.contestant_name FROM contestants AS T1 JOIN votes AS T2 ON T1.contestant_number = T2.contestant_number GROUP BY T1.contestant_number HAVING count(*) >= 2;	voter_1
SELECT T1.contestant_number, T1.contestant_name FROM contestants AS T1 JOIN votes AS T2 ON T1.contestant_number = T2.contestant_number GROUP BY T1.contestant_number ORDER BY count(*) LIMIT 1;	voter_1
SELECT count(*) FROM votes WHERE state = 'NY' OR state = 'CA';	voter_1
SELECT count(*) FROM contestants WHERE contestant_number NOT IN ( SELECT contestant_number FROM votes );	voter_1
SELECT T1.area_code FROM area_code_state AS T1 JOIN votes AS T2 ON T1.state = T2.state GROUP BY T1.area_code ORDER BY count(*) DESC LIMIT 1;	voter_1
SELECT T1.created, T1.state, T1.phone_number FROM VOTES AS T1 JOIN contestants AS T2 ON T1.contestant_number = T2.contestant_number WHERE T2.contestant_name = 'Tabatha Gehling';	voter_1
SELECT T1.area_code FROM area_code_state AS T1 JOIN votes AS T2 ON T1.state = T2.state JOIN contestants AS T3 ON T3.contestant_number = T2.contestant_number WHERE T3.contestant_name = 'Tabatha Gehling' INTERSECT SELECT T1.area_code FROM area_code_state AS T1 JOIN votes AS T2 ON T1.state = T2.state JOIN contestants AS T3 ON T3.contestant_number = T2.contestant_number WHERE T3.contestant_name = 'Kelly Clauss';	voter_1
SELECT contestant_name FROM contestants WHERE contestant_name LIKE '%Al%';	voter_1
SELECT Name FROM country WHERE IndepYear > 1950;	world_1
SELECT Name FROM country WHERE IndepYear > 1950;	world_1
SELECT count(*) FROM country WHERE GovernmentForm = 'Republic';	world_1
SELECT COUNT(*) FROM country WHERE GovernmentForm = 'Republic';	world_1
SELECT sum(SurfaceArea) FROM country WHERE Region = 'Caribbean';	world_1
SELECT sum(SurfaceArea) FROM country WHERE Region = 'Caribbean';	world_1
SELECT Continent FROM country WHERE Name = 'Anguilla';	world_1
SELECT Continent FROM country WHERE Name = 'Anguilla';	world_1
SELECT T2.Region FROM city AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Name = 'Kabul';	world_1
SELECT T2.Region FROM city AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Name = 'Kabul';	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = 'Aruba' ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = 'Aruba' ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT Population, LifeExpectancy FROM country WHERE Name = 'Brazil';	world_1
SELECT Population, LifeExpectancy FROM country WHERE Name = 'Brazil';	world_1
SELECT Region, Population FROM country WHERE Name = 'Angola';	world_1
SELECT Region, Population FROM country WHERE Name = 'Angola';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Region = 'Central Africa';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Region = 'Central Africa';	world_1
SELECT Name FROM country WHERE Continent = 'Asia' ORDER BY LifeExpectancy LIMIT 1;	world_1
SELECT Name FROM country WHERE Continent = 'Asia' ORDER BY LifeExpectancy LIMIT 1;	world_1
SELECT sum(T1.Population), max(T2.GNP) FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia';	world_1
SELECT count(*), max(T2.GNP) FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Continent = 'Africa' AND GovernmentForm = 'Republic';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Continent = 'Africa' AND GovernmentForm = 'Republic';	world_1
SELECT sum(SurfaceArea) FROM country WHERE Continent = 'Asia' OR Continent = 'Europe';	world_1
SELECT sum(SurfaceArea) FROM country WHERE Continent = 'Asia' OR Continent = 'Europe';	world_1
SELECT sum(Population) FROM city WHERE District = 'Gelderland';	world_1
SELECT sum(population) FROM city WHERE district = 'Gelderland';	world_1
SELECT avg(GNP), sum(Population) FROM country WHERE GovernmentForm = 'US Territory';	world_1
SELECT avg(GNP), sum(Population) FROM country WHERE Code2 = 'US';	world_1
SELECT count(DISTINCT Language) FROM countrylanguage;	world_1
SELECT count(DISTINCT Language) FROM countrylanguage;	world_1
SELECT COUNT(DISTINCT GovernmentForm) FROM country WHERE Continent = 'Africa';	world_1
SELECT COUNT(DISTINCT GovernmentForm) FROM country WHERE Continent = 'Africa';	world_1
SELECT count(DISTINCT T1.Language) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Name = 'Aruba';	world_1
SELECT count(DISTINCT T1.Language) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Name = 'Aruba';	world_1
SELECT COUNT(*) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Name = 'Afghanistan' AND T1.IsOfficial = 'T';	world_1
SELECT COUNT(DISTINCT T1.Language) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Name = 'Afghanistan' AND T1.IsOfficial = 'T';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Name ORDER BY count(*) DESC LIMIT 1;	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Name ORDER BY count(*) DESC LIMIT 1;	world_1
SELECT T2.Continent FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code GROUP BY T2.Continent ORDER BY count(*) DESC LIMIT 1;	world_1
SELECT T2.Continent FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code GROUP BY T2.Continent ORDER BY count(*) DESC LIMIT 1;	world_1
SELECT count(*) FROM countrylanguage WHERE Language = 'Dutch' AND Language = 'English';	world_1
SELECT COUNT(DISTINCT T1.Code) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' UNION SELECT T1.Name WHERE T2.Language = 'French';	world_1
SELECT DISTINCT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode JOIN countrylanguage AS T3 ON T1.Code = T3.CountryCode WHERE T2.Language = 'English' AND T3.Language = 'French';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' AND T2.IsOfficial = 'T' INTERSECT SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'French' AND T2.IsOfficial = 'T';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' UNION SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'French';	world_1
SELECT COUNT(DISTINCT T1.Continent) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Chinese';	world_1
SELECT COUNT(DISTINCT T1.Continent) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Chinese';	world_1
SELECT DISTINCT T1.Region FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch';	world_1
SELECT DISTINCT T1.Region FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Dutch' OR T2.Language = 'English';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch';	world_1
SELECT DISTINCT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch' AND T2.IsOfficial = 'T';	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia' ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia' GROUP BY T2.Language ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.GovernmentForm = 'Republic' GROUP BY T1.Language HAVING COUNT(*) = 1;	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.GovernmentForm = 'Republic' GROUP BY T2.Language HAVING COUNT(*) = 1;	world_1
SELECT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' ORDER BY T1.Population DESC LIMIT 1;	world_1
SELECT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.ID = T2.CountryCode WHERE T2.Language = 'English' ORDER BY T1.Population DESC LIMIT 1;	world_1
SELECT T1.Name, T1.Population, T1.LifeExpectancy FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia' ORDER BY T1.SurfaceArea DESC LIMIT 1;	world_1
SELECT Name, Population, LifeExpectancy FROM country WHERE Continent = 'Asia' ORDER BY SurfaceArea DESC LIMIT 1;	world_1
SELECT avg(T2.LifeExpectancy) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language = 'English' AND T1.IsOfficial = 'F';	world_1
SELECT avg(T2.LifeExpectancy) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language = 'English' AND T1.IsOfficial = 'F';	world_1
SELECT sum(T2.Population) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language NOT LIKE 'English';	world_1
SELECT count(*) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language NOT LIKE '%English%';	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.HeadOfState = 'Beatrix' AND T2.IsOfficial = 'T';	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.HeadOfState = 'Beatrix' AND T1.IsOfficial = 'T';	world_1
SELECT count(DISTINCT T2.Language) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.IndepYear < 1930;	world_1
SELECT count(DISTINCT T1.Language) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.IndepYear < 1930 AND T1.IsOfficial = 'T';	world_1
SELECT Name FROM country WHERE SurfaceArea > ( SELECT max(SurfaceArea) FROM country WHERE Continent = 'Europe' );	world_1
SELECT Name FROM country WHERE SurfaceArea > ( SELECT max(SurfaceArea) FROM country WHERE Continent = 'Europe' );	world_1
SELECT Name FROM country WHERE Continent = 'Africa' EXCEPT SELECT Name FROM country WHERE Continent = 'Asia';	world_1
SELECT Name FROM country WHERE Continent = 'Africa' AND Population < ( SELECT MIN(Population) FROM country WHERE Continent = 'Asia' );	world_1
SELECT Name FROM country WHERE Population > ( SELECT max(Population) FROM country WHERE Continent = 'Africa' ) AND Continent = 'Asia';	world_1
SELECT Name FROM country WHERE Continent = 'Asia' EXCEPT SELECT Name FROM country WHERE Continent = 'Africa';	world_1
SELECT DISTINCT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language NOT LIKE 'English';	world_1
SELECT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language NOT LIKE 'English';	world_1
SELECT DISTINCT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language!= 'English';	world_1
SELECT DISTINCT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language NOT LIKE 'English';	world_1
SELECT T2.Code FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language NOT LIKE 'English' AND T2.GovernmentForm NOT LIKE 'Republic';	world_1
SELECT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language NOT LIKE 'English' AND T1.GovernmentForm NOT LIKE 'Republic';	world_1
SELECT T1.Name FROM city AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code JOIN countrylanguage AS T3 ON T2.Code = T3.CountryCode WHERE T2.Continent = 'Europe' AND T3.Language = 'English' AND T3.IsOfficial = 'F';	world_1
SELECT T2.Name FROM countrylanguage AS T1 JOIN city AS T2 ON T1.CountryCode = T2.CountryCode WHERE T1.Language = 'English' AND T1.IsOfficial = 'F';	world_1
SELECT DISTINCT T1.Name FROM city AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code JOIN countrylanguage AS T3 ON T2.Code = T3.CountryCode WHERE T2.Region = 'Asia' AND T3.Language = 'Chinese' AND T3.IsOfficial = 'T';	world_1
SELECT DISTINCT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode JOIN country AS T3 ON T3.Code = T2.CountryCode WHERE T3.Continent = 'Asia' AND T2.Language = 'Chinese' AND T2.IsOfficial = 'T';	world_1
SELECT Name, IndepYear, SurfaceArea FROM country ORDER BY Population LIMIT 1;	world_1
SELECT Name, IndepYear, SurfaceArea FROM country ORDER BY Population LIMIT 1;	world_1
SELECT Population, Name, HeadOfState FROM country ORDER BY SurfaceArea DESC LIMIT 1;	world_1
SELECT Name, Population, HeadOfState FROM country ORDER BY SurfaceArea DESC LIMIT 1;	world_1
SELECT T1.Name, COUNT(DISTINCT T2.Language) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Name HAVING COUNT(DISTINCT T2.Language) >= 3;	world_1
SELECT T1.Name, COUNT(T2.Language) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Name HAVING COUNT(T2.Language) > 2;	world_1
SELECT COUNT(*), District FROM city WHERE Population > ( SELECT AVG(Population) FROM city ) GROUP BY District HAVING COUNT(*) > 1;	world_1
SELECT District, count(*) FROM city WHERE Population > ( SELECT avg(Population) FROM city ) GROUP BY District HAVING count(*) > 1;	world_1
SELECT GovernmentForm, SUM(Population) FROM country WHERE LifeExpectancy > 72 GROUP BY GovernmentForm ;	world_1
SELECT T1.GovernmentForm, SUM(T2.Population) FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.GovernmentForm HAVING AVG(T1.LifeExpectancy) > 72;	world_1
SELECT avg(LifeExpectancy), sum(Population) FROM country WHERE LifeExpectancy < 72 ;	world_1
SELECT Continent, sum(Population), avg(LifeExpectancy) FROM country WHERE LifeExpectancy < 72 GROUP BY Continent;	world_1
SELECT Name, SurfaceArea FROM country ORDER BY SurfaceArea DESC LIMIT 5;	world_1
SELECT Name, SurfaceArea FROM country ORDER BY SurfaceArea DESC LIMIT 5;	world_1
SELECT Name FROM country ORDER BY Population DESC LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population DESC LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population LIMIT 3;	world_1
SELECT count(*) FROM country WHERE Continent = 'Asia';	world_1
SELECT COUNT(Code) FROM country WHERE Continent = 'Asia';	world_1
SELECT Name FROM country WHERE Continent = 'Europe' AND Population = 80000;	world_1
SELECT Name FROM country WHERE Continent = 'Europe' AND Population = 80000;	world_1
SELECT SUM(T1.Population), AVG(T1.SurfaceArea) FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'North America' AND T1.SurfaceArea > 3000;	world_1
SELECT sum(T1.Population), avg(T1.SurfaceArea) FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'North America' AND T1.SurfaceArea > 3000;	world_1
SELECT Name FROM city WHERE Population BETWEEN 160000 AND 900000;	world_1
SELECT Name FROM city WHERE Population BETWEEN 160000 AND 900000;	world_1
SELECT Language FROM countrylanguage GROUP BY Language ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT Language FROM countrylanguage GROUP BY Language ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code ORDER BY T1.Percentage DESC LIMIT 1;	world_1
SELECT T1.Code, T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT count(*) FROM countrylanguage WHERE Language = 'Spanish' AND Percentage = ( SELECT max(Percentage) FROM countrylanguage );	world_1
SELECT COUNT(*) FROM countrylanguage WHERE Language = 'Spanish' AND IsOfficial = 'T';	world_1
SELECT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Spanish' ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Spanish' AND T2.IsOfficial = 'T';	world_1
SELECT count(*) FROM conductor;	orchestra
SELECT count(*) FROM conductor;	orchestra
SELECT Name FROM conductor ORDER BY Age ASC;	orchestra
SELECT Name FROM conductor ORDER BY Age;	orchestra
SELECT Name FROM conductor WHERE Nationality NOT LIKE "USA";	orchestra
SELECT Name FROM conductor WHERE Nationality!= "USA";	orchestra
SELECT Record_Company FROM orchestra ORDER BY Year_of_Founded DESC;	orchestra
SELECT Record_Company FROM orchestra ORDER BY Year_of_Founded DESC;	orchestra
SELECT avg(Attendance) FROM show;	orchestra
SELECT avg(Attendance) FROM show;	orchestra
SELECT max(Share), min(Share) FROM performance WHERE TYPE!= "Live final";	orchestra
SELECT max(Share), min(Share) FROM performance WHERE TYPE!= "Live final";	orchestra
SELECT count(DISTINCT Nationality) FROM conductor;	orchestra
SELECT count(DISTINCT Nationality) FROM conductor;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC LIMIT 1;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC LIMIT 1;	orchestra
SELECT T1.Name, T2.Orchestra FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID;	orchestra
SELECT T1.Name, T2.Orchestra FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Conductor_ID HAVING count(*) > 1;	orchestra
SELECT T2.Name FROM orchestra AS T1 JOIN conductor AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Conductor_ID HAVING count(*) > 1;	orchestra
SELECT T2.Name FROM orchestra AS T1 JOIN conductor AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Conductor_ID ORDER BY count(*) DESC LIMIT 1;	orchestra
SELECT T2.Name FROM orchestra AS T1 JOIN conductor AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Conductor_ID ORDER BY count(*) DESC LIMIT 1;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID WHERE T2.Year_of_Founded > 2008;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID WHERE T2.Year_of_Founded > 2008;	orchestra
SELECT DISTINCT Record_Company, COUNT(*) FROM orchestra GROUP BY Record_Company;	orchestra
SELECT Record_Company, COUNT(*) FROM orchestra GROUP BY Record_Company;	orchestra
SELECT Major_Record_Format FROM orchestra GROUP BY Major_Record_Format ORDER BY COUNT(*) ASC;	orchestra
SELECT Major_Record_Format FROM orchestra GROUP BY Major_Record_Format;	orchestra
SELECT Record_Company FROM orchestra GROUP BY Record_Company ORDER BY COUNT(*) DESC LIMIT 1;	orchestra
SELECT Record_Company FROM orchestra GROUP BY Record_Company ORDER BY COUNT(*) DESC LIMIT 1;	orchestra
SELECT Orchestra FROM orchestra WHERE orchestra_id NOT IN ( SELECT orchestra_id FROM performance);	orchestra
SELECT Orchestra FROM orchestra WHERE orchestra_id NOT IN ( SELECT orchestra_id FROM performance);	orchestra
SELECT Record_Company FROM orchestra WHERE Year_of_Founded < 2003 INTERSECT SELECT Record_Company FROM orchestra WHERE Year_of_Founded > 2003;	orchestra
SELECT T1.Record_Company FROM orchestra AS T1 JOIN orchestra AS T2 ON T1.Record_Company = T2.Record_Company WHERE T1.Year_of_Founded < 2003 INTERSECT SELECT T1.Record_Company FROM orchestra AS T1 JOIN orchestra AS T2 ON T1.Record_Company = T2.Record_Company WHERE T1.Year_of_Founded > 2003;	orchestra
SELECT count(*) FROM orchestra WHERE Major_Record_Format = "CD" OR Major_Record_Format = "DVD";	orchestra
SELECT COUNT(*) FROM orchestra WHERE Major_Record_Format = "CD" OR Major_Record_Format = "DVD";	orchestra
SELECT T2.Year_of_Founded FROM performance AS T1 JOIN orchestra AS T2 ON T1.Orchestra_ID = T2.Orchestra_ID GROUP BY T1.Orchestra_ID HAVING count(*) > 1;	orchestra
SELECT T2.Year_of_Founded FROM performance AS T1 JOIN orchestra AS T2 ON T1.Orchestra_ID = T2.Orchestra_ID GROUP BY T1.Orchestra_ID HAVING count(*) > 1;	orchestra
SELECT count(*) FROM highschooler;	network_1
SELECT count(*) FROM highschooler;	network_1
SELECT name, grade FROM highschooler;	network_1
SELECT name, grade FROM highschooler;	network_1
SELECT DISTINCT grade FROM highschooler;	network_1
SELECT grade FROM highschooler;	network_1
SELECT grade FROM highschooler WHERE name = 'Kyle';	network_1
SELECT grade FROM highschooler WHERE name = 'Kyle';	network_1
SELECT name FROM highschooler WHERE grade = 10;	network_1
SELECT name FROM highschooler WHERE grade = 10;	network_1
SELECT id FROM highschooler WHERE name = 'Kyle';	network_1
SELECT id FROM highschooler WHERE name = 'Kyle';	network_1
SELECT count(*) FROM highschooler WHERE grade = 9 OR grade = 10;	network_1
SELECT count(*) FROM highschooler WHERE grade = 9 OR grade = 10;	network_1
SELECT grade, count(*) FROM highschooler GROUP BY grade;	network_1
SELECT grade, count(*) FROM highschooler GROUP BY grade;	network_1
SELECT grade FROM highschooler GROUP BY grade ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT grade FROM highschooler GROUP BY grade ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT grade FROM highschooler GROUP BY grade HAVING count(*) >= 4;	network_1
SELECT grade FROM highschooler GROUP BY grade HAVING count(*) >= 4;	network_1
SELECT student_id, count(friend_id) FROM friend GROUP BY student_id ;	network_1
SELECT student_id, count(*) FROM friend GROUP BY student_id;	network_1
SELECT T1.name, count(*) FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT T1.name, count(*) FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id HAVING count(*) >= 3;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id HAVING count(*) >= 3;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.friend_id WHERE T2.student_id = ( SELECT id FROM highschooler WHERE name = 'Kyle' );	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.friend_id WHERE T2.student_id = ( SELECT id FROM highschooler WHERE name = 'Kyle' );	network_1
SELECT count(*) FROM friend AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT count(*) FROM friend AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT id FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT id FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT name FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT name FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT T1.id FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id JOIN likes AS T3 ON T1.id = T3.liked_id;	network_1
SELECT id FROM highschooler WHERE id IN ( SELECT student_id FROM friend ) AND id IN ( SELECT liked_id FROM likes );	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id JOIN likes AS T3 ON T1.id = T3.liked_id;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id JOIN likes AS T3 ON T1.id = T3.liked_id;	network_1
SELECT student_id, count(*) FROM likes GROUP BY student_id;	network_1
SELECT student_id, count(*) FROM likes GROUP BY student_id ;	network_1
SELECT T2.name, count(*) FROM likes AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id GROUP BY T1.student_id;	network_1
SELECT T2.name, count(*) FROM likes AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id GROUP BY T1.student_id;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id HAVING count(*) >= 2;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id HAVING count(*) >= 2;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id WHERE T1.grade > 5 GROUP BY T2.student_id HAVING count(*) >= 2;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id WHERE T1.grade > 5 GROUP BY T2.student_id HAVING count(*) >= 2;	network_1
SELECT count(*) FROM likes AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT count(*) FROM likes AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT avg(grade) FROM highschooler WHERE id IN ( SELECT student_id FROM friend );	network_1
SELECT avg(grade) FROM highschooler WHERE id IN ( SELECT student_id FROM friend );	network_1
SELECT min(grade) FROM highschooler EXCEPT SELECT grade FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id;	network_1
SELECT min(grade) FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT state FROM owners INTERSECT SELECT state FROM professionals ;	dog_kennels
SELECT state FROM Owners INTERSECT SELECT state FROM Professionals;	dog_kennels
SELECT avg(T1.age) FROM dogs AS T1 JOIN treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT avg(T1.age) FROM dogs AS T1 JOIN treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.professional_id, T1.last_name, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T1.state = "Indiana" OR T2.treatment_id > 2;	dog_kennels
SELECT professional_id, last_name, cell_number FROM Professionals WHERE state = "Indiana" UNION SELECT professional_id, last_name, cell_number FROM Professionals WHERE professional_id IN ( SELECT professional_id FROM Treatments GROUP BY professional_id HAVING count(*) > 2 );	dog_kennels
SELECT T1.name FROM dogs AS T1 JOIN treatments AS T2 ON T1.dog_id = T2.dog_id GROUP BY T1.name HAVING sum(T2.cost_of_treatment) < 1000;	dog_kennels
SELECT T1.name FROM dogs AS T1 JOIN treatments AS T2 ON T1.dog_id = T2.dog_id GROUP BY T1.name HAVING sum(T2.cost_of_treatment) < 1000;	dog_kennels
SELECT first_name FROM owners UNION SELECT first_name FROM professionals EXCEPT SELECT DISTINCT name FROM dogs;	dog_kennels
SELECT first_name FROM Owners UNION SELECT first_name FROM Professionals EXCEPT SELECT name FROM dogs;	dog_kennels
SELECT professional_id, role_code, email_address FROM professionals WHERE professional_id NOT IN ( SELECT professional_id FROM treatments );	dog_kennels
SELECT professional_id, role_code, email_address FROM professionals WHERE professional_id NOT IN ( SELECT professional_id FROM treatments );	dog_kennels
SELECT T1.owner_id, T1.first_name, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id GROUP BY T1.owner_id ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.first_name, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id GROUP BY T1.owner_id ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.professional_id, T2.role_code, T2.first_name FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT T1.professional_id, T2.role_code, T2.first_name FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT T1.breed_name FROM breeds AS T1 JOIN dogs AS T2 ON T1.breed_code = T2.breed_code GROUP BY T1.breed_name ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T2.breed_name FROM Dogs AS T1 JOIN Breeds AS T2 ON T1.breed_code = T2.breed_code GROUP BY T2.breed_name ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY sum(T3.cost_of_treatment) DESC LIMIT 1;	dog_kennels
SELECT t2.treatment_type_description FROM treatments AS t1 JOIN treatment_types AS t2 ON t1.treatment_type_code = t2.treatment_type_code ORDER BY t1.cost_of_treatment LIMIT 1;	dog_kennels
SELECT T2.treatment_type_description FROM Treatments AS T1 JOIN Treatment_Types AS T2 ON T1.treatment_type_code = T2.treatment_type_code ORDER BY T1.cost_of_treatment LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.zip_code FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY sum(T3.cost_of_treatment) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.zip_code FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY sum(T3.cost_of_treatment) DESC LIMIT 1;	dog_kennels
SELECT T1.professional_id, T2.cell_number FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT T1.professional_id, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT first_name, last_name FROM professionals WHERE professional_id IN ( SELECT professional_id FROM treatments WHERE cost_of_treatment < ( SELECT avg(cost_of_treatment) FROM treatments ) );	dog_kennels
SELECT T1.first_name, T1.last_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.cost_of_treatment < ( SELECT avg(cost_of_treatment) FROM Treatments);	dog_kennels
SELECT T2.date_of_treatment, T1.first_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id;	dog_kennels
SELECT T2.date_of_treatment, T1.first_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id;	dog_kennels
SELECT T1.cost_of_treatment, T2.treatment_type_description FROM Treatments AS T1 JOIN Treatment_Types AS T2 ON T1.treatment_type_code = T2.treatment_type_code;	dog_kennels
SELECT T1.cost_of_treatment, T2.treatment_type_description FROM Treatments AS T1 JOIN Treatment_Types AS T2 ON T1.treatment_type_code = T2.treatment_type_code;	dog_kennels
SELECT T1.first_name, T1.last_name, T2.size_description FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Sizes AS T3 ON T2.size_code = T3.size_code;	dog_kennels
SELECT T1.first_name, T1.last_name, T3.size_description FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Sizes AS T3 ON T2.size_code = T3.size_code;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id;	dog_kennels
SELECT T1.name, T3.date_of_treatment FROM dogs AS T1 JOIN breeds AS T2 ON T1.breed_code = T2.breed_code JOIN treatments AS T3 ON T1.dog_id = T3.dog_id ORDER BY T2.breed_name LIMIT 1;	dog_kennels
SELECT T1.name, T3.date_of_treatment FROM dogs AS T1 JOIN breeds AS T2 ON T1.breed_code = T2.breed_code JOIN treatments AS T3 ON T1.dog_id = T3.dog_id GROUP BY T1.name, T3.date_of_treatment ORDER BY count(*) LIMIT 1;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id WHERE T1.state = "Virginia";	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id WHERE T1.state = "Virginia";	dog_kennels
SELECT T1.date_arrived, T1.date_departed FROM dogs AS T1 JOIN treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.date_arrived, T1.date_departed FROM dogs AS T1 JOIN treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id ORDER BY T2.date_of_birth LIMIT 1;	dog_kennels
SELECT T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id ORDER BY T2.date_of_birth LIMIT 1;	dog_kennels
SELECT email_address FROM Professionals WHERE state = "Hawaii" OR state = "Wisconsin";	dog_kennels
SELECT email_address FROM professionals WHERE state = "Hawaii" OR state = "Wisconsin";	dog_kennels
SELECT date_arrived, date_departed FROM dogs;	dog_kennels
SELECT date_arrived, date_departed FROM dogs;	dog_kennels
SELECT count(DISTINCT dog_id) FROM treatments;	dog_kennels
SELECT count(*) FROM treatments;	dog_kennels
SELECT count(DISTINCT professional_id) FROM treatments;	dog_kennels
SELECT count(DISTINCT professional_id) FROM treatments;	dog_kennels
SELECT role_code, street, city, state FROM Professionals WHERE city LIKE "%West%";	dog_kennels
SELECT role_code, street, city, state FROM Professionals WHERE city LIKE "%West%";	dog_kennels
SELECT first_name, last_name, email_address FROM Owners WHERE state LIKE "%North%";	dog_kennels
SELECT first_name, last_name, email_address FROM Owners WHERE state LIKE "%North%";	dog_kennels
SELECT count(*) FROM dogs WHERE age < ( SELECT avg(age) FROM dogs);	dog_kennels
SELECT count(*) FROM dogs WHERE age < ( SELECT avg(age) FROM dogs );	dog_kennels
SELECT cost_of_treatment FROM Treatments ORDER BY date_of_treatment DESC LIMIT 1;	dog_kennels
SELECT cost_of_treatment FROM treatments ORDER BY date_of_treatment DESC LIMIT 1;	dog_kennels
SELECT count(*) FROM dogs WHERE dog_id NOT IN ( SELECT dog_id FROM treatments );	dog_kennels
SELECT count(*) FROM dogs WHERE dog_id NOT IN ( SELECT dog_id FROM treatments );	dog_kennels
SELECT count(*) FROM owners WHERE owner_id NOT IN ( SELECT owner_id FROM dogs);	dog_kennels
SELECT count(*) FROM owners WHERE owner_id NOT IN ( SELECT owner_id FROM dogs);	dog_kennels
SELECT count(*) FROM professionals WHERE professional_id NOT IN ( SELECT professional_id FROM treatments );	dog_kennels
SELECT count(*) FROM professionals WHERE professional_id NOT IN ( SELECT professional_id FROM treatments );	dog_kennels
SELECT name, age, weight FROM dogs WHERE abandoned_yn = 1;	dog_kennels
SELECT name, age, weight FROM dogs WHERE abandoned_yn = 1;	dog_kennels
SELECT avg(age) FROM dogs;	dog_kennels
SELECT avg(age) FROM dogs;	dog_kennels
SELECT max(age) FROM dogs;	dog_kennels
SELECT max(age) FROM dogs;	dog_kennels
SELECT charge_type, charge_amount FROM Charges;	dog_kennels
SELECT charge_type, charge_amount FROM Charges;	dog_kennels
SELECT max(charge_amount) FROM CHARGES;	dog_kennels
SELECT max(charge_amount) FROM CHARGES;	dog_kennels
SELECT email_address, cell_number, home_phone FROM professionals;	dog_kennels
SELECT email_address, cell_number, home_phone FROM professionals;	dog_kennels
SELECT breed_name, size_description FROM Breeds AS T1 JOIN Dogs AS T2 ON T1.breed_code = T2.breed_code JOIN Sizes AS T3 ON T3.size_code = T2.size_code;	dog_kennels
SELECT DISTINCT breed_name, size_description FROM Breeds AS T1 JOIN Dogs AS T2 ON T1.breed_code = T2.breed_code JOIN Sizes AS T3 ON T3.size_code = T2.size_code;	dog_kennels
SELECT T1.first_name, T3.treatment_type_description FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id JOIN Treatment_Types AS T3 ON T2.treatment_type_code = T3.treatment_type_code;	dog_kennels
SELECT T1.first_name, T3.treatment_type_description FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id JOIN Treatment_Types AS T3 ON T2.treatment_type_code = T3.treatment_type_code;	dog_kennels
SELECT count(*) FROM singer;	singer
SELECT count(*) FROM singer;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions ASC;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions ASC;	singer
SELECT Birth_Year, Citizenship FROM singer;	singer
SELECT Birth_Year, Citizenship FROM singer;	singer
SELECT Name FROM SINGER WHERE Citizenship NOT LIKE 'France';	singer
SELECT Name FROM singer WHERE Citizenship!= 'France';	singer
SELECT Name FROM singer WHERE Birth_Year = 1948 OR Birth_Year = 1949;	singer
SELECT Name FROM singer WHERE Birth_Year = 1948 OR Birth_Year = 1949;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions DESC LIMIT 1;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions DESC LIMIT 1;	singer
SELECT Citizenship, count(*) FROM singer GROUP BY Citizenship;	singer
SELECT Citizenship, COUNT(*) FROM singer GROUP BY Citizenship;	singer
SELECT Citizenship FROM singer GROUP BY Citizenship ORDER BY COUNT(*) DESC LIMIT 1;	singer
SELECT Citizenship FROM singer GROUP BY Citizenship ORDER BY COUNT(*) DESC LIMIT 1;	singer
SELECT Citizenship, max(Net_Worth_Millions) FROM singer GROUP BY Citizenship ;	singer
SELECT Citizenship, MAX(Net_Worth_Millions) FROM singer GROUP BY Citizenship;	singer
SELECT T1.Title, T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID;	singer
SELECT T1.Title, T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID;	singer
SELECT DISTINCT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID WHERE T2.Sales > 300000;	singer
SELECT DISTINCT T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID WHERE T1.Sales > 300000;	singer
SELECT T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Singer_ID HAVING count(*) > 1;	singer
SELECT T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Singer_ID HAVING count(*) > 1;	singer
SELECT T1.Name, sum(T2.Sales) FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name;	singer
SELECT T2.Name, sum(T1.Sales) FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T2.Name;	singer
SELECT Name FROM singer WHERE Singer_ID NOT IN ( SELECT Singer_ID FROM song );	singer
SELECT Name FROM singer WHERE Singer_ID NOT IN ( SELECT Singer_ID FROM song );	singer
SELECT Citizenship FROM singer WHERE Birth_Year < 1945 OR Birth_Year > 1955;	singer
SELECT DISTINCT Citizenship FROM singer WHERE Birth_Year < 1945 INTERSECT SELECT DISTINCT Citizenship FROM singer WHERE Birth_Year > 1955;	singer
SELECT count(DISTINCT feature_id) FROM Other_Available_Features;	real_estate_properties
SELECT T2.feature_type_name FROM Other_Available_Features AS T1 JOIN Ref_Feature_Types AS T2 ON T1.feature_type_code = T2.feature_type_code WHERE T1.feature_name = "AirCon";	real_estate_properties
SELECT T1.property_type_description FROM Ref_Property_Types AS T1 JOIN Properties AS T2 ON T1.property_type_code = T2.property_type_code;	real_estate_properties
SELECT property_name FROM properties WHERE property_type_code = "House" OR property_type_code = "Apartment" AND room_count > 1;	real_estate_properties
