SELECT count(*) FROM singer;	concert_singer
SELECT count(*) FROM singer;	concert_singer
SELECT Name, Country, Age FROM singer ORDER BY Age DESC;	concert_singer
SELECT Name, Country, Age FROM singer ORDER BY Age DESC;	concert_singer
SELECT avg(Age), min(Age), max(Age) FROM singer WHERE Country = 'France';	concert_singer
SELECT avg(Age), min(Age), max(Age) FROM singer WHERE Country = 'France';	concert_singer
SELECT Name, Song_release_year FROM singer ORDER BY Age LIMIT 1;	concert_singer
SELECT Name, Song_release_year FROM singer ORDER BY Age LIMIT 1;	concert_singer
SELECT DISTINCT Country FROM singer WHERE Age > 20;	concert_singer
SELECT DISTINCT Country FROM singer WHERE Age > 20;	concert_singer
SELECT country, COUNT(*) FROM singer GROUP BY country ;	concert_singer
SELECT country, COUNT(*) FROM singer GROUP BY country;	concert_singer
SELECT Song_Name FROM singer WHERE Age > ( SELECT AVG(Age) FROM singer );	concert_singer
SELECT Song_Name FROM singer WHERE Age > ( SELECT AVG(Age) FROM singer );	concert_singer
SELECT LOCATION, NAME FROM stadium WHERE Capacity BETWEEN 5000 AND 10000;	concert_singer
SELECT LOCATION, NAME FROM stadium WHERE Capacity BETWEEN 5000 AND 10000;	concert_singer
SELECT max(Capacity), average FROM stadium;	concert_singer
SELECT avg(Capacity), max(Capacity) FROM stadium;	concert_singer
SELECT Name, Capacity FROM stadium ORDER BY Average DESC LIMIT 1;	concert_singer
SELECT Name, Capacity FROM stadium ORDER BY Average DESC LIMIT 1;	concert_singer
SELECT count(*) FROM concert WHERE YEAR = '2014' OR YEAR = '2015';	concert_singer
SELECT count(*) FROM concert WHERE YEAR = '2014' OR YEAR = '2015';	concert_singer
SELECT T1.name, count(*) FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id GROUP BY T1.stadium_id;	concert_singer
SELECT T1.name, count(*) FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id GROUP BY T1.name;	concert_singer
SELECT T1.name, T1.capacity FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year >= 2014 GROUP BY T1.name, T1.capacity ORDER BY count(*) DESC LIMIT 1;	concert_singer
SELECT T1.name, T1.capacity FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE YEAR > 2013 GROUP BY T1.stadium_id ORDER BY COUNT(*) DESC LIMIT 1;	concert_singer
SELECT YEAR FROM concert GROUP BY YEAR ORDER BY COUNT(concert_ID) DESC LIMIT 1;	concert_singer
SELECT YEAR FROM concert GROUP BY YEAR ORDER BY COUNT(concert_ID) DESC LIMIT 1;	concert_singer
SELECT name FROM stadium WHERE stadium_id NOT IN ( SELECT stadium_id FROM concert );	concert_singer
SELECT name FROM stadium WHERE stadium_id NOT IN ( SELECT stadium_id FROM concert );	concert_singer
SELECT Country FROM singer WHERE Age > 40 INTERSECT SELECT Country FROM singer WHERE Age < 30;	concert_singer
SELECT name FROM stadium EXCEPT SELECT T1.name FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.year = 2014;	concert_singer
SELECT name FROM stadium WHERE stadium_id NOT IN ( SELECT stadium_id FROM concert WHERE YEAR = '2014' );	concert_singer
SELECT T1.concert_Name, T1.theme, count(*) FROM concert AS T1 JOIN singer_in_concert AS T2 ON T1.concert_ID = T2.concert_ID GROUP BY T1.concert_ID;	concert_singer
SELECT T2.concert_Name, T2.theme, count(*) FROM singer_in_concert AS T1 JOIN concert AS T2 ON T1.concert_ID = T2.concert_ID GROUP BY T2.concert_Name, T2.theme;	concert_singer
SELECT T2.name, count(*) FROM singer_in_concert AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T2.name;	concert_singer
SELECT T1.name, count(*) FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.name;	concert_singer
SELECT T1.name FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID JOIN concert AS T3 ON T2.concert_ID = T3.concert_ID WHERE T3.year = '2014';	concert_singer
SELECT T1.name FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID JOIN concert AS T3 ON T2.concert_ID = T3.concert_ID WHERE T3.year = '2014';	concert_singer
SELECT Name, Country FROM singer WHERE Song_Name LIKE '%Hey%';	concert_singer
SELECT Name, Country FROM singer WHERE Song_Name LIKE '%Hey%';	concert_singer
SELECT T1.name, T1.location FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year = 2014 INTERSECT SELECT T1.name, T1.location FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year = 2015;	concert_singer
SELECT T1.name, T1.location FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year = 2014 INTERSECT SELECT T1.name, T1.location FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year = 2015;	concert_singer
SELECT count(*) FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.capacity = ( SELECT max(capacity) FROM stadium);	concert_singer
SELECT count(*) FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.capacity = ( SELECT capacity FROM stadium ORDER BY capacity DESC LIMIT 1 );	concert_singer
SELECT COUNT(*) FROM Pets WHERE weight > 10;	pets_1
SELECT COUNT(*) FROM Pets WHERE weight > 10;	pets_1
SELECT weight FROM Pets WHERE PetType = "dog" AND pet_age = 1;	pets_1
SELECT weight FROM pets WHERE pet_type = 'dog' ORDER BY pet_age LIMIT 1;	pets_1
SELECT max(weight), pettype FROM Pets GROUP BY pettype;	pets_1
SELECT max(weight), pettype FROM Pets GROUP BY pettype;	pets_1
SELECT count(*) FROM has_pet AS T1 JOIN student AS T2 ON T1.stuid = T2.stuid WHERE T2.age > 20;	pets_1
SELECT count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.petID = T3.petID WHERE T1.Age > 20;	pets_1
SELECT count(*) FROM pets AS T1 JOIN Has_pet AS T2 ON T1.petid = T2.petid JOIN Student AS T3 ON T2.stuid = T3.stuid WHERE T3.sex = 'F' AND T1.pettype = 'dog';	pets_1
SELECT count(*) FROM pets AS T1 JOIN Has_pet AS T2 ON T1.petid = T2.petid JOIN Student AS T3 ON T2.StuID = T3.StuID WHERE T3.sex = 'F' AND T1.pettype = 'dog';	pets_1
SELECT count(DISTINCT PetType) FROM Pets;	pets_1
SELECT count(DISTINCT PetType) FROM Pets;	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T3.petid = T2.petid WHERE T3.pettype = 'cat' OR T3.pettype = 'dog';	pets_1
SELECT T1.Fname FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.pet_age = 3 OR T3.pet_age = 2;	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T3.petid = T2.petid WHERE T3.pettype = "cat" AND T3.pettype = "dog";	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T3.petid = T2.petid WHERE T3.pettype = 'cat' INTERSECT SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T3.petid = T2.petid WHERE T3.pettype = 'dog';	pets_1
SELECT major, age FROM student EXCEPT SELECT T1.major, T1.age FROM student AS T1 JOIN has_pet AS T2 ON T1.StuID = T2.StuID JOIN pets AS T3 ON T3.petid = T2.petid WHERE T3.pettype = 'cat';	pets_1
SELECT major, age FROM student EXCEPT SELECT T1.major, T1.age FROM student AS T1 JOIN has_pet AS T2 ON T1.StuID = T2.StuID JOIN pets AS T3 ON T3.petid = T2.petid WHERE T3.pettype = 'cat';	pets_1
SELECT StuID FROM Has_pet EXCEPT SELECT StuID FROM Has_pet AS T1 JOIN Pets AS T2 ON T1.petid = T2.petid WHERE T2.pettype = 'cat';	pets_1
SELECT StuID FROM Has_Pet EXCEPT SELECT T1.StuID FROM Has_Pet AS T1 JOIN Pets AS T2 ON T1.petID = T2.petID WHERE T2.petType = 'cat';	pets_1
SELECT T1.fname, T1.age FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = 'dog' AND T3.pettype!= 'cat';	pets_1
SELECT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pettype = 'dog' AND T3.pettype!= 'cat';	pets_1
SELECT PetType, weight FROM Pets ORDER BY pet_age LIMIT 1;	pets_1
SELECT PetType, weight FROM Pets ORDER BY pet_age LIMIT 1;	pets_1
SELECT PetID, weight FROM Pets WHERE pet_age > 1;	pets_1
SELECT PetID, weight FROM Pets WHERE pet_age > 1;	pets_1
SELECT avg(pet_age), max(pet_age), pettype FROM Pets GROUP BY pettype;	pets_1
SELECT avg(pet_age), max(pet_age), pettype FROM Pets GROUP BY pettype;	pets_1
SELECT PetType, avg(weight) FROM Pets GROUP BY PetType;	pets_1
SELECT PetType, avg(weight) FROM Pets GROUP BY PetType;	pets_1
SELECT T1.fname, T1.age FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid;	pets_1
SELECT DISTINCT T1.Fname, T1.Age FROM student AS T1 JOIN has_pet AS T2 ON T1.StuID = T2.StuID;	pets_1
SELECT T1.petid FROM Has_pet AS T1 JOIN Student AS T2 ON T1.StuID = T2.StuID WHERE T2.lname = 'Smith';	pets_1
SELECT T2.petid FROM student AS T1 JOIN Has_pet AS T2 ON T1.stuid = T2.stuid WHERE T1.lname = 'Smith';	pets_1
SELECT count(*), StuID FROM Has_Pet GROUP BY StuID;	pets_1
SELECT StuID, count(*) FROM Has_Pet GROUP BY StuID;	pets_1
SELECT T1.Fname, T1.Sex FROM Student AS T1 JOIN Has_pet AS T2 ON T1.StuID = T2.StuID GROUP BY T1.StuID HAVING COUNT(*) > 1;	pets_1
SELECT T1.Fname, T1.Sex FROM Student AS T1 JOIN Has_pet AS T2 ON T1.StuID = T2.StuID GROUP BY T1.StuID HAVING COUNT(*) > 1;	pets_1
SELECT T1.lname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T3.petid = T2.petid WHERE T3.pet_age = 3 AND T3.pettype = 'cat';	pets_1
SELECT T1.lname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.pet_age = 3 AND T3.pettype = 'cat';	pets_1
SELECT avg(age) FROM student WHERE StuID NOT IN ( SELECT StuID FROM Has_Pet );	pets_1
SELECT avg(age) FROM student WHERE StuID NOT IN ( SELECT StuID FROM Has_Pet );	pets_1
SELECT COUNT(*) FROM continents;	car_1
SELECT COUNT(*) FROM continents;	car_1
SELECT T1.contid, T1.continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.contid = T2.continent GROUP BY T1.contid, T1.continent;	car_1
SELECT T1.contid, T1.continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.contid = T2.continent GROUP BY T1.contid, T1.continent;	car_1
SELECT count(*) FROM countries;	car_1
SELECT count(*) FROM countries;	car_1
SELECT T1.Maker, T1.id, COUNT(*) FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.Maker GROUP BY T1.id;	car_1
SELECT T1.id, T1.fullname, count(*) FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.maker GROUP BY T1.id;	car_1
SELECT T1.Model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.ModelId = T2.Id ORDER BY Horsepower LIMIT 1;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.Horsepower LIMIT 1;	car_1
SELECT T1.Model FROM car_names AS T1 JOIN cars_data AS T2 ON T1.MakeId = T2.Id WHERE T2.Weight < ( SELECT AVG(Weight) FROM cars_data );	car_1
SELECT T1.Model FROM car_names AS T1 JOIN cars_data AS T2 ON T1.MakeId = T2.Id WHERE T2.Weight < ( SELECT AVG(Weight) FROM cars_data );	car_1
SELECT DISTINCT T1.Maker FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker JOIN cars_data AS T3 ON T2.ModelId = T3.Id WHERE T3.Year = 1970;	car_1
SELECT DISTINCT T1.Maker FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker JOIN cars_data AS T3 ON T2.ModelId = T3.Id WHERE T3.Year = 1970;	car_1
SELECT T1.make, T1.makeid FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.year = 1970;	car_1
SELECT T2.Maker, T1.Year FROM cars_data AS T1 JOIN model_list AS T2 ON T1.Id = T2.ModelId ORDER BY T1.Year LIMIT 1;	car_1
SELECT DISTINCT T1.Model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.ModelId = T2.Id WHERE T2.Year > 1980;	car_1
SELECT DISTINCT T2.Model FROM car_names AS T1 JOIN model_list AS T2 ON T1.Model = T2.Model JOIN cars_data AS T3 ON T3.Id = T1.MakeId WHERE T3.Year > 1980;	car_1
SELECT T1.continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.contid = T2.continent JOIN car_makers AS T3 ON T2.countryid = T3.country GROUP BY T1.continent;	car_1
SELECT T1.continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.contid = T2.continent JOIN car_makers AS T3 ON T2.countryid = T3.country GROUP BY T1.continent;	car_1
SELECT T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country GROUP BY T1.CountryName ORDER BY COUNT(*) DESC LIMIT 1;	car_1
SELECT T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country GROUP BY T1.CountryId ORDER BY COUNT(*) DESC LIMIT 1;	car_1
SELECT count(*), t1.fullname FROM car_makers AS t1 JOIN model_list AS t2 ON t1.id = t2.maker GROUP BY t1.fullname;	car_1
SELECT count(*), T1.id, T1.fullname FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.maker GROUP BY T1.id, T1.fullname;	car_1
SELECT T1.Accelerate FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T2.Make = 'amc hornet sportabout';	car_1
SELECT T1.Accelerate FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T2.Make = 'amc hornet sportabout';	car_1
SELECT count(*) FROM car_makers AS T1 JOIN countries AS T2 ON T1.country = T2.countryid WHERE T2.countryname = 'france';	car_1
SELECT count(*) FROM car_makers AS T1 JOIN countries AS T2 ON T1.country = T2.countryid WHERE T2.countryname = 'france';	car_1
SELECT count(*) FROM car_makers AS t1 JOIN countries AS t2 ON t1.country = t2.countryid WHERE t2.countryname = 'usa';	car_1
SELECT count(*) FROM car_makers AS t1 JOIN countries AS t2 ON t1.country = t2.countryid WHERE t2.countryname = 'usa';	car_1
SELECT AVG(MPG) FROM cars_data WHERE Cylinders = 4;	car_1
SELECT AVG(MPG) FROM cars_data WHERE Cylinders = 4;	car_1
SELECT MIN(Weight) FROM cars_data WHERE Cylinders = 8 AND YEAR = 1974;	car_1
SELECT MIN(Weight) FROM cars_data WHERE Cylinders = 8 AND YEAR = 1974;	car_1
SELECT DISTINCT T1.Maker, T1.Model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.Modelid = T2.Id;	car_1
SELECT DISTINCT T1.Maker, T1.Model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.Modelid = T2.Id;	car_1
SELECT Country, CountryId FROM car_makers GROUP BY Country HAVING COUNT(*) >= 1;	car_1
SELECT T1.CountryName, T1.CountryId FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country ;	car_1
SELECT COUNT(*) FROM cars_data WHERE Horsepower > 150;	car_1
SELECT COUNT(*) FROM cars_data WHERE Horsepower > 150;	car_1
SELECT YEAR, AVG(Weight) FROM cars_data GROUP BY YEAR;	car_1
SELECT AVG(Weight), YEAR FROM cars_data GROUP BY YEAR;	car_1
SELECT T1.countryname FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country WHERE T1.continent = 2 GROUP BY T1.countryname HAVING COUNT(*) >= 3;	car_1
SELECT T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country WHERE T1.Continent = 2 GROUP BY T1.CountryName HAVING COUNT(*) >= 3;	car_1
SELECT max(T1.Horsepower), T2.make FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders = 3;	car_1
SELECT max(T1.Horsepower), T2.make FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders = 3;	car_1
SELECT T1.model FROM model_list AS T1 INNER JOIN cars_data AS T2 ON T1.modelid = T2.id ORDER BY T2.mpg DESC LIMIT 1;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.MPG DESC LIMIT 1;	car_1
SELECT AVG(Horsepower) FROM cars_data WHERE YEAR < 1980;	car_1
SELECT AVG(Horsepower) FROM cars_data WHERE YEAR < 1980;	car_1
SELECT avg(Edispl) FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId JOIN model_list AS T3 ON T2.Model = T3.Model WHERE T3.Model = 'volvo';	car_1
SELECT AVG(T1.Edispl) FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T2.Make = 'volvo';	car_1
SELECT MAX(Accelerate), Cylinders FROM cars_data GROUP BY Cylinders;	car_1
SELECT max(Accelerate), Cylinders FROM cars_data GROUP BY Cylinders;	car_1
SELECT Model FROM car_names GROUP BY Model ORDER BY COUNT(Model) DESC LIMIT 1;	car_1
SELECT T1.Model FROM model_list AS T1 JOIN car_names AS T2 ON T1.Model = T2.Model GROUP BY T1.Model ORDER BY COUNT(*) DESC LIMIT 1;	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 4;	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 4;	car_1
SELECT COUNT(*) FROM cars_data WHERE YEAR = 1980;	car_1
SELECT COUNT(*) FROM cars_data WHERE YEAR = 1980;	car_1
SELECT count(*) FROM model_list AS T1 JOIN car_makers AS T2 ON T1.Maker = T2.Id WHERE T2.FullName = "American Motor Company";	car_1
SELECT count(*) FROM model_list AS T1 JOIN car_makers AS T2 ON T1.Maker = T2.Id WHERE T2.Maker = "amc";	car_1
SELECT T1.FullName, T1.id FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.Maker GROUP BY T1.id HAVING COUNT(*) > 3;	car_1
SELECT T1.Maker, T1.Id FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.Maker HAVING COUNT(*) > 3;	car_1
SELECT DISTINCT T1.Model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.ModelId = T2.Id JOIN car_makers AS T3 ON T1.Maker = T3.Id WHERE T3.FullName = 'General Motors' AND T2.Weight > 3500;	car_1
SELECT DISTINCT T2.Model FROM cars_data AS T1 JOIN model_list AS T2 ON T1.Id = T2.ModelId JOIN car_makers AS T3 ON T2.Maker = T3.Id WHERE T3.Maker = 'general motors' OR T1.Weight > 3500;	car_1
SELECT YEAR FROM cars_data WHERE Weight BETWEEN 3000 AND 4000;	car_1
SELECT YEAR FROM cars_data WHERE Weight < 4000 INTERSECT SELECT YEAR FROM cars_data WHERE Weight > 3000;	car_1
SELECT Horsepower FROM cars_data ORDER BY Accelerate DESC LIMIT 1;	car_1
SELECT Horsepower FROM cars_data ORDER BY Accelerate DESC LIMIT 1;	car_1
SELECT T1.Cylinders FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T2.Model = 'volvo' ORDER BY T1.Accelerate LIMIT 1;	car_1
SELECT T1.Cylinders FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId JOIN model_list AS T3 ON T3.ModelId = T2.MakeId WHERE T3.Maker = 'volvo' ORDER BY T1.Accelerate LIMIT 1;	car_1
SELECT count(*) FROM cars_data WHERE accelerate > ( SELECT accelerate FROM cars_data ORDER BY Horsepower DESC LIMIT 1 );	car_1
SELECT count(*) FROM cars_data WHERE accelerate > ( SELECT accelerate FROM cars_data ORDER BY Horsepower DESC LIMIT 1 );	car_1
SELECT count(*) FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country GROUP BY T1.CountryId HAVING count(*) > 2;	car_1
SELECT count(*) FROM car_makers GROUP BY Country HAVING count(*) > 2;	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 6;	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 6;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders = 4 ORDER BY T1.Horsepower DESC LIMIT 1;	car_1
SELECT T1.Model FROM model_list AS T1 JOIN cars_data AS T2 ON T1.ModelId = T2.Id WHERE T2.Cylinders = 4 ORDER BY T2.Horsepower DESC LIMIT 1;	car_1
SELECT T1.makeid, T1.make FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.Horsepower > ( SELECT MIN(Horsepower) FROM cars_data ) AND T2.Cylinders > 3;	car_1
SELECT T1.makeid, T1.make FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.cylinders < 4 EXCEPT SELECT T1.makeid, T1.make FROM car_names AS T1 JOIN cars_data AS T2 ON T1.makeid = T2.id WHERE T2.horsepower = ( SELECT MIN(horsepower) FROM cars_data );	car_1
SELECT max(MPG) FROM cars_data WHERE Cylinders = 8 AND YEAR < 1980;	car_1
SELECT max(MPG) FROM cars_data WHERE Cylinders = 8 OR YEAR < 1980;	car_1
SELECT T1.Model FROM model_list AS T1 JOIN car_makers AS T2 ON T1.Maker = T2.Id WHERE T1.Weight < 3500 AND T2.Maker!= 'Ford Motor Company';	car_1
SELECT DISTINCT T2.Model FROM cars_data AS T1 JOIN model_list AS T2 ON T1.Id = T2.ModelId JOIN car_makers AS T3 ON T2.Maker = T3.Id WHERE T1.Weight < 3500 AND T3.Maker!= 'Ford Motor Company';	car_1
SELECT CountryName FROM countries EXCEPT SELECT T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country;	car_1
SELECT CountryName FROM countries EXCEPT SELECT T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country;	car_1
SELECT T1.id, T1.maker FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.maker GROUP BY T1.id HAVING count(*) > 3;	car_1
SELECT T1.id, T1.maker FROM car_makers AS T1 JOIN model_list AS T2 ON T1.id = T2.maker GROUP BY T1.id HAVING count(*) > 3;	car_1
SELECT T1.countryid, T1.countryname FROM countries AS T1 JOIN car_makers AS T2 ON T1.countryid = T2.country WHERE T2.maker = 'fiat' GROUP BY T1.countryid HAVING COUNT(*) > 3;	car_1
SELECT countryid, countryname FROM car_makers GROUP BY country HAVING count(*) > 3;	car_1
SELECT Country FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Country FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Abbreviation FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Abbreviation FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Airline, Abbreviation FROM airlines WHERE Country = 'USA';	flight_2
SELECT Airline, Abbreviation FROM airlines WHERE Country = 'USA';	flight_2
SELECT AirportCode, AirportName FROM airports WHERE City = 'Anthony';	flight_2
SELECT AirportCode, AirportName FROM airports WHERE City = 'Anthony';	flight_2
SELECT COUNT(*) FROM airlines;	flight_2
SELECT COUNT(*) FROM airlines;	flight_2
SELECT count(*) FROM airports;	flight_2
SELECT COUNT(*) FROM airports;	flight_2
SELECT COUNT(*) FROM flights;	flight_2
SELECT COUNT(*) FROM flights;	flight_2
SELECT Airline FROM airlines WHERE Abbreviation = 'UAL';	flight_2
SELECT Airline FROM airlines WHERE Abbreviation = 'UAL';	flight_2
SELECT COUNT(*) FROM airlines WHERE Country = 'USA';	flight_2
SELECT COUNT(*) FROM airlines WHERE Country = 'USA';	flight_2
SELECT City, Country FROM airports WHERE AirportName = 'Alton';	flight_2
SELECT City, Country FROM airports WHERE AirportName = 'Alton';	flight_2
SELECT AirportName FROM airports WHERE AirportCode = 'AKO';	flight_2
SELECT AirportName FROM airports WHERE AirportCode = 'AKO';	flight_2
SELECT AirportName FROM airports WHERE City = 'Aberdeen';	flight_2
SELECT AirportName FROM airports WHERE City = 'Aberdeen';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.AirportCode = 'ATO';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.AirportCode = 'ATO';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen';	flight_2
SELECT count(*) FROM airports AS t1 JOIN flights AS t2 ON t1.AirportCode = t2.SourceAirport WHERE t1.City = 'Aberdeen' AND t2.DestAirport = 'ASH';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = "Aberdeen" AND T2.DestAirport = "ASY";	flight_2
SELECT COUNT(*) FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T2.Airline = 'JetBlue Airways';	flight_2
SELECT COUNT(*) FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T2.Airline = 'JetBlue Airways';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T2.AirportCode = 'ASY' AND T1.Airline = 'United Airlines';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T2.AirportCode = 'ASY' AND T1.Airline = 'United Airlines';	flight_2
SELECT COUNT(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T2.AirportCode = 'AHD' AND T1.Airline = 'United Airlines';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.AirportCode = 'AHD' AND T2.Airline = 'UAL';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen' AND T2.Airline = 'United Airlines';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport JOIN airlines AS T3 ON T3.uid = T2.Airline WHERE T3.Airline = "United Airlines" AND T1.City = "Aberdeen";	flight_2
SELECT T1.City FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport GROUP BY T1.City ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T1.City FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport GROUP BY T1.City ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T1.City FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport GROUP BY T1.City ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T1.City FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport GROUP BY T1.City ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T1.AirportCode FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport GROUP BY T1.AirportCode ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T1.AirportCode FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport GROUP BY T1.AirportCode ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT AirportCode FROM airports GROUP BY AirportCode ORDER BY COUNT(*) LIMIT 1;	flight_2
SELECT T1.AirportCode FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport GROUP BY T1.AirportCode ORDER BY COUNT(*) LIMIT 1;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T2.Abbreviation, T2.Country FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Abbreviation, T2.Country ORDER BY COUNT(*) LIMIT 1;	flight_2
SELECT T2.Abbreviation, T2.Country FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Abbreviation, T2.Country ORDER BY COUNT(*) LIMIT 1;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'AHD';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'AHD';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.DestAirport = 'AHD';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.DestAirport = 'AHD';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'APG' INTERSECT SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'CVO';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'APG' INTERSECT SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'CVO';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'CVO' EXCEPT SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'APG';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'CVO' EXCEPT SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline WHERE T2.SourceAirport = 'APG';	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline HAVING COUNT(*) >= 10;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline HAVING COUNT(*) >= 10;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline HAVING COUNT(T2.FlightNo) < 200;	flight_2
SELECT T1.Airline FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Airline HAVING COUNT(T2.FlightNo) < 200;	flight_2
SELECT T1.FlightNo FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T2.Airline = 'United Airlines';	flight_2
SELECT FlightNo FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T2.Airline = 'United Airlines';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT DISTINCT T2.FlightNo FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.AirportCode = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT T1.FlightNo FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T2.City = "Aberdeen ";	flight_2
SELECT T2.FlightNo FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen';	flight_2
SELECT T1.FlightNo FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T2.City = "Aberdeen";	flight_2
SELECT T2.FlightNo FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = 'Aberdeen' OR T1.City = 'Abilene';	flight_2
SELECT count(*) FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport WHERE T1.City = "Aberdeen " OR T1.City = "Abilene ";	flight_2
SELECT AirportName FROM airports EXCEPT SELECT DISTINCT T1.AirportName FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport OR T1.AirportCode = T2.DestAirport;	flight_2
SELECT airportcode FROM airports EXCEPT SELECT T1.AirportCode FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.SourceAirport OR T1.AirportCode = T2.DestAirport;	flight_2
SELECT count(*) FROM employee;	employee_hire_evaluation
SELECT count(*) FROM employee;	employee_hire_evaluation
SELECT Name FROM employee ORDER BY Age ASC;	employee_hire_evaluation
SELECT Name FROM employee ORDER BY Age ASC;	employee_hire_evaluation
SELECT count(*), city FROM employee GROUP BY city;	employee_hire_evaluation
SELECT count(*), City FROM employee GROUP BY City;	employee_hire_evaluation
SELECT City FROM employee WHERE Age < 30 GROUP BY City HAVING COUNT(*) > 1;	employee_hire_evaluation
SELECT city FROM employee WHERE age < 30 GROUP BY city HAVING COUNT(*) > 1;	employee_hire_evaluation
SELECT count(*), LOCATION FROM shop GROUP BY LOCATION;	employee_hire_evaluation
SELECT count(*), LOCATION FROM shop GROUP BY LOCATION;	employee_hire_evaluation
SELECT Manager_name, District FROM shop ORDER BY Number_products DESC LIMIT 1;	employee_hire_evaluation
SELECT Manager_name, District FROM shop ORDER BY Number_products DESC LIMIT 1;	employee_hire_evaluation
SELECT min(Number_products), max(Number_products) FROM shop;	employee_hire_evaluation
SELECT min(Number_products), max(Number_products) FROM shop;	employee_hire_evaluation
SELECT name, LOCATION, district FROM shop ORDER BY number_products DESC;	employee_hire_evaluation
SELECT name, LOCATION, district FROM shop ORDER BY number_products DESC;	employee_hire_evaluation
SELECT Name FROM shop WHERE Number_products > ( SELECT avg(Number_products) FROM shop );	employee_hire_evaluation
SELECT name FROM shop WHERE number_products > ( SELECT avg(number_products) FROM shop );	employee_hire_evaluation
SELECT T1.name FROM employee AS T1 JOIN evaluation AS T2 ON T1.employee_id = T2.employee_id GROUP BY T2.employee_id ORDER BY COUNT(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T1.name FROM employee AS T1 JOIN evaluation AS T2 ON T1.employee_id = T2.employee_id GROUP BY T1.employee_id ORDER BY COUNT(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T1.name FROM employee AS T1 JOIN evaluation AS T2 ON T1.employee_id = T2.employee_id ORDER BY T2.bonus DESC LIMIT 1;	employee_hire_evaluation
SELECT T1.name FROM employee AS T1 JOIN evaluation AS T2 ON T1.employee_id = T2.employee_id ORDER BY T2.bonus DESC LIMIT 1;	employee_hire_evaluation
SELECT name FROM employee WHERE employee_id NOT IN ( SELECT employee_id FROM evaluation );	employee_hire_evaluation
SELECT name FROM employee WHERE employee_id NOT IN ( SELECT employee_id FROM evaluation );	employee_hire_evaluation
SELECT t1.name FROM shop AS t1 JOIN hiring AS t2 ON t1.shop_id = t2.shop_id GROUP BY t1.shop_id ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT t1.name FROM shop AS t1 JOIN hiring AS t2 ON t1.shop_id = t2.shop_id GROUP BY t1.name ORDER BY COUNT(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT name FROM shop WHERE shop_id NOT IN ( SELECT shop_id FROM hiring );	employee_hire_evaluation
SELECT name FROM shop WHERE shop_id NOT IN ( SELECT shop_id FROM hiring );	employee_hire_evaluation
SELECT count(*), T1.name FROM shop AS T1 JOIN hiring AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.name;	employee_hire_evaluation
SELECT count(*), T2.name FROM hiring AS T1 JOIN shop AS T2 ON T1.shop_id = T2.shop_id GROUP BY T2.shop_id;	employee_hire_evaluation
SELECT sum(Bonus) FROM evaluation;	employee_hire_evaluation
SELECT sum(Bonus) FROM evaluation;	employee_hire_evaluation
SELECT * FROM hiring;	employee_hire_evaluation
SELECT * FROM hiring;	employee_hire_evaluation
SELECT district FROM shop WHERE Number_products < 3000 INTERSECT SELECT district FROM shop WHERE Number_products > 10000;	employee_hire_evaluation
SELECT District FROM shop WHERE Number_products < 3000 INTERSECT SELECT District FROM shop WHERE Number_products > 10000;	employee_hire_evaluation
SELECT count(DISTINCT LOCATION) FROM shop;	employee_hire_evaluation
SELECT count(DISTINCT LOCATION) FROM shop;	employee_hire_evaluation
SELECT count(*) FROM Documents;	cre_Doc_Template_Mgt
SELECT count(*) FROM Documents;	cre_Doc_Template_Mgt
SELECT Document_ID, Document_Name, Document_Description FROM Documents;	cre_Doc_Template_Mgt
SELECT Document_ID, Document_Name, Document_Description FROM Documents;	cre_Doc_Template_Mgt
SELECT document_name, template_id FROM documents WHERE document_description LIKE '%w%';	cre_Doc_Template_Mgt
SELECT document_name, template_id FROM documents WHERE document_description LIKE '%w%';	cre_Doc_Template_Mgt
SELECT document_id, template_id, document_description FROM Documents WHERE document_name = "Robbin CV";	cre_Doc_Template_Mgt
SELECT document_id, template_id, document_description FROM Documents WHERE document_name = 'Robbin CV';	cre_Doc_Template_Mgt
SELECT count(DISTINCT template_id) FROM documents;	cre_Doc_Template_Mgt
SELECT count(DISTINCT template_id) FROM Documents;	cre_Doc_Template_Mgt
SELECT count(*) FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id WHERE T1.template_type_code = 'PPT';	cre_Doc_Template_Mgt
SELECT count(*) FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id WHERE T1.template_type_code = 'PPT';	cre_Doc_Template_Mgt
SELECT template_id, count(*) FROM Documents GROUP BY template_id;	cre_Doc_Template_Mgt
SELECT template_id, COUNT(*) FROM Documents GROUP BY template_id;	cre_Doc_Template_Mgt
SELECT T1.template_id, T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY T1.template_id ORDER BY COUNT(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT T1.template_id, T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY T1.template_id ORDER BY COUNT(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_id FROM documents GROUP BY template_id HAVING COUNT(*) > 1;	cre_Doc_Template_Mgt
SELECT template_id FROM documents GROUP BY template_id HAVING COUNT(*) > 1;	cre_Doc_Template_Mgt
SELECT template_id FROM templates EXCEPT SELECT template_id FROM documents;	cre_Doc_Template_Mgt
SELECT template_id FROM templates EXCEPT SELECT template_id FROM documents;	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates;	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates;	cre_Doc_Template_Mgt
SELECT template_id, version_number, template_type_code FROM templates;	cre_Doc_Template_Mgt
SELECT template_id, version_number, template_type_code FROM templates;	cre_Doc_Template_Mgt
SELECT DISTINCT Template_Type_Code FROM Templates;	cre_Doc_Template_Mgt
SELECT DISTINCT Template_Type_Code FROM Ref_Template_Types;	cre_Doc_Template_Mgt
SELECT template_id FROM templates WHERE template_type_code = 'PP' OR template_type_code = 'PPT';	cre_Doc_Template_Mgt
SELECT template_id FROM Templates WHERE template_type_code = 'PP' OR template_type_code = 'PPT';	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates WHERE Template_Type_Code = 'CV';	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates AS T1 JOIN Ref_Template_Types AS T2 ON T1.Template_Type_Code = T2.Template_Type_Code WHERE T2.Template_Type_Description = 'CV';	cre_Doc_Template_Mgt
SELECT Version_Number, Template_Type_Code FROM Templates WHERE Version_Number > 5;	cre_Doc_Template_Mgt
SELECT Version_Number, Template_Type_Code FROM Templates WHERE Version_Number > 5;	cre_Doc_Template_Mgt
SELECT template_type_code, COUNT(*) FROM templates GROUP BY template_type_code;	cre_Doc_Template_Mgt
SELECT template_type_code, COUNT(*) FROM templates GROUP BY template_type_code;	cre_Doc_Template_Mgt
SELECT Template_Type_Code FROM Templates GROUP BY Template_Type_Code ORDER BY COUNT(Template_ID) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT Template_Type_Code FROM Templates GROUP BY Template_Type_Code ORDER BY COUNT(Template_ID) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code HAVING COUNT(*) < 3;	cre_Doc_Template_Mgt
SELECT template_type_code FROM Templates GROUP BY template_type_code HAVING COUNT(*) < 3;	cre_Doc_Template_Mgt
SELECT min(Version_Number), Template_Type_Code FROM Templates;	cre_Doc_Template_Mgt
SELECT min(Version_Number), Template_Type_Code FROM Templates ;	cre_Doc_Template_Mgt
SELECT T1.Template_Type_Code FROM Templates AS T1 INNER JOIN Documents AS T2 ON T1.Template_ID = T2.Template_ID WHERE T2.Document_Name = "Data base";	cre_Doc_Template_Mgt
SELECT T1.Template_Type_Code FROM Templates AS T1 JOIN Documents AS T2 ON T1.Template_ID = T2.Template_ID WHERE T2.Document_Name = 'Data base';	cre_Doc_Template_Mgt
SELECT T1.Document_Name FROM Documents AS T1 JOIN Templates AS T2 ON T1.Template_ID = T2.Template_ID WHERE T2.Template_Type_Code = 'BK';	cre_Doc_Template_Mgt
SELECT T1.Document_Name FROM Documents AS T1 JOIN Templates AS T2 ON T1.Template_ID = T2.Template_ID WHERE T2.Template_Type_Code = 'BK';	cre_Doc_Template_Mgt
SELECT T1.Template_Type_Code, count(*) FROM Templates AS T1 JOIN Documents AS T2 ON T1.Template_ID = T2.Template_ID GROUP BY T1.Template_Type_Code;	cre_Doc_Template_Mgt
SELECT T1.Template_Type_Code, count(*) FROM Templates AS T1 JOIN Documents AS T2 ON T1.Template_ID = T2.Template_ID GROUP BY T1.Template_Type_Code;	cre_Doc_Template_Mgt
SELECT T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY T1.template_type_code ORDER BY COUNT(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code ORDER BY COUNT(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT DISTINCT template_type_code FROM templates EXCEPT SELECT T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id;	cre_Doc_Template_Mgt
SELECT template_type_code FROM Templates EXCEPT SELECT T1.template_type_code FROM Templates AS T1 JOIN Documents AS T2 ON T1.template_id = T2.template_id;	cre_Doc_Template_Mgt
SELECT * FROM Ref_Template_Types;	cre_Doc_Template_Mgt
SELECT template_type_code, template_type_description FROM Ref_Template_Types;	cre_Doc_Template_Mgt
SELECT Template_Type_Description FROM Ref_Template_Types WHERE Template_Type_Code = "AD";	cre_Doc_Template_Mgt
SELECT Template_Type_Description FROM Ref_Template_Types WHERE Template_Type_Code = 'AD';	cre_Doc_Template_Mgt
SELECT Template_Type_Code FROM Ref_Template_Types WHERE Template_Type_Description = 'Book';	cre_Doc_Template_Mgt
SELECT Template_Type_Code FROM Ref_Template_Types WHERE Template_Type_Description = 'Book';	cre_Doc_Template_Mgt
SELECT DISTINCT T1.Template_Type_Description FROM Ref_Template_Types AS T1 JOIN Templates AS T2 ON T1.Template_Type_Code = T2.Template_Type_Code JOIN Documents AS T3 ON T2.Template_ID = T3.Template_ID;	cre_Doc_Template_Mgt
SELECT DISTINCT Document_Description FROM Documents;	cre_Doc_Template_Mgt
SELECT T1.Template_ID FROM Templates AS T1 JOIN Ref_Template_Types AS T2 ON T1.Template_Type_Code = T2.Template_Type_Code WHERE T2.Template_Type_Description = 'Presentation';	cre_Doc_Template_Mgt
SELECT template_id FROM templates AS T1 JOIN ref_template_types AS T2 ON T1.template_type_code = T2.template_type_code WHERE T2.template_type_description = 'Presentation';	cre_Doc_Template_Mgt
SELECT count(*) FROM Paragraphs;	cre_Doc_Template_Mgt
SELECT count(*) FROM Paragraphs;	cre_Doc_Template_Mgt
SELECT count(*) FROM Documents AS T1 JOIN Paragraphs AS T2 ON T1.Document_ID = T2.Document_ID WHERE T1.Document_Name = 'Summer Show';	cre_Doc_Template_Mgt
SELECT count(*) FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T1.document_name = 'Summer Show';	cre_Doc_Template_Mgt
SELECT Other_Details FROM Paragraphs WHERE Paragraph_Text = 'Korea';	cre_Doc_Template_Mgt
SELECT Other_Details FROM Paragraphs WHERE Paragraph_Text = 'Korea';	cre_Doc_Template_Mgt
SELECT T2.paragraph_id, T2.paragraph_text FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T1.document_name = 'Welcome to NY';	cre_Doc_Template_Mgt
SELECT T2.paragraph_id, T2.paragraph_text FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T1.document_name = 'Welcome to NY';	cre_Doc_Template_Mgt
SELECT T2.paragraph_text FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T1.document_name = 'Customer reviews';	cre_Doc_Template_Mgt
SELECT T1.paragraph_text FROM Paragraphs AS T1 JOIN Documents AS T2 ON T1.document_id = T2.document_id WHERE T2.document_name = 'Customer reviews';	cre_Doc_Template_Mgt
SELECT document_id, COUNT(*) FROM paragraphs GROUP BY document_id ORDER BY document_id;	cre_Doc_Template_Mgt
SELECT document_id, COUNT(*) FROM paragraphs GROUP BY document_id;	cre_Doc_Template_Mgt
SELECT document_id, document_name, count(*) FROM documents GROUP BY document_id, document_name;	cre_Doc_Template_Mgt
SELECT T1.document_id, T1.document_name, count(*) FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id GROUP BY T1.document_id;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING COUNT(*) >= 2;	cre_Doc_Template_Mgt
SELECT document_id FROM documents WHERE document_id IN ( SELECT document_id FROM paragraphs GROUP BY document_id HAVING COUNT(*) >= 2 );	cre_Doc_Template_Mgt
SELECT document_id, document_name FROM Documents ORDER BY document_id DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT T1.document_id, T1.document_name FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id GROUP BY T1.document_id ORDER BY COUNT(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT Document_ID FROM Paragraphs GROUP BY Document_ID ORDER BY count(*) LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id ORDER BY count(*) LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) BETWEEN 1 AND 2;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) BETWEEN 1 AND 2;	cre_Doc_Template_Mgt
SELECT T1.document_id FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T2.paragraph_text = 'Brazil' OR T2.paragraph_text = 'Ireland';	cre_Doc_Template_Mgt
SELECT T1.document_id FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T2.paragraph_text = 'Brazil' OR T2.paragraph_text = 'Ireland';	cre_Doc_Template_Mgt
SELECT count(*) FROM teacher;	course_teach
SELECT COUNT(*) FROM teacher;	course_teach
SELECT Name FROM teacher ORDER BY Age ASC;	course_teach
SELECT Name FROM teacher ORDER BY Age ASC;	course_teach
SELECT Age, Hometown FROM teacher;	course_teach
SELECT Age, Hometown FROM teacher;	course_teach
SELECT Name FROM teacher WHERE Hometown!= 'Little Lever Urban District';	course_teach
SELECT Name FROM teacher WHERE Hometown!= 'Little Lever Urban District';	course_teach
SELECT Name FROM teacher WHERE Age = 32 OR Age = 33;	course_teach
SELECT Name FROM teacher WHERE Age = 32 OR Age = 33;	course_teach
SELECT Hometown FROM teacher ORDER BY Age LIMIT 1;	course_teach
SELECT Hometown FROM teacher ORDER BY Age LIMIT 1;	course_teach
SELECT Hometown, count(*) FROM teacher GROUP BY Hometown;	course_teach
SELECT Hometown, COUNT(*) FROM teacher GROUP BY Hometown;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown ORDER BY COUNT(Hometown) DESC LIMIT 1;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown ORDER BY COUNT(Hometown) DESC LIMIT 1;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown HAVING COUNT(*) >= 2;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown HAVING COUNT(*) >= 2;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID ORDER BY T1.Name ASC;	course_teach
SELECT T1.Name, T3.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID ORDER BY T1.Name ASC;	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID WHERE T3.Course = 'Math';	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID WHERE T3.Course = 'Math';	course_teach
SELECT T1.Name, COUNT(*) FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T1.Name;	course_teach
SELECT T2.Name, count(*) FROM course_arrange AS T1 JOIN teacher AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T2.Name;	course_teach
SELECT T2.Name FROM course_arrange AS T1 JOIN teacher AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T2.Name HAVING COUNT(T1.Course_ID) >= 2;	course_teach
SELECT T2.Name FROM course_arrange AS T1 JOIN teacher AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T2.Name HAVING COUNT(T1.Course_ID) >= 2;	course_teach
SELECT Name FROM teacher EXCEPT SELECT T2.Name FROM course_arrange AS T1 JOIN teacher AS T2 ON T1.Teacher_ID = T2.Teacher_ID;	course_teach
SELECT Name FROM teacher EXCEPT SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID;	course_teach
SELECT count(*) FROM visitor WHERE Age < 30;	museum_visit
SELECT Name FROM visitor WHERE Level_of_membership > 4 ORDER BY Level_of_membership DESC;	museum_visit
SELECT avg(Age) FROM visitor WHERE Level_of_membership <= 4;	museum_visit
SELECT Name, Level_of_membership FROM visitor WHERE Level_of_membership > 4 ORDER BY Age DESC;	museum_visit
SELECT Museum_ID, Name FROM museum ORDER BY Num_of_Staff DESC LIMIT 1;	museum_visit
SELECT avg(Num_of_Staff) FROM museum WHERE Open_Year < 2009;	museum_visit
SELECT Open_Year, Num_of_Staff FROM museum WHERE Name = 'Plaza Museum';	museum_visit
SELECT Name FROM museum WHERE num_of_staff > ( SELECT min(num_of_staff) FROM museum WHERE open_year > 2010 );	museum_visit
SELECT T1.ID, T1.Name, T1.Age FROM visitor AS T1 JOIN visit AS T2 ON T1.ID = T2.visitor_ID GROUP BY T1.ID HAVING COUNT(*) > 1;	museum_visit
SELECT T1.id, T1.name, T1.level_of_membership FROM VISITOR AS T1 JOIN VISIT AS T2 ON T1.id = T2.visitor_id ORDER BY T2.total_spent DESC LIMIT 1;	museum_visit
SELECT T1.Museum_ID, T1.Name FROM museum AS T1 JOIN visit AS T2 ON T1.Museum_ID = T2.Museum_ID GROUP BY T1.Museum_ID ORDER BY COUNT(*) DESC LIMIT 1;	museum_visit
SELECT name FROM museum WHERE museum_id NOT IN ( SELECT museum_id FROM visit );	museum_visit
SELECT T1.name, T1.age FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id ORDER BY T2.num_of_ticket DESC LIMIT 1;	museum_visit
SELECT avg(Num_of_Ticket), max(Num_of_Ticket) FROM visit;	museum_visit
SELECT sum(T1.Total_spent) FROM visit AS T1 JOIN visitor AS T2 ON T1.visitor_ID = T2.ID WHERE T2.Level_of_membership = 1;	museum_visit
SELECT T1.name FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id JOIN museum AS T3 ON T2.museum_id = T3.museum_id WHERE T3.open_year < 2009 INTERSECT SELECT T1.name FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id JOIN museum AS T3 ON T2.museum_id = T3.museum_id WHERE T3.open_year > 2011;	museum_visit
SELECT count(*) FROM visitor WHERE ID NOT IN ( SELECT T1.visitor_ID FROM visit AS T1 JOIN museum AS T2 ON T1.Museum_ID = T2.Museum_ID WHERE T2.Open_Year > 2010 );	museum_visit
SELECT count(*) FROM museum WHERE open_year > 2013 OR open_year < 2008;	museum_visit
SELECT count(*) FROM players;	wta_1
SELECT count(*) FROM players;	wta_1
SELECT count(*) FROM matches;	wta_1
SELECT COUNT(*) FROM matches;	wta_1
SELECT first_name, birth_date FROM players WHERE country_code = 'USA';	wta_1
SELECT first_name, birth_date FROM players WHERE country_code = 'USA';	wta_1
SELECT avg(T1.loser_age), avg(T1.winner_age) FROM matches AS T1 JOIN players AS T2 ON T1.loser_id = T2.player_id ;	wta_1
SELECT avg(T1.loser_age), avg(T1.winner_age) FROM matches AS T1 JOIN players AS T2 ON T1.loser_id = T2.player_id;	wta_1
SELECT avg(T2.ranking) FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id;	wta_1
SELECT avg(T2.ranking) FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id;	wta_1
SELECT max(T1.loser_rank) FROM matches AS T1 JOIN players AS T2 ON T1.loser_id = T2.player_id;	wta_1
SELECT min(loser_rank) FROM matches;	wta_1
SELECT COUNT(DISTINCT country_code) FROM players;	wta_1
SELECT count(DISTINCT country_code) FROM players;	wta_1
SELECT COUNT(DISTINCT loser_name) FROM matches;	wta_1
SELECT COUNT(DISTINCT loser_name) FROM matches;	wta_1
SELECT tourney_name FROM matches GROUP BY tourney_name HAVING COUNT(*) > 10;	wta_1
SELECT tourney_name FROM matches GROUP BY tourney_name HAVING COUNT(tourney_name) > 10;	wta_1
SELECT winner_name FROM matches WHERE YEAR = 2013 INTERSECT SELECT winner_name FROM matches WHERE YEAR = 2016;	wta_1
SELECT T1.first_name, T1.last_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE strftime('%Y', T2.tourney_date) = '2013' INTERSECT SELECT T1.first_name, T1.last_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE strftime('%Y', T2.tourney_date) = '2016';	wta_1
SELECT COUNT(*) FROM matches WHERE YEAR = 2013 OR YEAR = 2016;	wta_1
SELECT count(*) FROM matches WHERE year = 2013 OR year = 2016;	wta_1
SELECT T1.country_code, T1.first_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = 'WTA Championships' INTERSECT SELECT T1.country_code, T1.first_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = 'Australian Open';	wta_1
SELECT DISTINCT T1.first_name, T1.country_code FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = 'WTA Championships' INTERSECT SELECT DISTINCT T1.first_name, T1.country_code FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = 'Australian Open';	wta_1
SELECT first_name, country_code FROM players ORDER BY birth_date LIMIT 1;	wta_1
SELECT first_name, country_code FROM players ORDER BY birth_date LIMIT 1;	wta_1
SELECT first_name, last_name FROM players ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players WHERE hand = 'L' ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players WHERE hand = 'L' ORDER BY birth_date;	wta_1
SELECT T2.first_name, T2.country_code FROM rankings AS T1 JOIN players AS T2 ON T1.player_id = T2.player_id GROUP BY T1.player_id ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.country_code FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id ORDER BY T2.tours DESC LIMIT 1;	wta_1
SELECT year FROM matches GROUP BY year ORDER BY COUNT(*) DESC LIMIT 1;	wta_1
SELECT year FROM matches GROUP BY year ORDER BY COUNT(*) DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.last_name, T2.winner_rank_points FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id GROUP BY T2.winner_id ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT T1.winner_name, T2.ranking_points FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id GROUP BY T2.player_id ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT T1.winner_name FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T1.tourney_name = 'Australian Open' ORDER BY T1.winner_rank_points DESC LIMIT 1;	wta_1
SELECT T2.winner_name FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T1.tourney_name = "Australian Open";	wta_1
SELECT loser_name, winner_name FROM matches ORDER BY minutes LIMIT 1;	wta_1
SELECT winner_name, loser_name FROM matches ORDER BY minutes DESC LIMIT 1;	wta_1
SELECT avg(T2.ranking), T1.first_name FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT T2.first_name, avg(T1.ranking) FROM rankings AS T1 JOIN players AS T2 ON T1.player_id = T2.player_id GROUP BY T2.first_name;	wta_1
SELECT sum(ranking_points), T1.first_name FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT T2.first_name, sum(T1.ranking_points) FROM rankings AS T1 JOIN players AS T2 ON T1.player_id = T2.player_id GROUP BY T2.first_name;	wta_1
SELECT count(*), country_code FROM players GROUP BY country_code;	wta_1
SELECT count(*), country_code FROM players GROUP BY country_code;	wta_1
SELECT country_code FROM players GROUP BY country_code ORDER BY COUNT(player_id) DESC LIMIT 1;	wta_1
SELECT country_code FROM players GROUP BY country_code ORDER BY COUNT(*) DESC LIMIT 1;	wta_1
SELECT country_code FROM players GROUP BY country_code HAVING COUNT(*) > 50;	wta_1
SELECT country_code FROM players GROUP BY country_code HAVING COUNT(*) > 50;	wta_1
SELECT sum(tours), ranking_date FROM rankings GROUP BY ranking_date;	wta_1
SELECT ranking_date, SUM(tours) FROM rankings GROUP BY ranking_date;	wta_1
SELECT year, COUNT(*) FROM matches GROUP BY year;	wta_1
SELECT year, COUNT(*) FROM matches GROUP BY year;	wta_1
SELECT T1.first_name, T1.last_name, T2.ranking FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id JOIN matches AS T3 ON T1.player_id = T3.winner_id ORDER BY T3.winner_age LIMIT 3;	wta_1
SELECT T2.first_name, T2.last_name, T1.winner_rank FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id ORDER BY T1.winner_age LIMIT 3;	wta_1
SELECT count(DISTINCT winner_name) FROM matches WHERE winner_hand = 'L' AND tourney_name = 'WTA Championships';	wta_1
SELECT count(*) FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T2.hand = 'L' AND T1.tourney_name = 'WTA Championships';	wta_1
SELECT T2.first_name, T2.country_code, T2.birth_date FROM matches AS T1 JOIN players AS T2 ON T1.winner_id = T2.player_id ORDER BY T1.winner_rank_points DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.country_code, T1.birth_date FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id ORDER BY T2.winner_rank_points DESC LIMIT 1;	wta_1
SELECT count(*), hand FROM players GROUP BY hand;	wta_1
SELECT count(*), hand FROM players GROUP BY hand;	wta_1
SELECT COUNT(*) FROM ship WHERE disposition_of_ship = 'Captured';	battle_death
SELECT name, tonnage FROM ship ORDER BY name DESC;	battle_death
SELECT name, date, result FROM battle;	battle_death
SELECT MAX(killed), MIN(killed) FROM death;	battle_death
SELECT AVG(injured) FROM death;	battle_death
SELECT T1.killed, T1.injured FROM death AS T1 JOIN ship AS T2 ON T1.caused_by_ship_id = T2.id WHERE T2.tonnage = 't';	battle_death
SELECT name, result FROM battle WHERE bulgarian_commander!= 'Boril';	battle_death
SELECT DISTINCT T1.id, T1.name FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.ship_type = 'Brig';	battle_death
SELECT T1.id, T1.name FROM battle AS T1 JOIN death AS T2 ON T1.id = T2.caused_by_ship_id WHERE T2.killed > 10;	battle_death
SELECT T1.id, T1.name FROM ship AS T1 JOIN death AS T2 ON T1.id = T2.caused_by_ship_id ORDER BY T2.injured DESC LIMIT 1;	battle_death
SELECT DISTINCT name FROM battle WHERE bulgarian_commander = 'Kaloyan' AND latin_commander = 'Baldwin I';	battle_death
SELECT count(DISTINCT result) FROM battle;	battle_death
SELECT count(*) FROM battle WHERE id NOT IN ( SELECT T1.id FROM ship AS T1 JOIN battle AS T2 ON T1.lost_in_battle = T2.id WHERE T1.tonnage = 225 );	battle_death
SELECT T1.name, T1.date FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.name = 'Lettice' OR T2.name = 'HMS Atalanta';	battle_death
SELECT T1.name, T1.result, T1.bulgarian_commander FROM battle AS T1 LEFT JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.location!= 'English Channel';	battle_death
SELECT note FROM death WHERE note LIKE '%East%';	battle_death
SELECT line_1, line_2 FROM Addresses;	student_transcripts_tracking
SELECT line_1, line_2 FROM Addresses;	student_transcripts_tracking
SELECT count(*) FROM Courses;	student_transcripts_tracking
SELECT count(*) FROM Courses;	student_transcripts_tracking
SELECT course_description FROM Courses WHERE course_name = "math";	student_transcripts_tracking
SELECT course_description FROM Courses WHERE course_name = "math";	student_transcripts_tracking
SELECT zip_postcode FROM Addresses WHERE city = 'Port Chelsea';	student_transcripts_tracking
SELECT zip_postcode FROM Addresses WHERE city = 'Port Chelsea';	student_transcripts_tracking
SELECT T1.department_name, T1.department_id FROM Departments AS T1 JOIN Degree_Programs AS T2 ON T1.department_id = T2.department_id GROUP BY T1.department_id ORDER BY COUNT(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.department_name, T1.department_id FROM departments AS T1 JOIN degree_programs AS T2 ON T1.department_id = T2.department_id GROUP BY T1.department_id ORDER BY COUNT(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT count(DISTINCT department_id) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(DISTINCT department_id) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(DISTINCT degree_summary_name) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(DISTINCT degree_summary_name) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(*) FROM degree_programs AS T1 JOIN departments AS T2 ON T1.department_id = T2.department_id WHERE T2.department_name = 'engineering';	student_transcripts_tracking
SELECT count(*) FROM degree_programs AS T1 JOIN departments AS T2 ON T1.department_id = T2.department_id WHERE T2.department_name = 'engineering';	student_transcripts_tracking
SELECT section_name, section_description FROM Sections;	student_transcripts_tracking
SELECT section_name, section_description FROM Sections;	student_transcripts_tracking
SELECT T1.course_name, T1.course_id FROM Courses AS T1 JOIN Sections AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_id HAVING count(*) <= 2;	student_transcripts_tracking
SELECT T1.course_name, T1.course_id FROM Courses AS T1 JOIN Sections AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_id HAVING count(*) < 2;	student_transcripts_tracking
SELECT section_name FROM Sections ORDER BY section_name DESC;	student_transcripts_tracking
SELECT section_name FROM Sections ORDER BY section_name DESC;	student_transcripts_tracking
SELECT T1.semester_name, T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id GROUP BY T1.semester_name ORDER BY COUNT(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.semester_name, T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id GROUP BY T1.semester_name, T1.semester_id ORDER BY COUNT(T2.student_id) DESC LIMIT 1;	student_transcripts_tracking
SELECT department_description FROM Departments WHERE department_name LIKE "%computer%";	student_transcripts_tracking
SELECT T1.department_description FROM DEPARTMENTS AS T1 JOIN DEGREE_PROGRAMS AS T2 ON T1.department_id = T2.department_id WHERE T1.department_name LIKE '%computer%';	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T1.student_id FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id GROUP BY T1.student_id HAVING COUNT(T3.degree_program_id) = 2;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T1.student_id FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id GROUP BY T1.student_id HAVING COUNT(T3.degree_program_id) = 2;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = 'Bachelor';	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = 'Bachelor';	student_transcripts_tracking
SELECT T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_summary_name ORDER BY COUNT(T2.student_id) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_summary_name ORDER BY COUNT(T2.student_id) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_program_id, T2.degree_summary_name FROM Student_Enrolment AS T1 JOIN Degree_Programs AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_program_id ORDER BY COUNT(T1.student_id) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_program_id, T2.degree_summary_name FROM Student_Enrolment AS T1 JOIN Degree_Programs AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_program_id ORDER BY COUNT(T1.student_id) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.student_id, T1.first_name, T1.middle_name, T1.last_name, count(*) FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.student_id, T1.first_name, T1.middle_name, T1.last_name, count(*) FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT semester_name FROM semesters EXCEPT SELECT T1.semester_name FROM semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id;	student_transcripts_tracking
SELECT semester_name FROM semesters EXCEPT SELECT T2.semester_name FROM student_enrolment AS T1 JOIN semesters AS T2 ON T1.semester_id = T2.semester_id;	student_transcripts_tracking
SELECT T1.course_name FROM Courses AS T1 JOIN Student_Enrolment_Courses AS T2 ON T1.course_id = T2.course_id;	student_transcripts_tracking
SELECT T1.course_name FROM courses AS T1 JOIN student_enrolment_courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name;	student_transcripts_tracking
SELECT T1.course_name FROM courses AS T1 JOIN student_enrolment_courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.course_name FROM COURSES AS T1 JOIN STUDENT_ENROLMENT_COURSES AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name ORDER BY COUNT(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.current_address_id = T2.address_id WHERE T2.state_province_county = "North Carolina" EXCEPT SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id;	student_transcripts_tracking
SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T2.state_province_county = "North Carolina" EXCEPT SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id JOIN Student_Enrolment AS T3 ON T1.student_id = T3.student_id JOIN Degree_Programs AS T4 ON T3.degree_program_id = T4.degree_program_id;	student_transcripts_tracking
SELECT T1.transcript_date, T1.transcript_id FROM Transcripts AS T1 JOIN Transcript_Contents AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id HAVING COUNT(*) >= 2;	student_transcripts_tracking
SELECT T1.transcript_date, T1.transcript_id FROM Transcripts AS T1 JOIN Transcript_Contents AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id HAVING COUNT(*) >= 2;	student_transcripts_tracking
SELECT cell_mobile_number FROM Students WHERE first_name = 'Timmothy' AND last_name = 'Ward';	student_transcripts_tracking
SELECT cell_mobile_number FROM Students WHERE first_name = 'Timmothy' AND last_name = 'Ward';	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY date_left LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT T1.first_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T1.current_address_id!= T1.permanent_address_id;	student_transcripts_tracking
SELECT T1.first_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T1.current_address_id!= T1.permanent_address_id;	student_transcripts_tracking
SELECT T1.address_id, T1.line_1, T1.line_2, T1.line_3 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.current_address_id GROUP BY T1.address_id ORDER BY COUNT(T2.student_id) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.address_id, T1.line_1, T1.line_2 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.permanent_address_id GROUP BY T1.address_id ORDER BY COUNT(T2.student_id) DESC LIMIT 1;	student_transcripts_tracking
SELECT avg(transcript_date) FROM Transcripts;	student_transcripts_tracking
SELECT avg(transcript_date) FROM Transcripts;	student_transcripts_tracking
SELECT transcript_date, other_details FROM Transcripts ORDER BY transcript_date LIMIT 1;	student_transcripts_tracking
SELECT transcript_date, other_details FROM Transcripts ORDER BY transcript_date LIMIT 1;	student_transcripts_tracking
SELECT count(*) FROM Transcripts;	student_transcripts_tracking
SELECT count(*) FROM Transcripts;	student_transcripts_tracking
SELECT transcript_date FROM Transcripts ORDER BY transcript_date DESC LIMIT 1;	student_transcripts_tracking
SELECT transcript_date FROM Transcripts ORDER BY transcript_date DESC LIMIT 1;	student_transcripts_tracking
SELECT count(*), T1.student_course_id FROM Student_Enrolment_Courses AS T1 JOIN Transcript_Contents AS T2 ON T1.student_course_id = T2.student_course_id GROUP BY T1.student_course_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.course_id, count(*) FROM Student_Enrolment_Courses AS T1 JOIN Transcripts AS T2 ON T1.student_enrolment_id = T2.transcript_id GROUP BY T1.course_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.transcript_date, T1.transcript_id FROM Transcripts AS T1 JOIN Transcript_Contents AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id ORDER BY count(*) LIMIT 1;	student_transcripts_tracking
SELECT T1.transcript_date, T1.transcript_id FROM Transcripts AS T1 JOIN Transcript_Contents AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id ORDER BY count(*) LIMIT 1;	student_transcripts_tracking
SELECT T1.semester_name FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = 'Master' INTERSECT SELECT T1.semester_name FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = 'Bachelor';	student_transcripts_tracking
SELECT T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = "Master" INTERSECT SELECT T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = "Bachelor";	student_transcripts_tracking
SELECT count(DISTINCT current_address_id) FROM Students;	student_transcripts_tracking
SELECT DISTINCT T1.line_1, T1.line_2, T1.line_3 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.current_address_id;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY first_name DESC, middle_name DESC, last_name DESC;	student_transcripts_tracking
SELECT other_student_details FROM Students ORDER BY last_name DESC;	student_transcripts_tracking
SELECT section_description FROM Sections WHERE section_name = 'h';	student_transcripts_tracking
SELECT section_description FROM Sections WHERE section_name = 'h';	student_transcripts_tracking
SELECT T1.first_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T2.country = 'Haiti' OR T1.cell_mobile_number = '09700166582';	student_transcripts_tracking
SELECT T1.first_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T2.country = 'Haiti' OR T1.cell_mobile_number = '09700166582';	student_transcripts_tracking
SELECT Title FROM Cartoon ORDER BY Title ASC;	tvshow
SELECT Title FROM Cartoon ORDER BY Title ASC;	tvshow
SELECT title FROM Cartoon WHERE directed_by = 'Ben Jones';	tvshow
SELECT title FROM Cartoon WHERE directed_by = 'Ben Jones';	tvshow
SELECT count(*) FROM Cartoon WHERE Written_by = "Joseph Kuhr";	tvshow
SELECT count(*) FROM Cartoon WHERE Written_by = 'Joseph Kuhr';	tvshow
SELECT Title, Directed_by FROM Cartoon ORDER BY Original_air_date;	tvshow
SELECT Title, Directed_by FROM Cartoon ORDER BY Original_air_date;	tvshow
SELECT Title FROM Cartoon WHERE Directed_by = 'Ben Jones' OR Directed_by = 'Brandon Vietti';	tvshow
SELECT title FROM Cartoon WHERE directed_by = 'Ben Jones' OR directed_by = 'Brandon Vietti';	tvshow
SELECT Country, COUNT(*) FROM TV_Channel GROUP BY Country ORDER BY COUNT(*) DESC LIMIT 1;	tvshow
SELECT Country, count(*) FROM TV_Channel GROUP BY Country ORDER BY count(*) DESC LIMIT 1;	tvshow
SELECT count(DISTINCT series_name), count(DISTINCT Content) FROM TV_Channel;	tvshow
SELECT count(DISTINCT series_name), count(DISTINCT Content) FROM TV_Channel;	tvshow
SELECT Content FROM TV_Channel WHERE series_name = "Sky Radio";	tvshow
SELECT Content FROM TV_Channel WHERE series_name = 'Sky Radio';	tvshow
SELECT Package_Option FROM TV_Channel WHERE series_name = "Sky Radio";	tvshow
SELECT Package_Option FROM TV_Channel WHERE series_name = 'Sky Radio';	tvshow
SELECT count(*) FROM TV_Channel WHERE Language = 'English';	tvshow
SELECT count(*) FROM TV_Channel WHERE Language = 'English';	tvshow
SELECT Language, count(*) FROM TV_Channel GROUP BY Language ORDER BY count(*) LIMIT 1;	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language ORDER BY COUNT(*) LIMIT 1;	tvshow
SELECT Language, count(*) FROM TV_Channel GROUP BY Language;	tvshow
SELECT Language, count(*) FROM TV_Channel GROUP BY Language;	tvshow
SELECT T1.Series_name FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.title = 'The Rise of the Blue Beetle!';	tvshow
SELECT T1.series_name FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.title = 'The Rise of the Blue Beetle!';	tvshow
SELECT T1.Title FROM Cartoon AS T1 JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T2.series_name = "Sky Radio";	tvshow
SELECT T1.title FROM Cartoon AS T1 JOIN TV_Channel AS T2 ON T1.channel = T2.id WHERE T2.series_name = "Sky Radio";	tvshow
SELECT Episode FROM TV_series ORDER BY Rating;	tvshow
SELECT Episode FROM TV_series ORDER BY Rating;	tvshow
SELECT Episode, Rating FROM TV_series ORDER BY Rating DESC LIMIT 3;	tvshow
SELECT Episode, Rating FROM TV_series ORDER BY Rating DESC LIMIT 3;	tvshow
SELECT min(Share), max(Share) FROM TV_series;	tvshow
SELECT MAX(Share), MIN(Share) FROM TV_series;	tvshow
SELECT Air_Date FROM TV_series WHERE Episode = 'A Love of a Lifetime';	tvshow
SELECT Air_Date FROM TV_series WHERE Episode = 'A Love of a Lifetime';	tvshow
SELECT Weekly_Rank FROM TV_series WHERE Episode = 'A Love of a Lifetime';	tvshow
SELECT Weekly_Rank FROM TV_series WHERE Episode = 'A Love of a Lifetime';	tvshow
SELECT T1.Series_name FROM TV_Channel AS T1 JOIN TV_series AS T2 ON T1.id = T2.Channel WHERE T2.Episode = "A Love of a Lifetime";	tvshow
SELECT T1.series_name FROM TV_Channel AS T1 JOIN TV_series AS T2 ON T1.id = T2.Channel WHERE T2.Episode = "A Love of a Lifetime";	tvshow
SELECT T1.Episode FROM TV_series AS T1 JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T2.series_name = "Sky Radio";	tvshow
SELECT T1.Episode FROM TV_series AS T1 JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T2.series_name = "Sky Radio";	tvshow
SELECT count(*), Directed_by FROM Cartoon GROUP BY Directed_by;	tvshow
SELECT count(*), directed_by FROM Cartoon GROUP BY directed_by;	tvshow
SELECT Production_code, Channel FROM Cartoon ORDER BY Original_air_date DESC LIMIT 1;	tvshow
SELECT Production_code, Channel FROM Cartoon ORDER BY Original_air_date DESC LIMIT 1;	tvshow
SELECT Package_Option, series_name FROM TV_Channel WHERE Hight_definition_TV = 'yes';	tvshow
SELECT Package_Option, series_name FROM TV_Channel WHERE Hight_definition_TV = 'yes';	tvshow
SELECT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = 'Todd Casey';	tvshow
SELECT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = "Todd Casey";	tvshow
SELECT Country FROM TV_Channel EXCEPT SELECT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = 'Todd Casey';	tvshow
SELECT Country FROM TV_Channel EXCEPT SELECT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE Written_by = "Todd Casey";	tvshow
SELECT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = "Ben Jones" INTERSECT SELECT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = "Michael Chang";	tvshow
SELECT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = "Ben Jones" INTERSECT SELECT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = "Michael Chang";	tvshow
SELECT Pixel_aspect_ratio_PAR, Country FROM TV_Channel WHERE Language!= 'English';	tvshow
SELECT Pixel_aspect_ratio_PAR, Country FROM TV_Channel WHERE Language!= 'English';	tvshow
SELECT id FROM TV_Channel GROUP BY Country HAVING COUNT(*) > 2;	tvshow
SELECT id FROM TV_Channel GROUP BY id HAVING COUNT(*) > 2;	tvshow
SELECT id FROM TV_Channel WHERE id NOT IN ( SELECT channel FROM Cartoon WHERE directed_by = 'Ben Jones' );	tvshow
SELECT id FROM TV_Channel WHERE id NOT IN ( SELECT channel FROM Cartoon WHERE directed_by = 'Ben Jones' );	tvshow
SELECT Package_Option FROM TV_Channel EXCEPT SELECT T1.Package_Option FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = 'Ben Jones';	tvshow
SELECT Package_Option FROM TV_Channel EXCEPT SELECT T1.Package_Option FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = 'Ben Jones';	tvshow
SELECT count(*) FROM poker_player;	poker_player
SELECT count(*) FROM poker_player;	poker_player
SELECT Earnings FROM poker_player ORDER BY Earnings DESC;	poker_player
SELECT Earnings FROM poker_player ORDER BY Earnings DESC;	poker_player
SELECT Final_Table_Made, Best_Finish FROM poker_player;	poker_player
SELECT Final_Table_Made, Best_Finish FROM poker_player;	poker_player
SELECT AVG(Earnings) FROM poker_player;	poker_player
SELECT AVG(Earnings) FROM poker_player;	poker_player
SELECT Money_Rank FROM poker_player ORDER BY Earnings DESC LIMIT 1;	poker_player
SELECT Money_Rank FROM poker_player ORDER BY Earnings DESC LIMIT 1;	poker_player
SELECT max(Final_Table_Made) FROM poker_player WHERE Earnings < 200000;	poker_player
SELECT max(Final_Table_Made) FROM poker_player WHERE Earnings < 200000;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Earnings > 300000;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T1.Earnings > 300000;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Final_Table_Made ASC;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Final_Table_Made ASC;	poker_player
SELECT T2.Birth_Date FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Earnings LIMIT 1;	poker_player
SELECT T1.Birth_Date FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Earnings LIMIT 1;	poker_player
SELECT T1.Money_Rank FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Height DESC LIMIT 1;	poker_player
SELECT T1.Money_Rank FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Height DESC LIMIT 1;	poker_player
SELECT avg(T1.Earnings) FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Height > 200;	poker_player
SELECT avg(T2.Earnings) FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID WHERE T1.Height > 200;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Earnings DESC;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Earnings DESC;	poker_player
SELECT Nationality, COUNT(*) FROM people GROUP BY Nationality;	poker_player
SELECT Nationality, COUNT(*) FROM people GROUP BY Nationality;	poker_player
SELECT Nationality FROM people GROUP BY Nationality ORDER BY COUNT(Nationality) DESC LIMIT 1;	poker_player
SELECT Nationality FROM people GROUP BY Nationality ORDER BY COUNT(Nationality) DESC LIMIT 1;	poker_player
SELECT Nationality FROM people GROUP BY Nationality HAVING COUNT(*) >= 2;	poker_player
SELECT Nationality FROM people GROUP BY Nationality HAVING COUNT(Nationality) >= 2;	poker_player
SELECT Name, Birth_Date FROM people ORDER BY Name ASC;	poker_player
SELECT Name, Birth_Date FROM people ORDER BY Name;	poker_player
SELECT Name FROM people WHERE Nationality!= "Russia";	poker_player
SELECT Name FROM people WHERE Nationality!= 'Russia';	poker_player
SELECT Name FROM people WHERE People_ID NOT IN ( SELECT People_ID FROM poker_player );	poker_player
SELECT Name FROM people WHERE People_ID NOT IN ( SELECT People_ID FROM poker_player );	poker_player
SELECT COUNT(DISTINCT Nationality) FROM people;	poker_player
SELECT COUNT(DISTINCT Nationality) FROM people;	poker_player
SELECT count(*) FROM AREA_CODE_STATE;	voter_1
SELECT contestant_number, contestant_name FROM CONTESTANTS ORDER BY contestant_name DESC;	voter_1
SELECT vote_id, phone_number, state FROM VOTES;	voter_1
SELECT max(area_code), min(area_code) FROM AREA_CODE_STATE;	voter_1
SELECT max(created) FROM VOTES WHERE state = 'CA';	voter_1
SELECT contestant_name FROM contestants WHERE contestant_name!= 'Jessie Alloway';	voter_1
SELECT DISTINCT state, created FROM VOTES;	voter_1
SELECT T1.contestant_number, T1.contestant_name FROM CONTESTANTS AS T1 JOIN VOTES AS T2 ON T1.contestant_number = T2.contestant_number GROUP BY T1.contestant_number HAVING COUNT(*) >= 2;	voter_1
SELECT T1.contestant_number, T2.contestant_name FROM VOTES AS T1 JOIN CONTESTANTS AS T2 ON T1.contestant_number = T2.contestant_number GROUP BY T1.contestant_number ORDER BY count(*) LIMIT 1;	voter_1
SELECT count(*) FROM VOTES WHERE state = 'NY' OR state = 'CA';	voter_1
SELECT count(*) FROM CONTESTANTS WHERE contestant_number NOT IN ( SELECT contestant_number FROM VOTES );	voter_1
SELECT T1.area_code FROM AREA_CODE_STATE AS T1 JOIN VOTES AS T2 ON T1.state = T2.state GROUP BY T1.area_code ORDER BY COUNT(*) DESC LIMIT 1;	voter_1
SELECT T1.created, T1.state, T1.phone_number FROM VOTES AS T1 JOIN CONTESTANTS AS T2 ON T1.contestant_number = T2.contestant_number WHERE T2.contestant_name = 'Tabatha Gehling';	voter_1
SELECT T1.area_code FROM AREA_CODE_STATE AS T1 JOIN VOTES AS T2 ON T1.state = T2.state WHERE T2.contestant_number = 2 INTERSECT SELECT T1.area_code FROM AREA_CODE_STATE AS T1 JOIN VOTES AS T2 ON T1.state = T2.state WHERE T2.contestant_number = 3;	voter_1
SELECT contestant_name FROM contestants WHERE contestant_name LIKE '%Al%';	voter_1
SELECT Name FROM country WHERE IndepYear > 1950;	world_1
SELECT Name FROM country WHERE IndepYear > 1950;	world_1
SELECT count(*) FROM country WHERE GovernmentForm = 'Republic';	world_1
SELECT count(*) FROM country WHERE GovernmentForm = 'Republic';	world_1
SELECT sum(SurfaceArea) FROM country WHERE Region = 'Caribbean';	world_1
SELECT sum(SurfaceArea) FROM country WHERE Region = 'Caribbean';	world_1
SELECT T1.Continent FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T2.Name = 'The Valley';	world_1
SELECT T1.Continent FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T2.Name = 'The Valley';	world_1
SELECT T2.Region FROM city AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Name = 'Kabul';	world_1
SELECT T2.Region FROM city AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Name = 'Kabul';	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = 'Aruba' ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = "Aruba" ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT Population, LifeExpectancy FROM country WHERE Name = 'Brazil';	world_1
SELECT Population, LifeExpectancy FROM country WHERE Name = 'Brazil';	world_1
SELECT Region, Population FROM country WHERE Name = 'Angola';	world_1
SELECT Region, Population FROM country WHERE Name = 'Angola';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Region = 'Central Africa';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Region = 'Central Africa';	world_1
SELECT name FROM country WHERE continent = 'Asia' ORDER BY LifeExpectancy LIMIT 1;	world_1
SELECT Name FROM country WHERE Continent = 'Asia' ORDER BY LifeExpectancy LIMIT 1;	world_1
SELECT sum(Population), max(GNP) FROM country WHERE continent = 'Asia';	world_1
SELECT continent, max(gnp) FROM country WHERE continent = 'Asia';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Continent = 'Africa' AND GovernmentForm = 'Republic';	world_1
SELECT avg(LifeExpectancy) FROM country WHERE Continent = 'Africa' AND GovernmentForm = 'Republic';	world_1
SELECT sum(surfacearea) FROM country WHERE continent = 'Asia' OR continent = 'Europe';	world_1
SELECT sum(SurfaceArea) FROM country WHERE Continent = 'Asia' OR Continent = 'Europe';	world_1
SELECT sum(Population) FROM city WHERE District = 'Gelderland';	world_1
SELECT sum(Population) FROM city WHERE District = 'Gelderland';	world_1
SELECT avg(GNP), sum(Population) FROM country WHERE GovernmentForm = 'US Territory';	world_1
SELECT avg(GNP), sum(Population) FROM country WHERE GovernmentForm = 'US Territory';	world_1
SELECT COUNT(DISTINCT Language) FROM countrylanguage;	world_1
SELECT COUNT(DISTINCT Language) FROM countrylanguage;	world_1
SELECT count(DISTINCT GovernmentForm) FROM country WHERE Continent = 'Africa';	world_1
SELECT count(DISTINCT GovernmentForm) FROM country WHERE Continent = 'Africa';	world_1
SELECT sum(T2.Percentage) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = 'Aruba';	world_1
SELECT count(DISTINCT T2.Language) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = 'Aruba';	world_1
SELECT count(*) FROM countrylanguage WHERE CountryCode = 'AFG' AND IsOfficial = 'T';	world_1
SELECT count(*) FROM countrylanguage WHERE CountryCode = 'AFG' AND IsOfficial = 'T';	world_1
SELECT T1.name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.code = T2.countrycode GROUP BY T1.name ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Name ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT T1.Continent FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Continent ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT T1.Continent FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Continent ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT count(*) FROM countrylanguage WHERE Language = 'English' ;	world_1
SELECT count(*) FROM countrylanguage WHERE Language = 'English' OR Language = 'Dutch';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' INTERSECT SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'French';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' INTERSECT SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'French';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' INTERSECT SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'French';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' AND T2.IsOfficial = 'T' INTERSECT SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'French' AND T2.IsOfficial = 'T';	world_1
SELECT count(DISTINCT T1.continent) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.code = T2.countrycode WHERE T2.language = 'Chinese';	world_1
SELECT count(*) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Chinese';	world_1
SELECT T1.Region FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch';	world_1
SELECT T1.Region FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Dutch' OR T2.Language = 'English';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch';	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia' GROUP BY T2.Language ORDER BY count(*) DESC LIMIT 1;	world_1
SELECT T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia' GROUP BY T2.Language ORDER BY COUNT(T1.Code) DESC LIMIT 1;	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.GovernmentForm = 'Republic' GROUP BY T1.Language HAVING COUNT(T1.CountryCode) = 1;	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.GovernmentForm = 'Republic' GROUP BY T1.Language HAVING COUNT(T1.CountryCode) = 1;	world_1
SELECT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode WHERE T2.Language = 'English' ORDER BY T1.Population DESC LIMIT 1;	world_1
SELECT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode WHERE T2.Language = 'English' ORDER BY T1.Population DESC LIMIT 1;	world_1
SELECT T1.Name, T1.Population, T1.LifeExpectancy FROM country AS T1 JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia' ORDER BY T1.SurfaceArea DESC LIMIT 1;	world_1
SELECT name, population, lifeexpectancy FROM country WHERE continent = 'Asia' ORDER BY surfacearea DESC LIMIT 1;	world_1
SELECT avg(T1.LifeExpectancy) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' AND T2.IsOfficial = 'F';	world_1
SELECT avg(T1.LifeExpectancy) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' AND T2.IsOfficial = 'F';	world_1
SELECT sum(t1.population) FROM city AS t1 JOIN country AS t2 ON t1.countrycode = t2.code EXCEPT SELECT sum(t1.population) FROM city AS t1 JOIN country AS t2 ON t1.countrycode = t2.code WHERE t2.name = 'United States';	world_1
SELECT sum(t1.population) FROM country AS t1 JOIN city AS t2 ON t1.code = t2.countrycode EXCEPT SELECT sum(t1.population) FROM country AS t1 JOIN city AS t2 ON t1.code = t2.countrycode WHERE t1.name = 'United States';	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.HeadOfState = 'Beatrix' AND T1.IsOfficial = 'T';	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.HeadOfState = 'Beatrix' AND T1.IsOfficial = 'T';	world_1
SELECT count(DISTINCT T2.language) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.code = T2.countrycode WHERE T1.indepyear < 1930 AND T2.isofficial = 'T';	world_1
SELECT count(DISTINCT T1.Language) FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.IndepYear < 1930 AND T1.IsOfficial = 'T';	world_1
SELECT name FROM country WHERE surfacearea > ( SELECT MIN(surfacearea) FROM country WHERE continent = 'Europe' );	world_1
SELECT name FROM country WHERE surfacearea > ( SELECT MIN(surfacearea) FROM country WHERE continent = 'Europe' );	world_1
SELECT name FROM country WHERE continent = 'Africa' AND population < ( SELECT max(population) FROM country WHERE continent = 'Asia' );	world_1
SELECT name FROM country WHERE continent = 'Africa' AND population < ( SELECT min(population) FROM country WHERE continent = 'Asia' );	world_1
SELECT name FROM country WHERE continent = 'Asia' AND population > ( SELECT max(population) FROM country WHERE continent = 'Africa' );	world_1
SELECT name FROM country WHERE continent = 'Asia' AND population > ( SELECT min(population) FROM country WHERE continent = 'Africa' );	world_1
SELECT Code FROM country WHERE Code NOT IN ( SELECT Code FROM countrylanguage WHERE Language = 'English' );	world_1
SELECT Code FROM country WHERE Code NOT IN ( SELECT Code FROM countrylanguage WHERE Language = 'English' );	world_1
SELECT DISTINCT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language!= 'English';	world_1
SELECT T1.code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.code = T2.countrycode WHERE T2.language!= 'English';	world_1
SELECT code FROM country WHERE governmentform!= 'Republic' AND code NOT IN ( SELECT T1.code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.code = T2.countrycode WHERE language = 'English' );	world_1
SELECT code FROM country WHERE governmentform!= 'Republic' AND code NOT IN ( SELECT countrycode FROM countrylanguage WHERE language = 'English' );	world_1
SELECT T1.Name FROM city AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Continent = 'Europe' EXCEPT	world_1
SELECT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode WHERE T2.Language = 'English' AND T2.IsOfficial = 'F';	world_1
SELECT DISTINCT T1.name FROM city AS T1 JOIN country AS T2 ON T1.countrycode = T2.code JOIN countrylanguage AS T3 ON T2.code = T3.countrycode WHERE T3.language = 'Chinese' AND T2.continent = 'Asia';	world_1
SELECT DISTINCT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode WHERE T2.Language = 'Chinese' AND T1.Continent = 'Asia';	world_1
SELECT name, indepyear, surfacearea FROM country ORDER BY population LIMIT 1;	world_1
SELECT name, indepyear, surfacearea FROM country ORDER BY population LIMIT 1;	world_1
SELECT Population, Name, HeadOfState FROM country ORDER BY SurfaceArea DESC LIMIT 1;	world_1
SELECT name, population, headofstate FROM country ORDER BY surfacearea DESC LIMIT 1;	world_1
SELECT T1.Name, count(*) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Code HAVING count(*) >= 3;	world_1
SELECT t1.name, count(*) FROM country AS t1 JOIN countrylanguage AS t2 ON t1.code = t2.countrycode GROUP BY t1.name HAVING count(*) > 2;	world_1
SELECT count(*), district FROM city WHERE population > ( SELECT avg(population) FROM city ) GROUP BY district;	world_1
SELECT district, count(*) FROM city GROUP BY district ;	world_1
SELECT governmentform, sum(Population) FROM country GROUP BY governmentform HAVING avg(LifeExpectancy) > 72;	world_1
SELECT GovernmentForm, sum(Population) FROM country WHERE LifeExpectancy > 72 GROUP BY GovernmentForm;	world_1
SELECT continent, avg(lifeexpectancy), sum(population) FROM country WHERE lifeexpectancy < 72 GROUP BY continent;	world_1
SELECT continent, sum(Population), avg(LifeExpectancy) FROM country WHERE LifeExpectancy < 72 GROUP BY continent;	world_1
SELECT Name, SurfaceArea FROM country ORDER BY SurfaceArea DESC LIMIT 5;	world_1
SELECT Name, SurfaceArea FROM country ORDER BY SurfaceArea DESC LIMIT 5;	world_1
SELECT name FROM country ORDER BY population DESC LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population DESC LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population LIMIT 3;	world_1
SELECT count(*) FROM country WHERE continent = 'Asia';	world_1
SELECT count(*) FROM country WHERE continent = 'Asia';	world_1
SELECT Name FROM country WHERE Continent = 'Europe' AND Population = 80000;	world_1
SELECT name FROM country WHERE continent = 'Europe' AND population = 80000;	world_1
SELECT sum(Population), avg(surfacearea) FROM country WHERE continent = 'North America' AND surfacearea > 3000;	world_1
SELECT sum(Population), avg(surfacearea) FROM country WHERE continent = 'North America' AND surfacearea > 3000;	world_1
SELECT Name FROM city WHERE Population BETWEEN 160000 AND 900000;	world_1
SELECT Name FROM city WHERE Population BETWEEN 160000 AND 900000;	world_1
SELECT Language FROM countrylanguage ORDER BY Percentage DESC LIMIT 1;	world_1
SELECT Language FROM countrylanguage GROUP BY Language ORDER BY COUNT(DISTINCT CountryCode) DESC LIMIT 1;	world_1
SELECT T1.Name, T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT t1.code, t2.language FROM country AS t1 JOIN countrylanguage AS t2 ON t1.code = t2.countrycode ORDER BY t2.percentage DESC;	world_1
SELECT count(*) FROM countrylanguage WHERE language = 'Spanish' ;	world_1
SELECT count(*) FROM countrylanguage WHERE Language = 'Spanish' AND IsOfficial = 'T';	world_1
SELECT T1.code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.code = T2.countrycode WHERE T2.language = 'Spanish' ORDER BY T2.percentage DESC LIMIT 1;	world_1
SELECT CountryCode FROM countrylanguage WHERE Language = 'Spanish' AND IsOfficial = 'T';	world_1
SELECT count(*) FROM conductor;	orchestra
SELECT count(*) FROM conductor;	orchestra
SELECT Name FROM conductor ORDER BY Age ASC;	orchestra
SELECT Name FROM conductor ORDER BY Age;	orchestra
SELECT Name FROM conductor WHERE Nationality!= "USA";	orchestra
SELECT Name FROM conductor WHERE Nationality!= "USA";	orchestra
SELECT record_company FROM orchestra ORDER BY year_of_founded DESC;	orchestra
SELECT record_company FROM orchestra ORDER BY year_of_founded DESC;	orchestra
SELECT avg(Attendance) FROM show;	orchestra
SELECT avg(Attendance) FROM show;	orchestra
SELECT max(Official_ratings_(millions)), min(Official_ratings_(millions)) FROM performance WHERE Type!= "Live final";	orchestra
SELECT max(share), min(share) FROM performance WHERE TYPE!= "Live final";	orchestra
SELECT count(DISTINCT Nationality) FROM conductor;	orchestra
SELECT count(DISTINCT Nationality) FROM conductor;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC;	orchestra
SELECT name FROM conductor ORDER BY Year_of_Work DESC;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC LIMIT 1;	orchestra
SELECT name FROM conductor ORDER BY year_of_work DESC LIMIT 1;	orchestra
SELECT T1.name, T2.orchestra FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID;	orchestra
SELECT T1.Name, T2.Orchestra FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Name HAVING COUNT(*) > 1;	orchestra
SELECT T1.name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.name HAVING COUNT(*) > 1;	orchestra
SELECT T1.name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T2.Conductor_ID ORDER BY COUNT(*) DESC LIMIT 1;	orchestra
SELECT T1.name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Conductor_ID ORDER BY COUNT(*) DESC LIMIT 1;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID WHERE T2.Year_of_Founded > 2008;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID WHERE T2.Year_of_Founded > 2008;	orchestra
SELECT Record_Company, COUNT(*) FROM orchestra GROUP BY Record_Company;	orchestra
SELECT record_company, COUNT(*) FROM orchestra GROUP BY record_company;	orchestra
SELECT Major_Record_Format FROM orchestra GROUP BY Major_Record_Format ORDER BY COUNT(*) ASC;	orchestra
SELECT Major_Record_Format FROM orchestra GROUP BY Major_Record_Format ORDER BY count(*) DESC;	orchestra
SELECT Record_Company FROM orchestra GROUP BY Record_Company ORDER BY COUNT(Record_Company) DESC LIMIT 1;	orchestra
SELECT Record_Company FROM orchestra GROUP BY Record_Company ORDER BY COUNT(Record_Company) DESC LIMIT 1;	orchestra
SELECT Orchestra FROM orchestra EXCEPT SELECT T1.Orchestra FROM orchestra AS T1 JOIN performance AS T2 ON T1.Orchestra_ID = T2.Orchestra_ID;	orchestra
SELECT orchestra FROM orchestra EXCEPT SELECT T2.orchestra FROM performance AS T1 JOIN orchestra AS T2 ON T1.Orchestra_ID = T2.Orchestra_ID;	orchestra
SELECT record_company FROM orchestra WHERE year_of_founded < 2003 INTERSECT SELECT record_company FROM orchestra WHERE year_of_founded > 2003;	orchestra
SELECT record_company FROM orchestra WHERE year_of_founded < 2003 INTERSECT SELECT record_company FROM orchestra WHERE year_of_founded > 2003;	orchestra
SELECT count(*) FROM orchestra WHERE Major_Record_Format = "CD" OR Major_Record_Format = "DVD";	orchestra
SELECT count(*) FROM orchestra WHERE Major_Record_Format = 'CD' OR Major_Record_Format = 'DVD';	orchestra
SELECT Year_of_Founded FROM orchestra GROUP BY Year_of_Founded HAVING COUNT(*) > 1;	orchestra
SELECT T1.year_of_founded FROM orchestra AS T1 JOIN performance AS T2 ON T1.orchestra_id = T2.orchestra_id GROUP BY T1.orchestra_id HAVING COUNT(*) > 1;	orchestra
SELECT count(*) FROM Highschooler;	network_1
SELECT count(*) FROM Highschooler;	network_1
SELECT name, grade FROM Highschooler;	network_1
SELECT name, grade FROM Highschooler;	network_1
SELECT grade FROM Highschooler;	network_1
SELECT grade FROM Highschooler;	network_1
SELECT grade FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT grade FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT name FROM Highschooler WHERE grade = 10;	network_1
SELECT name FROM Highschooler WHERE grade = 10;	network_1
SELECT id FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT id FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT count(*) FROM Highschooler WHERE grade = 9 OR grade = 10;	network_1
SELECT count(*) FROM Highschooler WHERE grade = 9 OR grade = 10;	network_1
SELECT grade, count(*) FROM Highschooler GROUP BY grade;	network_1
SELECT grade, count(*) FROM Highschooler GROUP BY grade;	network_1
SELECT grade FROM Highschooler GROUP BY grade ORDER BY COUNT(*) DESC LIMIT 1;	network_1
SELECT grade FROM Highschooler GROUP BY grade ORDER BY COUNT(*) DESC LIMIT 1;	network_1
SELECT DISTINCT grade FROM Highschooler WHERE grade >= 4;	network_1
SELECT DISTINCT grade FROM Highschooler WHERE grade >= 4;	network_1
SELECT student_id, count(*) FROM Friend GROUP BY student_id;	network_1
SELECT student_id, count(*) FROM Friend GROUP BY student_id;	network_1
SELECT T1.name, count(*) FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT T1.name, count(*) FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT name FROM friend GROUP BY student_id ORDER BY count(*) LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id HAVING COUNT(*) >= 3;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id HAVING COUNT(*) >= 3;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id WHERE T1.name = 'Kyle';	network_1
SELECT T2.name FROM Friend AS T1 JOIN Highschooler AS T2 ON T1.student_id = T2.ID WHERE T1.student_id = 1510;	network_1
SELECT count(*) FROM friend AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT count(*) FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id WHERE T1.name = 'Kyle';	network_1
SELECT id FROM highschooler EXCEPT SELECT student_id FROM friend;	network_1
SELECT id FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT name FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT name FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT T1.id FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id INTERSECT SELECT T3.id FROM highschooler AS T3 JOIN likes AS T4 ON T3.id = T4.liked_id;	network_1
SELECT id FROM highschooler WHERE id IN ( SELECT student_id FROM friend INTERSECT SELECT liked_id FROM likes );	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id EXCEPT SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id;	network_1
SELECT DISTINCT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id JOIN likes AS T3 ON T1.id = T3.student_id;	network_1
SELECT student_id, count(*) FROM Likes GROUP BY student_id;	network_1
SELECT student_id, count(*) FROM Likes GROUP BY student_id;	network_1
SELECT T1.name, count(*) FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT T1.name, count(*) FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T1.id ORDER BY count(*) LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T1.id ORDER BY COUNT(*) DESC LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T1.id HAVING COUNT(*) >= 2;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T1.id HAVING COUNT(*) >= 2;	network_1
SELECT name FROM highschooler WHERE grade > 5 EXCEPT SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id HAVING count(*) < 2;	network_1
SELECT name FROM highschooler WHERE grade > 5 EXCEPT SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id HAVING count(*) < 2;	network_1
SELECT count(*) FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id WHERE T1.name = 'Kyle';	network_1
SELECT count(*) FROM likes AS T1 JOIN highschooler AS T2 ON T1.student_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT avg(grade) FROM highschooler WHERE id IN ( SELECT student_id FROM friend );	network_1
SELECT avg(grade) FROM highschooler WHERE id IN ( SELECT student_id FROM friend );	network_1
SELECT min(grade) FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT min(grade) FROM highschooler WHERE id NOT IN ( SELECT student_id FROM friend );	network_1
SELECT DISTINCT state FROM Owners INTERSECT SELECT DISTINCT state FROM Professionals;	dog_kennels
SELECT state FROM Owners INTERSECT SELECT state FROM Professionals;	dog_kennels
SELECT avg(T1.age) FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT avg(T1.age) FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.professional_id, T1.last_name, T1.cell_number	dog_kennels
SELECT professional_id, last_name, cell_number FROM professionals WHERE state = "Indiana" UNION SELECT T1.professional_id, T1.last_name, T1.cell_number FROM professionals AS T1 JOIN treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING COUNT(*) > 2;	dog_kennels
SELECT T1.name FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id WHERE T2.cost_of_treatment <= 1000;	dog_kennels
SELECT T1.name FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id WHERE T2.cost_of_treatment <= 1000;	dog_kennels
SELECT first_name FROM Professionals INTERSECT SELECT first_name FROM Owners;	dog_kennels
SELECT first_name FROM Professionals EXCEPT SELECT name FROM Dogs UNION SELECT first_name FROM Owners;	dog_kennels
SELECT T1.professional_id, T1.role_code, T1.email_address FROM Professionals AS T1 LEFT JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.professional_id IS NULL;	dog_kennels
SELECT T1.professional_id, T1.role_code, T1.email_address FROM Professionals AS T1 LEFT JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.professional_id IS NULL;	dog_kennels
SELECT T1.owner_id, T1.first_name, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id GROUP BY T1.owner_id ORDER BY COUNT(*) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.first_name, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id GROUP BY T1.owner_id ORDER BY COUNT(*) DESC LIMIT 1;	dog_kennels
SELECT T1.professional_id, T1.role_code, T1.first_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING COUNT(*) >= 2;	dog_kennels
SELECT T1.professional_id, T1.role_code, T1.first_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING COUNT(*) >= 2;	dog_kennels
SELECT breed_name FROM Breeds AS T1 JOIN Dogs AS T2 ON T1.breed_code = T2.breed_code GROUP BY T1.breed_code ORDER BY COUNT(T2.breed_code) DESC LIMIT 1;	dog_kennels
SELECT T1.breed_name FROM Breeds AS T1 JOIN Dogs AS T2 ON T1.breed_code = T2.breed_code GROUP BY T2.breed_code ORDER BY COUNT(T2.breed_code) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY COUNT(T3.treatment_id) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T2.last_name FROM Dogs AS T1 JOIN Owners AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T1.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY SUM(T3.cost_of_treatment) DESC LIMIT 1;	dog_kennels
SELECT T1.treatment_type_description FROM Treatment_Types AS T1 JOIN Treatments AS T2 ON T1.treatment_type_code = T2.treatment_type_code GROUP BY T2.treatment_type_code ORDER BY sum(T2.cost_of_treatment) LIMIT 1;	dog_kennels
SELECT T1.treatment_type_description FROM Treatment_Types AS T1 JOIN Treatments AS T2 ON T1.treatment_type_code = T2.treatment_type_code GROUP BY T2.treatment_type_code ORDER BY sum(T2.cost_of_treatment) LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.zip_code FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id, T1.zip_code ORDER BY SUM(T3.cost_of_treatment) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.zip_code FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id GROUP BY T1.owner_id ORDER BY SUM(T2.weight) DESC LIMIT 1;	dog_kennels
SELECT T1.professional_id, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING COUNT(*) >= 2;	dog_kennels
SELECT T1.professional_id, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING COUNT(*) >= 2;	dog_kennels
SELECT T1.first_name, T1.last_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.cost_of_treatment < ( SELECT avg(cost_of_treatment) FROM Treatment_Types );	dog_kennels
SELECT T1.first_name, T1.last_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.cost_of_treatment < ( SELECT avg(cost_of_treatment) FROM Treatments );	dog_kennels
SELECT T1.date_of_treatment, T2.first_name FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id;	dog_kennels
SELECT T1.date_of_treatment, T2.first_name FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id;	dog_kennels
SELECT T1.cost_of_treatment, T2.treatment_type_description FROM Treatments AS T1 JOIN Treatment_Types AS T2 ON T1.treatment_type_code = T2.treatment_type_code;	dog_kennels
SELECT T1.cost_of_treatment, T2.treatment_type_description FROM Treatments AS T1 JOIN Treatment_Types AS T2 ON T1.treatment_type_code = T2.treatment_type_code;	dog_kennels
SELECT T1.first_name, T1.last_name, T3.size_description FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Sizes AS T3 ON T3.size_code = T2.size_code;	dog_kennels
SELECT T1.first_name, T1.last_name, T3.size_description FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Sizes AS T3 ON T3.size_code = T2.size_code;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id;	dog_kennels
SELECT T1.name, T2.date_of_treatment FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id JOIN Breeds AS T3 ON T1.breed_code = T3.breed_code ORDER BY T3.breed_name LIMIT 1;	dog_kennels
SELECT T1.name, T2.date_of_treatment FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id JOIN Breeds AS T3 ON T1.breed_code = T3.breed_code WHERE T3.breed_name = "Eskimo";	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id WHERE T1.state = 'Virginia';	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id WHERE T1.state = 'Virginia';	dog_kennels
SELECT T1.date_arrived, T1.date_departed FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.date_arrived, T1.date_departed FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.last_name FROM owners AS T1 JOIN dogs AS T2 ON T1.owner_id = T2.owner_id ORDER BY T2.age LIMIT 1;	dog_kennels
SELECT T1.last_name FROM owners AS T1 JOIN dogs AS T2 ON T1.owner_id = T2.owner_id ORDER BY T2.age LIMIT 1;	dog_kennels
SELECT email_address FROM Professionals WHERE state = 'Hawaii' OR state = 'Wisconsin';	dog_kennels
SELECT email_address FROM Professionals WHERE state = 'Hawaii' OR state = 'Wisconsin';	dog_kennels
SELECT date_arrived, date_departed FROM Dogs;	dog_kennels
SELECT date_arrived, date_departed FROM Dogs;	dog_kennels
SELECT count(DISTINCT dog_id) FROM Treatments;	dog_kennels
SELECT count(DISTINCT dog_id) FROM Treatments;	dog_kennels
SELECT count(DISTINCT professional_id) FROM Treatments;	dog_kennels
SELECT count(DISTINCT professional_id) FROM Treatments;	dog_kennels
SELECT role_code, street, city, state FROM Professionals WHERE city LIKE '%West%';	dog_kennels
SELECT T1.role_code, T1.street, T1.city, T1.state FROM Professionals AS T1 JOIN Owners AS T2 ON T1.professional_id = T2.owner_id WHERE T1.city LIKE "%West%";	dog_kennels
SELECT first_name, last_name, email_address FROM Owners WHERE state LIKE '%North%';	dog_kennels
SELECT first_name, last_name, email_address FROM Owners WHERE state LIKE '%North%';	dog_kennels
SELECT count(*) FROM Dogs WHERE age < ( SELECT avg(age) FROM Dogs );	dog_kennels
SELECT count(*) FROM Dogs WHERE age < ( SELECT avg(age) FROM Dogs );	dog_kennels
SELECT cost_of_treatment FROM Treatments WHERE date_of_treatment = ( SELECT date_of_treatment FROM Treatments ORDER BY date_of_treatment DESC LIMIT 1);	dog_kennels
SELECT cost_of_treatment FROM Treatments WHERE date_of_treatment = ( SELECT date_of_treatment FROM Treatments ORDER BY date_of_treatment DESC LIMIT 1);	dog_kennels
SELECT count(*) FROM Dogs WHERE dog_id NOT IN ( SELECT dog_id FROM Treatments );	dog_kennels
SELECT count(*) FROM Dogs WHERE dog_id NOT IN ( SELECT dog_id FROM Treatments );	dog_kennels
SELECT count(*) FROM Owners WHERE owner_id NOT IN ( SELECT owner_id FROM Dogs );	dog_kennels
SELECT count(*) FROM owners WHERE owner_id NOT IN ( SELECT owner_id FROM dogs );	dog_kennels
SELECT count(*) FROM Professionals WHERE professional_id NOT IN ( SELECT professional_id FROM Treatments );	dog_kennels
SELECT count(*) FROM professionals WHERE professional_id NOT IN ( SELECT professional_id FROM treatments );	dog_kennels
SELECT name, age, weight FROM Dogs WHERE abandoned_yn = 1;	dog_kennels
SELECT name, age, weight FROM Dogs WHERE abandoned_yn = 1;	dog_kennels
SELECT avg(age) FROM Dogs;	dog_kennels
SELECT AVG(age) FROM Dogs;	dog_kennels
SELECT max(age) FROM Dogs;	dog_kennels
SELECT max(age) FROM Dogs;	dog_kennels
SELECT charge_type, charge_amount FROM Charges;	dog_kennels
SELECT charge_type, charge_amount FROM Charges;	dog_kennels
SELECT max(charge_amount) FROM Charges;	dog_kennels
SELECT charge_amount FROM Charges ORDER BY charge_amount DESC LIMIT 1;	dog_kennels
SELECT email_address, cell_number, home_phone FROM Professionals;	dog_kennels
SELECT email_address, cell_number, home_phone FROM Professionals;	dog_kennels
SELECT breed_code, size_code FROM Dogs;	dog_kennels
SELECT DISTINCT breed_code, size_code FROM Dogs;	dog_kennels
SELECT T1.first_name, T3.treatment_type_description FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id JOIN Treatment_Types AS T3 ON T2.treatment_type_code = T3.treatment_type_code;	dog_kennels
SELECT T1.first_name, T3.treatment_type_description FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id JOIN Treatment_Types AS T3 ON T2.treatment_type_code = T3.treatment_type_code;	dog_kennels
SELECT count(*) FROM singer;	singer
SELECT COUNT(*) FROM singer;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions ASC;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions ASC;	singer
SELECT Birth_Year, Citizenship FROM singer;	singer
SELECT Birth_Year, Citizenship FROM singer;	singer
SELECT Name FROM singer WHERE Citizenship!= "France";	singer
SELECT Name FROM singer WHERE Citizenship!= 'France';	singer
SELECT Name FROM singer WHERE Birth_Year = 1948 OR Birth_Year = 1949;	singer
SELECT Name FROM singer WHERE Birth_Year = 1948 OR Birth_Year = 1949;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions DESC LIMIT 1;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions DESC LIMIT 1;	singer
SELECT Citizenship, COUNT(*) FROM Singer GROUP BY Citizenship;	singer
SELECT Citizenship, COUNT(*) FROM singer GROUP BY Citizenship;	singer
SELECT Citizenship FROM singer GROUP BY Citizenship ORDER BY COUNT(Citizenship) DESC LIMIT 1;	singer
SELECT Citizenship FROM singer GROUP BY Citizenship ORDER BY COUNT(Citizenship) DESC LIMIT 1;	singer
SELECT Citizenship, MAX(Net_Worth_Millions) FROM singer GROUP BY Citizenship;	singer
SELECT Citizenship, max(Net_Worth_Millions) FROM singer GROUP BY Citizenship;	singer
SELECT T1.Title, T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID;	singer
SELECT T1.Title, T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID;	singer
SELECT DISTINCT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID WHERE T2.Sales > 300000;	singer
SELECT DISTINCT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID WHERE T2.Sales > 300000;	singer
SELECT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name HAVING COUNT(T2.Singer_ID) > 1;	singer
SELECT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name HAVING COUNT(T2.Singer_ID) > 1;	singer
SELECT T1.Name, sum(T2.Sales) FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name;	singer
SELECT T1.Name, sum(T2.Sales) FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name;	singer
SELECT Name FROM singer WHERE Singer_ID NOT IN ( SELECT Singer_ID FROM song );	singer
SELECT Name FROM singer WHERE Singer_ID NOT IN ( SELECT singer_id FROM song );	singer
SELECT Citizenship FROM singer WHERE birth_year < 1945 INTERSECT SELECT Citizenship FROM singer WHERE birth_year > 1955;	singer
SELECT Citizenship FROM singer WHERE Birth_Year < 1945 INTERSECT SELECT Citizenship FROM singer WHERE Birth_Year > 1955;	singer
SELECT count(*) FROM Other_Available_Features;	real_estate_properties
SELECT T1.feature_type_name FROM Ref_Feature_Types AS T1 JOIN Other_Available_Features AS T2 ON T1.feature_type_code = T2.feature_type_code WHERE T2.feature_name = 'AirCon';	real_estate_properties
SELECT T1.property_type_description FROM Ref_Property_Types AS T1 JOIN Properties AS T2 ON T1.property_type_code = T2.property_type_code WHERE T2.property_type_code = 'House';	real_estate_properties
SELECT property_name FROM Properties WHERE room_count > 1 AND (property_type_code = "House" OR property_type_code = "Apartment");	real_estate_properties
