SELECT count(*) FROM singer;	concert_singer
SELECT count(*) FROM singer;	concert_singer
SELECT name, country, age FROM singer ORDER BY age DESC;	concert_singer
SELECT Name, Country, Age FROM singer ORDER BY Age DESC;	concert_singer
SELECT avg(Age), min(Age), max(Age) FROM singer WHERE Country = 'France';	concert_singer
SELECT avg(age), min(age), max(age) FROM singer WHERE country = 'France';	concert_singer
SELECT song_name, song_release_year FROM singer ORDER BY age LIMIT 1;	concert_singer
SELECT name, song_release_year FROM singer ORDER BY age LIMIT 1;	concert_singer
SELECT DISTINCT Country FROM singer WHERE Age > 20;	concert_singer
SELECT DISTINCT Country FROM singer WHERE Age > 20;	concert_singer
SELECT Country, COUNT(*) FROM singer GROUP BY Country;	concert_singer
SELECT Country, COUNT(*) FROM singer GROUP BY Country;	concert_singer
SELECT Song_Name FROM singer WHERE Age > ( SELECT AVG(Age) FROM singer );	concert_singer
SELECT song_name FROM singer WHERE age > ( SELECT avg(age) FROM singer );	concert_singer
SELECT LOCATION, Name FROM stadium WHERE Capacity BETWEEN 5000 AND 10000;	concert_singer
SELECT LOCATION, NAME FROM stadium WHERE CAPACITY BETWEEN 5000 AND 10000;	concert_singer
SELECT max(Capacity), avg(Average) FROM stadium;	concert_singer
SELECT AVG(Capacity), MAX(Capacity) FROM stadium;	concert_singer
SELECT name, capacity FROM stadium ORDER BY average DESC LIMIT 1;	concert_singer
SELECT name, capacity FROM stadium ORDER BY average DESC LIMIT 1;	concert_singer
SELECT count(*) FROM concert WHERE YEAR = '2014' OR YEAR = '2015';	concert_singer
SELECT count(*) FROM concert WHERE YEAR = '2014' OR YEAR = '2015';	concert_singer
SELECT T1.Name, count(*) FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID GROUP BY T1.Name;	concert_singer
SELECT T2.Stadium_ID, COUNT(*) FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID GROUP BY T2.Stadium_ID;	concert_singer
SELECT T1.Name, T1.Capacity FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.Year >= 2014 GROUP BY T1.Stadium_ID ORDER BY count(*) DESC LIMIT 1;	concert_singer
SELECT T1.name, T1.capacity FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.year > 2013 ORDER BY T2.year DESC LIMIT 1;	concert_singer
SELECT YEAR FROM concert GROUP BY YEAR ORDER BY count(*) DESC LIMIT 1;	concert_singer
SELECT YEAR FROM concert GROUP BY YEAR ORDER BY count(*) DESC LIMIT 1;	concert_singer
SELECT name FROM stadium EXCEPT SELECT T1.name FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID;	concert_singer
SELECT name FROM stadium EXCEPT SELECT T1.name FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID;	concert_singer
SELECT Country FROM singer WHERE Age > 40 INTERSECT SELECT Country FROM singer WHERE Age < 30 ;	concert_singer
SELECT name FROM stadium EXCEPT SELECT T1.name FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.Year = 2014;	concert_singer
SELECT name FROM stadium EXCEPT SELECT T1.name FROM stadium AS T1 JOIN concert AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.Year = 2014;	concert_singer
SELECT T1.concert_Name, T1.Theme, count(*) FROM concert AS T1 JOIN singer_in_concert AS T2 ON T1.concert_ID = T2.concert_ID GROUP BY T1.concert_Name, T1.Theme;	concert_singer
SELECT T1.concert_Name, T1.Theme, count(*) FROM concert AS T1 JOIN singer_in_concert AS T2 ON T1.concert_ID = T2.concert_ID GROUP BY T1.concert_Name, T1.Theme;	concert_singer
SELECT T1.Name, COUNT(*) FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name;	concert_singer
SELECT T1.Name, COUNT(*) FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name;	concert_singer
SELECT T1.Name FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.Singer_ID = T2.Singer_ID JOIN concert AS T3 ON T2.concert_ID = T3.concert_ID WHERE T3.Year = '2014';	concert_singer
SELECT T1.name FROM singer AS T1 JOIN singer_in_concert AS T2 ON T1.singer_id = T2.singer_id JOIN concert AS T3 ON T2.concert_id = T3.concert_id WHERE T3.year = '2014';	concert_singer
SELECT Name, Country FROM singer WHERE Song_Name LIKE '%Hey%';	concert_singer
SELECT Name, Country FROM singer WHERE Song_Name LIKE '%Hey%';	concert_singer
SELECT T1.name, T1.location FROM stadium AS T1 JOIN concert AS T2 ON T1.stadium_id = T2.stadium_id WHERE T2.year = 2014 OR T2.year = 2015 GROUP BY T1.name, T1.location HAVING COUNT(*) = 2;	concert_singer
SELECT T2.name, T2.location FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T1.year = '2014' UNION SELECT T2.name, T2.location FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T1.year = '2015';	concert_singer
SELECT count(*) FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.Capacity = ( SELECT max(Capacity) FROM stadium );	concert_singer
SELECT count(*) FROM concert AS T1 JOIN stadium AS T2 ON T1.Stadium_ID = T2.Stadium_ID WHERE T2.Capacity = ( SELECT max(Capacity) FROM stadium );	concert_singer
SELECT count(*) FROM Pets WHERE weight > 10;	pets_1
SELECT count(*) FROM Pets WHERE weight > 10;	pets_1
SELECT weight FROM pets WHERE pet_age = ( SELECT min(pet_age) FROM pets );	pets_1
SELECT weight FROM pets WHERE pet_age = ( SELECT min(pet_age) FROM pets );	pets_1
SELECT max(weight), petType FROM Pets GROUP BY petType;	pets_1
SELECT max(weight), PetType FROM Pets GROUP BY PetType;	pets_1
SELECT count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T1.age > 20;	pets_1
SELECT count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T1.Age > 20;	pets_1
SELECT count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T1.Sex = 'F' AND T3.PetType = 'dog';	pets_1
SELECT count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T1.Sex = 'F' AND T3.PetType = 'dog';	pets_1
SELECT count(DISTINCT PetType) FROM Pets;	pets_1
SELECT count(DISTINCT PetType) FROM Pets;	pets_1
SELECT T1.Fname FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat' OR T3.PetType = 'dog';	pets_1
SELECT T1.fname FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat' OR T3.PetType = 'dog';	pets_1
SELECT T1.Fname FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat' INTERSECT SELECT T1.Fname FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'dog' ;	pets_1
SELECT T1.fname FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat' INTERSECT SELECT T1.fname FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'dog' ;	pets_1
SELECT major, age FROM Student EXCEPT SELECT major, age FROM Student WHERE StuID IN ( SELECT StuID FROM Has_Pet AS T1 JOIN Pets AS T2 ON T1.PetID = T2.PetID WHERE T2.PetType = 'cat' );	pets_1
SELECT major, age FROM Student EXCEPT SELECT T1.major, T1.age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat';	pets_1
SELECT StuID FROM Student WHERE StuID NOT IN ( SELECT StuID FROM Has_Pet AS T1 JOIN Pets AS T2 ON T1.PetID = T2.PetID WHERE T2.PetType = 'cat' );	pets_1
SELECT StuID FROM Student WHERE StuID NOT IN ( SELECT StuID FROM Has_Pet AS T1 JOIN Pets AS T2 ON T1.PetID = T2.PetID WHERE T2.PetType = 'cat' );	pets_1
SELECT T1.fname, T1.age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'dog' EXCEPT SELECT T1.fname, T1.age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat';	pets_1
SELECT DISTINCT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.PetType = 'dog' INTERSECT SELECT DISTINCT T1.fname FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid JOIN pets AS T3 ON T2.petid = T3.petid WHERE T3.PetType = 'cat' ;	pets_1
SELECT pet_age, weight FROM Pets ORDER BY pet_age LIMIT 1;	pets_1
SELECT pet_age, weight FROM pets ORDER BY pet_age LIMIT 1;	pets_1
SELECT PetID, weight FROM Pets WHERE pet_age > 1;	pets_1
SELECT petid, weight FROM pets WHERE pet_age > 1;	pets_1
SELECT avg(pet_age), max(pet_age), PetType FROM Pets GROUP BY PetType;	pets_1
SELECT avg(pet_age), max(pet_age), petType FROM Pets GROUP BY petType;	pets_1
SELECT avg(weight), PetType FROM Pets GROUP BY PetType;	pets_1
SELECT avg(weight), PetType FROM Pets GROUP BY PetType;	pets_1
SELECT T1.Fname, T1.Age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID;	pets_1
SELECT DISTINCT T1.Fname, T1.Age FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID;	pets_1
SELECT T1.PetID FROM Has_Pet AS T1 JOIN Student AS T2 ON T1.StuID = T2.StuID WHERE T2.LName = 'Smith';	pets_1
SELECT T1.PetID FROM Has_Pet AS T1 JOIN Student AS T2 ON T1.StuID = T2.StuID WHERE T2.LName = 'Smith';	pets_1
SELECT T1.StuID, count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID GROUP BY T1.StuID ;	pets_1
SELECT T1.StuID, count(*) FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID GROUP BY T1.StuID ;	pets_1
SELECT T1.Fname, T1.Sex FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID GROUP BY T1.Fname, T1.Sex HAVING count(*) > 1;	pets_1
SELECT T1.fname, T1.sex FROM student AS T1 JOIN has_pet AS T2 ON T1.stuid = T2.stuid GROUP BY T1.fname, T1.sex HAVING count(*) > 1;	pets_1
SELECT T1.LName FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat' AND T3.pet_age = 3;	pets_1
SELECT T1.LName FROM Student AS T1 JOIN Has_Pet AS T2 ON T1.StuID = T2.StuID JOIN Pets AS T3 ON T2.PetID = T3.PetID WHERE T3.PetType = 'cat' AND T3.pet_age = 3;	pets_1
SELECT avg(age) FROM Student WHERE StuID NOT IN ( SELECT StuID FROM Has_Pet );	pets_1
SELECT avg(age) FROM Student WHERE StuID NOT IN ( SELECT StuID FROM Has_Pet );	pets_1
SELECT count(*) FROM continents;	car_1
SELECT count(*) FROM continents;	car_1
SELECT T1.ContId, T1.Continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.ContId = T2.Continent GROUP BY T1.ContId;	car_1
SELECT T1.ContId, T1.Continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.ContId = T2.Continent GROUP BY T1.ContId;	car_1
SELECT count(*) FROM countries;	car_1
SELECT count(*) FROM countries;	car_1
SELECT T1.Maker, T1.FullName, COUNT(*) FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.Maker;	car_1
SELECT T1.FullName, T1.Id, count(*) FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.FullName;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.Horsepower LIMIT 1;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.Horsepower LIMIT 1;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Weight < ( SELECT AVG(Weight) FROM cars_data ) ;	car_1
SELECT T1.Model FROM car_names AS T1 JOIN cars_data AS T2 ON T1.MakeId = T2.Id WHERE T2.Weight < ( SELECT AVG(Weight) FROM cars_data ) ;	car_1
SELECT T2.Maker FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Year = 1970 ;	car_1
SELECT DISTINCT T1.Maker FROM car_makers AS T1 JOIN cars_data AS T2 ON T1.Id = T2.Id WHERE T2.Year = 1970 ;	car_1
SELECT T1.Make, T2.Year FROM car_names AS T1 JOIN cars_data AS T2 ON T1.MakeId = T2.Id WHERE T2.Year = ( SELECT MIN(YEAR) FROM cars_data );	car_1
SELECT T1.Maker, T1.Year FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.Year LIMIT 1;	car_1
SELECT DISTINCT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Year > 1980;	car_1
SELECT DISTINCT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Year > 1980;	car_1
SELECT T1.Continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.ContId = T2.Continent GROUP BY T1.Continent;	car_1
SELECT T1.Continent, count(*) FROM continents AS T1 JOIN countries AS T2 ON T1.ContId = T2.Continent GROUP BY T1.Continent;	car_1
SELECT T2.CountryName FROM car_makers AS T1 JOIN countries AS T2 ON T1.Country = T2.CountryId GROUP BY T2.CountryName ORDER BY count(*) DESC LIMIT 1;	car_1
SELECT T2.CountryName FROM car_makers AS T1 JOIN countries AS T2 ON T1.Country = T2.CountryId GROUP BY T2.CountryName ORDER BY count(*) DESC LIMIT 1;	car_1
SELECT T2.Maker, COUNT(*) FROM model_list AS T1 JOIN car_makers AS T2 ON T1.Maker = T2.Id GROUP BY T2.Maker;	car_1
SELECT T2.Maker, T2.FullName, COUNT(*) FROM car_names AS T1 JOIN car_makers AS T2 ON T1.MakeId = T2.Id GROUP BY T2.Maker;	car_1
SELECT T1.Accelerate FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T2.Make = 'amc hornet sportabout';	car_1
SELECT T1.Accelerate FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId INNER JOIN model_list AS T3 ON T2.MakeId = T3.MakeId WHERE T2.Make = 'amc' AND T3.Model = 'hornet sportabout';	car_1
SELECT count(*) FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country WHERE T1.CountryId = 3;	car_1
SELECT count(*) FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country WHERE T1.CountryName = 'france';	car_1
SELECT count(*) FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country WHERE T1.CountryId = 1;	car_1
SELECT count(*) FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId JOIN model_list AS T3 ON T2.MakeId = T3.ModelId JOIN car_makers AS T4 ON T3.Maker = T4.Id WHERE T4.Country = 1;	car_1
SELECT AVG(MPG) FROM cars_data WHERE Cylinders = 4;	car_1
SELECT AVG(MPG) FROM cars_data WHERE Cylinders = 4;	car_1
SELECT MIN(Weight) FROM cars_data WHERE Cylinders = 8 AND YEAR = 1974;	car_1
SELECT min(Weight) FROM cars_data WHERE Cylinders = 8 AND YEAR = 1974;	car_1
SELECT DISTINCT T1.Maker, T1.Model FROM model_list AS T1 JOIN car_names AS T2 ON T1.ModelId = T2.MakeId;	car_1
SELECT T1.Maker, T1.Model FROM model_list AS T1 INNER JOIN car_names AS T2 ON T1.ModelId = T2.MakeId;	car_1
SELECT T1.CountryName, T1.CountryId FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country GROUP BY T1.CountryId HAVING COUNT(*) > 0;	car_1
SELECT T2.CountryName, T1.CountryId FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.CountryId;	car_1
SELECT COUNT(*) FROM cars_data WHERE Horsepower > 150;	car_1
SELECT COUNT(*) FROM cars_data WHERE Horsepower > 150;	car_1
SELECT avg(Weight), YEAR FROM cars_data GROUP BY YEAR;	car_1
SELECT avg(Weight), avg(YEAR) FROM cars_data;	car_1
SELECT T2.CountryName FROM continents AS T1 JOIN countries AS T2 ON T1.ContId = T2.Continent WHERE T1.Continent = 2 GROUP BY T2.CountryName HAVING COUNT(*) >= 3;	car_1
SELECT T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.Country WHERE T1.Continent = 2 GROUP BY T1.CountryName HAVING COUNT(*) >= 3;	car_1
SELECT max(T1.Horsepower), T2.Make FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders = 3 ;	car_1
SELECT T1.Horsepower, T2.Make FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders = 3 ORDER BY T1.Horsepower DESC LIMIT 1;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.MPG DESC LIMIT 1;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId ORDER BY T1.MPG DESC LIMIT 1;	car_1
SELECT avg(Horsepower) FROM cars_data WHERE YEAR < 1980;	car_1
SELECT avg(Horsepower) FROM cars_data WHERE YEAR < 1980;	car_1
SELECT avg(T1.Edispl) FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId INNER JOIN model_list AS T3 ON T2.MakeId = T3.ModelId WHERE T3.Model = 'volvo';	car_1
SELECT avg(T1.Edispl) FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId INNER JOIN model_list AS T3 ON T2.MakeId = T3.MakeId INNER JOIN car_makers AS T4 ON T3.Maker = T4.Id WHERE T4.Maker = 'volvo';	car_1
SELECT max(accelerate), cylinders FROM cars_data GROUP BY cylinders;	car_1
SELECT max(accelerate), cylinders FROM cars_data GROUP BY cylinders;	car_1
SELECT Model FROM car_names GROUP BY Model ORDER BY COUNT(*) DESC LIMIT 1;	car_1
SELECT Model FROM model_list GROUP BY Model ORDER BY count(*) DESC LIMIT 1;	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 4;	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 4;	car_1
SELECT COUNT(*) FROM cars_data WHERE YEAR = 1980;	car_1
SELECT COUNT(*) FROM cars_data WHERE YEAR = 1980;	car_1
SELECT count(*) FROM model_list AS T1 JOIN car_makers AS T2 ON T1.Maker = T2.Id WHERE T2.FullName = 'American Motor Company';	car_1
SELECT count(*) FROM model_list AS T1 JOIN car_makers AS T2 ON T1.Maker = T2.Id WHERE T2.Maker = 'amc';	car_1
SELECT T1.FullName, T1.Id FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.FullName HAVING COUNT(*) > 3;	car_1
SELECT T1.Maker, T1.Id FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.Maker HAVING COUNT(*) > 3;	car_1
SELECT DISTINCT T2.Model FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker JOIN cars_data AS T3 ON T3.Id = T2.MakeId WHERE T1.FullName = 'General Motors' OR T3.Weight > 3500;	car_1
SELECT DISTINCT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId JOIN model_list AS T3 ON T2.MakeId = T3.MakeId JOIN car_makers AS T4 ON T3.Maker = T4.Id WHERE T4.Maker = 'general motors' OR T1.Weight > 3500;	car_1
SELECT YEAR FROM cars_data WHERE Weight BETWEEN 3000 AND 4000;	car_1
SELECT DISTINCT YEAR FROM cars_data WHERE Weight < 4000 OR Weight > 3000;	car_1
SELECT horsepower FROM cars_data ORDER BY accelerate DESC LIMIT 1;	car_1
SELECT Horsepower FROM cars_data ORDER BY Accelerate DESC LIMIT 1;	car_1
SELECT T1.Cylinders FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T2.Model = 'volvo' ORDER BY T1.Accelerate LIMIT 1;	car_1
SELECT T1.Cylinders FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId INNER JOIN model_list AS T3 ON T2.MakeId = T3.MakeId WHERE T3.Model = 'volvo' ORDER BY T1.Accelerate LIMIT 1;	car_1
SELECT count(*) FROM cars_data WHERE Accelerate > ( SELECT Accelerate FROM cars_data ORDER BY Horsepower DESC LIMIT 1 ) ;	car_1
SELECT COUNT(*) FROM cars_data WHERE Accelerate > ( SELECT Accelerate FROM cars_data ORDER BY Horsepower DESC LIMIT 1);	car_1
SELECT count(*) FROM ( SELECT countryid FROM car_makers GROUP BY countryid HAVING count(*) > 2 );	car_1
SELECT count(*) FROM ( SELECT countryid FROM car_makers GROUP BY countryid HAVING count(*) > 2 );	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 6;	car_1
SELECT COUNT(*) FROM cars_data WHERE Cylinders > 6;	car_1
SELECT T2.Model FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders = 4 ORDER BY T1.Horsepower DESC LIMIT 1;	car_1
SELECT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders = 4 ORDER BY T1.Horsepower DESC LIMIT 1;	car_1
SELECT MakeId, Make FROM car_names WHERE MakeId NOT IN ( SELECT MakeId FROM cars_data WHERE Cylinders > 3 ) ;	car_1
SELECT T1.MakeId, T2.Make FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Cylinders < 4;	car_1
SELECT MAX(MPG) FROM cars_data WHERE Cylinders = 8 OR YEAR < 1980;	car_1
SELECT max(MPG) FROM cars_data WHERE Cylinders = 8 OR YEAR < 1980;	car_1
SELECT DISTINCT T2.Model FROM cars_data AS T1 INNER JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Weight < 3500 AND T2.Make!= 'ford';	car_1
SELECT DISTINCT T2.Model FROM cars_data AS T1 JOIN car_names AS T2 ON T1.Id = T2.MakeId WHERE T1.Weight < 3500 AND T2.Make!= 'ford';	car_1
SELECT T2.CountryName FROM car_makers AS T1 JOIN countries AS T2 ON T1.Country = T2.CountryId WHERE T1.Maker IS NULL;	car_1
SELECT T1.CountryName FROM countries AS T1 LEFT JOIN car_makers AS T2 ON T1.CountryId = T2.Country WHERE T2.Id IS NULL;	car_1
SELECT id, Maker FROM car_makers GROUP BY Maker HAVING count(*) >= 2 AND count(*) > 3;	car_1
SELECT T1.Id, T1.Maker FROM car_makers AS T1 JOIN model_list AS T2 ON T1.Id = T2.Maker GROUP BY T1.Id, T1.Maker HAVING COUNT(*) >= 2 AND SUM(T2.ModelId) > 3;	car_1
SELECT T1.CountryId, T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.CountryId JOIN model_list AS T3 ON T2.Id = T3.Maker WHERE T3.Model = 'fiat' GROUP BY T1.CountryId HAVING COUNT(*) > 3;	car_1
SELECT T1.CountryId, T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.CountryId JOIN model_list AS T3 ON T2.Id = T3.Maker WHERE T3.Model = 'fiat' GROUP BY T1.CountryId HAVING count(*) > 3 UNION SELECT T1.CountryId, T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.CountryId JOIN model_list AS T3 ON T2.Id = T3.Maker EXCEPT SELECT T1.CountryId, T1.CountryName FROM countries AS T1 JOIN car_makers AS T2 ON T1.CountryId = T2.CountryId JOIN model_list AS T3 ON T2.Id = T3.Maker ;	car_1
SELECT Country FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Country FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Abbreviation FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Abbreviation FROM airlines WHERE Airline = 'JetBlue Airways';	flight_2
SELECT Airline, Abbreviation FROM airlines WHERE Country = 'USA';	flight_2
SELECT Airline, Abbreviation FROM airlines WHERE Country = 'USA';	flight_2
SELECT AirportCode, AirportName FROM airports WHERE City = 'Anthony';	flight_2
SELECT AirportCode, AirportName FROM airports WHERE City = 'Anthony';	flight_2
SELECT count(*) FROM airlines;	flight_2
SELECT count(*) FROM airlines;	flight_2
SELECT count(*) FROM airports;	flight_2
SELECT count(*) FROM airports;	flight_2
SELECT count(*) FROM flights;	flight_2
SELECT count(*) FROM flights;	flight_2
SELECT Airline FROM airlines WHERE Abbreviation = 'UAL';	flight_2
SELECT Airline FROM airlines WHERE Abbreviation = 'UAL';	flight_2
SELECT count(*) FROM airlines WHERE Country = 'USA';	flight_2
SELECT count(*) FROM airlines WHERE Country = 'USA';	flight_2
SELECT City, Country FROM airports WHERE AirportCode = 'ALT';	flight_2
SELECT City, Country FROM airports WHERE AirportCode = 'ALT';	flight_2
SELECT AirportName FROM airports WHERE AirportCode = 'AKO';	flight_2
SELECT AirportName FROM airports WHERE AirportCode = 'AKO';	flight_2
SELECT AirportName FROM airports WHERE City = 'Aberdeen';	flight_2
SELECT AirportName FROM airports WHERE City = 'Aberdeen';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT count(*) FROM flights WHERE DestAirport = 'ATO';	flight_2
SELECT count(*) FROM flights WHERE DestAirport = 'ATO';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T2.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T2.City = 'Aberdeen';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T2.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T2.City = 'Ashley';	flight_2
SELECT count(*) FROM flights WHERE SourceAirport = 'APG' AND DestAirport = 'ASY';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T2.Airline = 'JetBlue Airways';	flight_2
SELECT count(*) FROM flights WHERE Airline = 'Jetblue Airways';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T2.Airline = 'United Airlines' AND T1.DestAirport = 'ASY';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T1.Airline = 1 AND T2.AirportName = 'ASY';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T1.Airline = 1 AND T2.AirportName = 'AHD';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T1.Airline = 1 AND T2.AirportName = 'AHD Airport';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T1.Airline = 1 AND T2.City = 'Aberdeen';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode JOIN airlines AS T3 ON T1.Airline = T3.uid WHERE T3.Airline = 'United Airlines' AND T2.City = 'Aberdeen ';	flight_2
SELECT T2.City FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode GROUP BY T2.City ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.City FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode GROUP BY T2.City ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.City FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode GROUP BY T2.City ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.City FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode GROUP BY T2.City ORDER BY COUNT(*) DESC LIMIT 1;	flight_2
SELECT T2.AirportCode FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode GROUP BY T2.AirportCode ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.AirportCode FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode GROUP BY T2.AirportCode ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.AirportCode FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode GROUP BY T2.AirportCode ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.AirportCode FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode GROUP BY T2.AirportCode ORDER BY count(*) LIMIT 1;	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Airline ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Airline ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T2.Abbreviation, T2.Country FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Abbreviation, T2.Country ORDER BY count(*) DESC LIMIT 1;	flight_2
SELECT T1.Abbreviation, T1.Country FROM airlines AS T1 JOIN flights AS T2 ON T1.uid = T2.Airline GROUP BY T1.Abbreviation ORDER BY count(*) LIMIT 1;	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.SourceAirport = 'AHD';	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.SourceAirport = 'AHD';	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.DestAirport = 'AHD';	flight_2
SELECT T1.Airline FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T2.AirportName = 'AHD';	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.SourceAirport = 'APG' INTERSECT SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.DestAirport = 'CVO';	flight_2
SELECT T1.Airline FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode JOIN airports AS T3 ON T1.DestAirport = T3.AirportCode WHERE T2.AirportCode = "APG" AND T3.AirportCode = "CVO" ;	flight_2
SELECT T1.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.SourceAirport = 'CVO' INTERSECT SELECT T1.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.SourceAirport = 'APG' ;	flight_2
SELECT T1.Airline FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T1.DestAirport = 'CVO' INTERSECT SELECT T1.Airline FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T1.DestAirport = 'APG' ;	flight_2
SELECT Airline FROM flights GROUP BY Airline HAVING COUNT(*) >= 10;	flight_2
SELECT T2.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid GROUP BY T2.Airline HAVING COUNT(*) >= 10;	flight_2
SELECT Airline FROM airlines GROUP BY Airline HAVING COUNT(*) < 200;	flight_2
SELECT T1.Airline FROM flights AS T1 JOIN airlines AS T2 ON T1.Airline = T2.uid WHERE T1.FlightNo < 200;	flight_2
SELECT FlightNo FROM flights WHERE Airline = 1;	flight_2
SELECT FlightNo FROM flights WHERE Airline = 1;	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE DestAirport = 'APG';	flight_2
SELECT FlightNo FROM flights WHERE DestAirport = 'APG';	flight_2
SELECT FlightNo FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T2.City = 'Aberdeen ';	flight_2
SELECT FlightNo FROM flights WHERE SourceAirport = 'APG';	flight_2
SELECT T2.FlightNo FROM airports AS T1 JOIN flights AS T2 ON T1.AirportCode = T2.DestAirport WHERE T1.City = 'Aberdeen';	flight_2
SELECT FlightNo FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T2.City = 'Aberdeen ';	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.DestAirport = T2.AirportCode WHERE T2.City = "Aberdeen " OR T2.City = "Abilene ";	flight_2
SELECT count(*) FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode WHERE T2.City = "Aberdeen " OR T2.City = "Abilene ";	flight_2
SELECT AirportName FROM airports WHERE AirportName NOT IN ( SELECT T2.AirportName FROM flights AS T1 JOIN airports AS T2 ON T1.SourceAirport = T2.AirportCode );	flight_2
SELECT AirportName FROM airports WHERE AirportName NOT IN ( SELECT DestAirport FROM flights ) ;	flight_2
SELECT count(*) FROM employee;	employee_hire_evaluation
SELECT count(*) FROM employee;	employee_hire_evaluation
SELECT Name FROM employee ORDER BY Age;	employee_hire_evaluation
SELECT Name FROM employee ORDER BY Age;	employee_hire_evaluation
SELECT count(*), city FROM employee GROUP BY city;	employee_hire_evaluation
SELECT City, COUNT(*) FROM employee GROUP BY City;	employee_hire_evaluation
SELECT City FROM employee WHERE Age < 30 GROUP BY City HAVING COUNT(*) > 1;	employee_hire_evaluation
SELECT City FROM employee WHERE Age < 30 GROUP BY City HAVING COUNT(*) > 1;	employee_hire_evaluation
SELECT LOCATION, COUNT(*) FROM shop GROUP BY LOCATION;	employee_hire_evaluation
SELECT LOCATION, COUNT(*) FROM shop GROUP BY LOCATION;	employee_hire_evaluation
SELECT manager_name, district FROM shop ORDER BY number_products DESC LIMIT 1;	employee_hire_evaluation
SELECT manager_name, district FROM shop ORDER BY number_products DESC LIMIT 1;	employee_hire_evaluation
SELECT min(Number_products), max(Number_products) FROM shop;	employee_hire_evaluation
SELECT min(Number_products), max(Number_products) FROM shop;	employee_hire_evaluation
SELECT name, location, district FROM shop ORDER BY Number_products DESC;	employee_hire_evaluation
SELECT name, location, district FROM shop ORDER BY Number_products DESC;	employee_hire_evaluation
SELECT Name FROM shop WHERE Number_products > ( SELECT AVG(Number_products) FROM shop );	employee_hire_evaluation
SELECT Name FROM shop WHERE Number_products > ( SELECT AVG(Number_products) FROM shop ) ;	employee_hire_evaluation
SELECT T1.Name FROM employee AS T1 JOIN evaluation AS T2 ON T1.Employee_ID = T2.Employee_ID GROUP BY T1.Name ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T1.Name FROM employee AS T1 JOIN evaluation AS T2 ON T1.Employee_ID = T2.Employee_ID GROUP BY T1.Name ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T2.Name FROM evaluation AS T1 JOIN employee AS T2 ON T1.Employee_ID = T2.Employee_ID ORDER BY T1.Bonus DESC LIMIT 1;	employee_hire_evaluation
SELECT T2.Name FROM evaluation AS T1 JOIN employee AS T2 ON T1.Employee_ID = T2.Employee_ID ORDER BY T1.Bonus DESC LIMIT 1;	employee_hire_evaluation
SELECT name FROM employee EXCEPT SELECT T1.name FROM employee AS T1 JOIN evaluation AS T2 ON T1.employee_id = T2.employee_id;	employee_hire_evaluation
SELECT name FROM employee EXCEPT SELECT T1.name FROM employee AS T1 JOIN evaluation AS T2 ON T1.employee_id = T2.employee_id;	employee_hire_evaluation
SELECT T1.name FROM shop AS T1 JOIN hiring AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.name ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT T1.name FROM shop AS T1 JOIN hiring AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.name ORDER BY count(*) DESC LIMIT 1;	employee_hire_evaluation
SELECT Name FROM shop WHERE Shop_ID NOT IN ( SELECT Shop_ID FROM hiring );	employee_hire_evaluation
SELECT T1.Name FROM shop AS T1 LEFT JOIN hiring AS T2 ON T1.Shop_ID = T2.Shop_ID WHERE T2.Employee_ID IS NULL;	employee_hire_evaluation
SELECT T2.Name, count(*) FROM hiring AS T1 JOIN shop AS T2 ON T1.Shop_ID = T2.Shop_ID GROUP BY T2.Name;	employee_hire_evaluation
SELECT count(*), T1.name FROM shop AS T1 JOIN hiring AS T2 ON T1.shop_id = T2.shop_id GROUP BY T1.name;	employee_hire_evaluation
SELECT sum(Bonus) FROM evaluation;	employee_hire_evaluation
SELECT sum(Bonus) FROM evaluation;	employee_hire_evaluation
SELECT * FROM hiring;	employee_hire_evaluation
SELECT * FROM hiring;	employee_hire_evaluation
SELECT District FROM shop WHERE Number_products < 3000 INTERSECT SELECT District FROM shop WHERE Number_products > 10000;	employee_hire_evaluation
SELECT DISTINCT District FROM shop WHERE Number_products < 3000 INTERSECT SELECT DISTINCT District FROM shop WHERE Number_products > 10000;	employee_hire_evaluation
SELECT count(DISTINCT location) FROM shop;	employee_hire_evaluation
SELECT count(DISTINCT location) FROM shop;	employee_hire_evaluation
SELECT count(*) FROM Documents;	cre_Doc_Template_Mgt
SELECT count(*) FROM Documents;	cre_Doc_Template_Mgt
SELECT Document_ID, Document_Name, Document_Description FROM Documents;	cre_Doc_Template_Mgt
SELECT Document_ID, Document_Name, Document_Description FROM Documents;	cre_Doc_Template_Mgt
SELECT document_name, template_id FROM Documents WHERE document_description LIKE '%w%';	cre_Doc_Template_Mgt
SELECT Document_Name, Template_ID FROM Documents WHERE Document_Description LIKE '%w%';	cre_Doc_Template_Mgt
SELECT T2.document_id, T2.template_id, T1.document_description FROM Documents AS T1 JOIN Paragraphs AS T2 ON T1.document_id = T2.document_id WHERE T1.document_name = 'Robbin CV';	cre_Doc_Template_Mgt
SELECT T1.document_id, T1.template_id, T1.document_description FROM documents AS T1 JOIN templates AS T2 ON T1.template_id = T2.template_id WHERE T1.document_name = 'Robbin CV';	cre_Doc_Template_Mgt
SELECT count(DISTINCT Template_ID) FROM Documents;	cre_Doc_Template_Mgt
SELECT count(DISTINCT Template_ID) FROM Documents;	cre_Doc_Template_Mgt
SELECT count(*) FROM Documents AS T1 JOIN Templates AS T2 ON T1.Template_ID = T2.Template_ID WHERE T2.Template_Type_Code = 'PPT';	cre_Doc_Template_Mgt
SELECT count(*) FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id WHERE T1.template_type_code = 'PPT';	cre_Doc_Template_Mgt
SELECT Template_ID, count(*) FROM Documents GROUP BY Template_ID;	cre_Doc_Template_Mgt
SELECT template_id, count(*) FROM documents GROUP BY template_id;	cre_Doc_Template_Mgt
SELECT T1.template_id, T2.template_type_code FROM documents AS T1 JOIN templates AS T2 ON T1.template_id = T2.template_id GROUP BY T1.template_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT T1.template_id, T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY T1.template_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_id FROM documents GROUP BY template_id HAVING count(*) > 1;	cre_Doc_Template_Mgt
SELECT template_id FROM documents GROUP BY template_id HAVING count(*) > 1;	cre_Doc_Template_Mgt
SELECT template_id FROM Templates WHERE template_id NOT IN ( SELECT template_id FROM Documents );	cre_Doc_Template_Mgt
SELECT template_id FROM Templates EXCEPT SELECT template_id FROM Documents ;	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates;	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates;	cre_Doc_Template_Mgt
SELECT Template_ID, Version_Number, Template_Type_Code FROM Templates;	cre_Doc_Template_Mgt
SELECT Template_ID, Version_Number, Template_Type_Code FROM Templates;	cre_Doc_Template_Mgt
SELECT DISTINCT Template_Type_Code FROM Templates;	cre_Doc_Template_Mgt
SELECT template_type_code FROM Ref_template_types ;	cre_Doc_Template_Mgt
SELECT template_id FROM templates WHERE template_type_code = 'PP' OR template_type_code = 'PPT';	cre_Doc_Template_Mgt
SELECT Template_ID FROM Templates WHERE Template_Type_Code = 'PP' OR Template_Type_Code = 'PPT';	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates WHERE Template_Type_Code = 'CV';	cre_Doc_Template_Mgt
SELECT count(*) FROM Templates AS T1 JOIN Ref_Template_Types AS T2 ON T1.Template_Type_Code = T2.Template_Type_Code WHERE T2.Template_Type_Description = 'CV';	cre_Doc_Template_Mgt
SELECT Version_Number, Template_Type_Code FROM Templates WHERE Version_Number > 5;	cre_Doc_Template_Mgt
SELECT Version_Number, Template_Type_Code FROM Templates WHERE Version_Number > 5;	cre_Doc_Template_Mgt
SELECT Template_Type_Code, count(*) FROM Templates GROUP BY Template_Type_Code;	cre_Doc_Template_Mgt
SELECT template_type_code, count(*) FROM Templates GROUP BY template_type_code;	cre_Doc_Template_Mgt
SELECT Template_Type_Code FROM Templates GROUP BY Template_Type_Code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM templates GROUP BY template_type_code HAVING count(*) < 3;	cre_Doc_Template_Mgt
SELECT template_type_code FROM Ref_template_types GROUP BY template_type_code HAVING count(*) < 3;	cre_Doc_Template_Mgt
SELECT min(version_number), template_type_code FROM Templates ;	cre_Doc_Template_Mgt
SELECT min(version_number), template_type_code FROM templates ;	cre_Doc_Template_Mgt
SELECT T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id WHERE T2.document_name = "Data base";	cre_Doc_Template_Mgt
SELECT T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id WHERE T2.document_name = "Data base";	cre_Doc_Template_Mgt
SELECT Document_Name FROM Documents AS T1 JOIN Templates AS T2 ON T1.Template_ID = T2.Template_ID WHERE T2.Template_Type_Code = 'BK';	cre_Doc_Template_Mgt
SELECT T1.document_name FROM documents AS T1 JOIN templates AS T2 ON T1.template_id = T2.template_id WHERE T2.template_type_code = 'BK';	cre_Doc_Template_Mgt
SELECT template_type_code, count(*) FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY template_type_code;	cre_Doc_Template_Mgt
SELECT template_type_code, count(*) FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY template_type_code;	cre_Doc_Template_Mgt
SELECT T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY T1.template_type_code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT T1.template_type_code FROM templates AS T1 JOIN documents AS T2 ON T1.template_id = T2.template_id GROUP BY T1.template_type_code ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT template_type_code FROM Ref_template_types WHERE template_type_code NOT IN ( SELECT template_type_code FROM Documents );	cre_Doc_Template_Mgt
SELECT template_type_code FROM Ref_template_types EXCEPT SELECT T2.template_type_code FROM Documents AS T1 JOIN Templates AS T2 ON T1.Template_ID = T2.Template_ID;	cre_Doc_Template_Mgt
SELECT Template_Type_Code, Template_Type_Description FROM Ref_Template_Types;	cre_Doc_Template_Mgt
SELECT template_type_code, template_type_description FROM Ref_template_types;	cre_Doc_Template_Mgt
SELECT template_type_description FROM Ref_template_types WHERE template_type_code = 'AD';	cre_Doc_Template_Mgt
SELECT Template_Type_Description FROM Ref_Template_Types WHERE Template_Type_Code = 'AD';	cre_Doc_Template_Mgt
SELECT template_type_code FROM Ref_template_types WHERE template_type_description = 'Book';	cre_Doc_Template_Mgt
SELECT template_type_code FROM Ref_template_types WHERE template_type_description = 'Book';	cre_Doc_Template_Mgt
SELECT DISTINCT T1.template_type_description FROM ref_template_types AS T1 JOIN templates AS T2 ON T1.template_type_code = T2.template_type_code JOIN documents AS T3 ON T2.template_id = T3.template_id;	cre_Doc_Template_Mgt
SELECT DISTINCT T2.Document_Description FROM Templates AS T1 JOIN Documents AS T2 ON T1.Template_ID = T2.Template_ID;	cre_Doc_Template_Mgt
SELECT T1.template_id FROM templates AS T1 JOIN ref_template_types AS T2 ON T1.template_type_code = T2.template_type_code WHERE T2.template_type_description = 'Presentation';	cre_Doc_Template_Mgt
SELECT template_id FROM templates AS T1 JOIN ref_template_types AS T2 ON T1.template_type_code = T2.template_type_code WHERE T2.template_type_description = 'Presentation';	cre_Doc_Template_Mgt
SELECT count(*) FROM Paragraphs;	cre_Doc_Template_Mgt
SELECT count(*) FROM Paragraphs;	cre_Doc_Template_Mgt
SELECT count(*) FROM Paragraphs AS T1 JOIN Documents AS T2 ON T1.Document_ID = T2.Document_ID WHERE T2.Document_Name = 'Summer Show';	cre_Doc_Template_Mgt
SELECT count(*) FROM Documents AS T1 JOIN Paragraphs AS T2 ON T1.Document_ID = T2.Document_ID WHERE T1.Document_Name = 'Summer Show';	cre_Doc_Template_Mgt
SELECT Other_Details FROM Paragraphs WHERE Paragraph_Text = 'Korea';	cre_Doc_Template_Mgt
SELECT Other_Details FROM Paragraphs WHERE Paragraph_Text = 'Korea';	cre_Doc_Template_Mgt
SELECT T2.Paragraph_ID, T2.Paragraph_Text FROM Documents AS T1 INNER JOIN Paragraphs AS T2 ON T1.Document_ID = T2.Document_ID WHERE T1.Document_Name = 'Welcome to NY';	cre_Doc_Template_Mgt
SELECT T1.Paragraph_ID, T1.Paragraph_Text FROM Paragraphs AS T1 JOIN Documents AS T2 ON T1.Document_ID = T2.Document_ID WHERE T2.Document_Name = 'Welcome to NY';	cre_Doc_Template_Mgt
SELECT T1.Paragraph_Text FROM Paragraphs AS T1 JOIN Documents AS T2 ON T1.Document_ID = T2.Document_ID WHERE T2.Document_Name = 'Customer reviews';	cre_Doc_Template_Mgt
SELECT T1.Paragraph_Text FROM Paragraphs AS T1 JOIN Documents AS T2 ON T1.Document_ID = T2.Document_ID WHERE T2.Document_Name = 'Customer reviews';	cre_Doc_Template_Mgt
SELECT Document_ID, count(*) FROM Paragraphs GROUP BY Document_ID;	cre_Doc_Template_Mgt
SELECT Document_ID, count(*) FROM Paragraphs GROUP BY Document_ID ORDER BY Document_ID;	cre_Doc_Template_Mgt
SELECT T1.document_id, T1.document_name, count(*) FROM Documents AS T1 JOIN Paragraphs AS T2 ON T1.document_id = T2.document_id GROUP BY T1.document_id;	cre_Doc_Template_Mgt
SELECT T1.document_id, T1.document_name, count(*) FROM Documents AS T1 JOIN Paragraphs AS T2 ON T1.document_id = T2.document_id GROUP BY T1.document_id, T1.document_name;	cre_Doc_Template_Mgt
SELECT Document_ID FROM Paragraphs GROUP BY Document_ID HAVING count(*) >= 2;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) >= 2;	cre_Doc_Template_Mgt
SELECT T1.document_id, T1.document_name FROM Documents AS T1 JOIN Paragraphs AS T2 ON T1.document_id = T2.document_id GROUP BY T1.document_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT T1.document_id, T1.document_name FROM documents AS T1 JOIN paragraphs AS T2 ON T1.document_id = T2.document_id GROUP BY T1.document_id ORDER BY count(*) DESC LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id ORDER BY count(*) LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id ORDER BY count(*) LIMIT 1;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) = 1 OR count(*) = 2;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs GROUP BY document_id HAVING count(*) BETWEEN 1 AND 2;	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs WHERE paragraph_text = 'Brazil' OR paragraph_text = 'Ireland';	cre_Doc_Template_Mgt
SELECT document_id FROM paragraphs WHERE paragraph_text = 'Brazil' INTERSECT SELECT document_id FROM paragraphs WHERE paragraph_text = 'Ireland';	cre_Doc_Template_Mgt
SELECT count(*) FROM teacher;	course_teach
SELECT count(*) FROM teacher;	course_teach
SELECT Name FROM teacher ORDER BY Age;	course_teach
SELECT Name FROM teacher ORDER BY Age ASC;	course_teach
SELECT Age, Hometown FROM teacher;	course_teach
SELECT Age, Hometown FROM teacher;	course_teach
SELECT Name FROM teacher WHERE Hometown NOT LIKE "Little Lever Urban District";	course_teach
SELECT Name FROM teacher WHERE Hometown NOT LIKE "Little Lever Urban District";	course_teach
SELECT Name FROM teacher WHERE Age = 32 OR Age = 33;	course_teach
SELECT Name FROM teacher WHERE Age = 32 OR Age = 33;	course_teach
SELECT Hometown FROM teacher ORDER BY Age LIMIT 1;	course_teach
SELECT Hometown FROM teacher ORDER BY Age LIMIT 1;	course_teach
SELECT Hometown, COUNT(*) FROM teacher GROUP BY Hometown;	course_teach
SELECT Hometown, COUNT(*) FROM teacher GROUP BY Hometown;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown ORDER BY COUNT(*) DESC LIMIT 1;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown ORDER BY count(*) DESC LIMIT 1;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown HAVING COUNT(*) >= 2;	course_teach
SELECT Hometown FROM teacher GROUP BY Hometown HAVING COUNT(*) >= 2;	course_teach
SELECT T2.Name, T1.Course FROM course_arrange AS T1 JOIN teacher AS T2 ON T1.Teacher_ID = T2.Teacher_ID;	course_teach
SELECT T1.Name, T2.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID;	course_teach
SELECT T1.Name, T2.Course FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID ORDER BY T1.Name;	course_teach
SELECT T1.Name, T2.Course FROM teacher AS T1 JOIN course AS T2 ON T1.Teacher_ID = T2.Course_ID ORDER BY T1.Name;	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID WHERE T3.Course = 'Math';	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID JOIN course AS T3 ON T2.Course_ID = T3.Course_ID WHERE T3.Course = 'Math';	course_teach
SELECT T1.Name, count(*) FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T1.Name;	course_teach
SELECT T1.Name, count(*) FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T1.Name;	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T1.Name HAVING count(*) >= 2;	course_teach
SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID GROUP BY T1.Name HAVING count(*) >= 2;	course_teach
SELECT Name FROM teacher WHERE Teacher_ID NOT IN ( SELECT Teacher_ID FROM course_arrange ) ;	course_teach
SELECT Name FROM teacher EXCEPT SELECT T1.Name FROM teacher AS T1 JOIN course_arrange AS T2 ON T1.Teacher_ID = T2.Teacher_ID;	course_teach
SELECT COUNT(ID) FROM visitor WHERE Age < 30;	museum_visit
SELECT Name FROM visitor WHERE Level_of_membership > 4 ORDER BY Level_of_membership DESC;	museum_visit
SELECT avg(age) FROM visitor WHERE level_of_membership <= 4;	museum_visit
SELECT Name, Level_of_membership FROM visitor WHERE Level_of_membership > 4 ORDER BY Age DESC;	museum_visit
SELECT museum_id, name FROM museum ORDER BY num_of_staff DESC LIMIT 1;	museum_visit
SELECT avg(num_of_staff) FROM museum WHERE open_year < '2009';	museum_visit
SELECT open_year, num_of_staff FROM museum WHERE name = 'Plaza Museum';	museum_visit
SELECT name FROM museum WHERE num_of_staff > ( SELECT min(num_of_staff) FROM museum WHERE open_year > '2010' );	museum_visit
SELECT T1.ID, T1.Name, T1.Age FROM visitor AS T1 JOIN visit AS T2 ON T1.ID = T2.visitor_ID GROUP BY T1.ID HAVING COUNT(*) > 1;	museum_visit
SELECT T1.ID, T1.Name, T1.Level_of_membership FROM visitor AS T1 JOIN visit AS T2 ON T1.ID = T2.visitor_ID GROUP BY T1.ID ORDER BY SUM(T2.Total_spent) DESC LIMIT 1;	museum_visit
SELECT T1.Museum_ID, T2.Name FROM visit AS T1 JOIN museum AS T2 ON T1.Museum_ID = T2.Museum_ID GROUP BY T1.Museum_ID ORDER BY count(*) DESC LIMIT 1;	museum_visit
SELECT Name FROM museum WHERE Museum_ID NOT IN ( SELECT Museum_ID FROM visit );	museum_visit
SELECT T2.Name, T2.Age FROM visit AS T1 JOIN visitor AS T2 ON T1.visitor_ID = T2.ID GROUP BY T2.Name, T2.Age ORDER BY count(*) DESC LIMIT 1;	museum_visit
SELECT avg(Num_of_Ticket), max(Num_of_Ticket) FROM visit;	museum_visit
SELECT sum(T1.Total_spent) FROM visit AS T1 JOIN visitor AS T2 ON T1.visitor_ID = T2.ID WHERE T2.Level_of_membership = 1;	museum_visit
SELECT T1.name FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id JOIN museum AS T3 ON T2.Museum_ID = T3.Museum_ID WHERE T3.open_year < 2009 INTERSECT SELECT T1.name FROM visitor AS T1 JOIN visit AS T2 ON T1.id = T2.visitor_id JOIN museum AS T3 ON T2.Museum_ID = T3.Museum_ID WHERE T3.open_year > 2011 ;	museum_visit
SELECT count(*) FROM museum AS T1 JOIN visit AS T2 ON T1.Museum_ID = T2.Museum_ID WHERE T1.Open_Year < 2010 ;	museum_visit
SELECT count(*) FROM museum WHERE open_year > 2013 OR open_year < 2008;	museum_visit
SELECT count(*) FROM players;	wta_1
SELECT count(*) FROM players;	wta_1
SELECT count(*) FROM matches;	wta_1
SELECT count(*) FROM matches;	wta_1
SELECT first_name, birth_date FROM players WHERE country_code = 'USA';	wta_1
SELECT first_name, birth_date FROM players WHERE country_code = 'USA';	wta_1
SELECT avg(loser_age), avg(winner_age) FROM matches;	wta_1
SELECT avg(loser_age), avg(winner_age) FROM matches;	wta_1
SELECT avg(winner_rank) FROM matches;	wta_1
SELECT avg(winner_rank) FROM matches;	wta_1
SELECT max(loser_rank) FROM matches;	wta_1
SELECT max(loser_rank) FROM matches;	wta_1
SELECT count(DISTINCT country_code) FROM players;	wta_1
SELECT count(DISTINCT country_code) FROM players;	wta_1
SELECT COUNT(DISTINCT loser_name) FROM matches;	wta_1
SELECT count(DISTINCT loser_name) FROM matches;	wta_1
SELECT tourney_name FROM matches GROUP BY tourney_name HAVING COUNT(*) > 10;	wta_1
SELECT tourney_name FROM matches GROUP BY tourney_name HAVING count(*) > 10;	wta_1
SELECT DISTINCT winner_name FROM matches WHERE YEAR = 2013 INTERSECT SELECT DISTINCT winner_name FROM matches WHERE YEAR = 2016;	wta_1
SELECT DISTINCT T2.first_name, T2.last_name FROM matches AS T1 INNER JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T1.year = 2013 OR T1.year = 2016;	wta_1
SELECT count(*) FROM matches WHERE year = 2013 OR year = 2016;	wta_1
SELECT count(*) FROM matches WHERE year = 2013 OR year = 2016;	wta_1
SELECT T1.country_code, T1.first_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE tourney_name = "WTA Championships" INTERSECT SELECT T1.country_code, T1.first_name FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE tourney_name = "Australian Open";	wta_1
SELECT T1.first_name, T1.country_code FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T2.tourney_name = 'WTA Championships' AND T2.tourney_name = 'Australian Open';	wta_1
SELECT first_name, country_code FROM players ORDER BY birth_date LIMIT 1;	wta_1
SELECT first_name, country_code FROM players ORDER BY birth_date LIMIT 1;	wta_1
SELECT first_name, last_name FROM players ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players ORDER BY birth_date;	wta_1
SELECT first_name, last_name FROM players WHERE hand = "L";	wta_1
SELECT first_name, last_name FROM players WHERE hand = 'L' ORDER BY birth_date;	wta_1
SELECT T1.first_name, T1.country_code FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name, T1.country_code ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.country_code FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name, T1.country_code ORDER BY tours DESC LIMIT 1;	wta_1
SELECT year FROM matches GROUP BY year ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT year FROM matches GROUP BY year ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT T1.winner_name, T2.ranking_points FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id ORDER BY T2.ranking_points DESC LIMIT 1;	wta_1
SELECT T1.winner_name, T2.ranking_points FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id ORDER BY T2.ranking_points DESC LIMIT 1;	wta_1
SELECT T1.winner_name FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id WHERE T1.tourney_name = "Australian Open" ORDER BY T2.ranking_points DESC LIMIT 1;	wta_1
SELECT T1.winner_name FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id WHERE T2.tours = ( SELECT MAX(tours) FROM rankings );	wta_1
SELECT loser_name, winner_name FROM matches ORDER BY minutes DESC LIMIT 1;	wta_1
SELECT T1.winner_name, T1.loser_name FROM matches AS T1 WHERE T1.minutes = ( SELECT max(minutes) FROM matches ) ;	wta_1
SELECT avg(T2.ranking), T1.first_name FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT T1.first_name, AVG(T2.ranking) FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT T1.first_name, sum(T2.ranking_points) FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id GROUP BY T1.first_name;	wta_1
SELECT first_name, sum(ranking_points) FROM rankings AS T1 JOIN players AS T2 ON T1.player_id = T2.player_id GROUP BY first_name;	wta_1
SELECT count(*), country_code FROM players GROUP BY country_code ;	wta_1
SELECT count(*), country_code FROM players GROUP BY country_code ;	wta_1
SELECT country_code FROM players GROUP BY country_code ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT country_code FROM players GROUP BY country_code ORDER BY count(*) DESC LIMIT 1;	wta_1
SELECT country_code FROM players GROUP BY country_code HAVING COUNT(*) > 50;	wta_1
SELECT country_code FROM players GROUP BY country_code HAVING COUNT(*) > 50;	wta_1
SELECT ranking_date, count(*) FROM rankings ;	wta_1
SELECT ranking_date, tours FROM rankings ;	wta_1
SELECT YEAR, COUNT(*) FROM matches GROUP BY YEAR;	wta_1
SELECT year, count(*) FROM matches GROUP BY year;	wta_1
SELECT T1.winner_name, T1.winner_rank FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id ORDER BY T1.winner_age LIMIT 3;	wta_1
SELECT T1.winner_name, T1.winner_rank FROM matches AS T1 JOIN rankings AS T2 ON T1.winner_id = T2.player_id ORDER BY T1.winner_age LIMIT 3;	wta_1
SELECT count(DISTINCT T1.winner_name) FROM matches AS T1 INNER JOIN players AS T2 ON T1.winner_id = T2.player_id WHERE T2.hand = 'L' AND T1.tourney_name = 'WTA Championships';	wta_1
SELECT count(*) FROM players AS T1 JOIN matches AS T2 ON T1.player_id = T2.winner_id WHERE T1.hand = "L";	wta_1
SELECT T1.first_name, T1.country_code, T1.birth_date FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id ORDER BY T2.ranking_points DESC LIMIT 1;	wta_1
SELECT T1.first_name, T1.country_code, T1.birth_date FROM players AS T1 JOIN rankings AS T2 ON T1.player_id = T2.player_id ORDER BY T2.ranking_points DESC LIMIT 1;	wta_1
SELECT count(*), hand FROM players GROUP BY hand;	wta_1
SELECT count(*), hand FROM players GROUP BY hand;	wta_1
SELECT count(*) FROM ship WHERE disposition_of_ship = 'Captured';	battle_death
SELECT name, tonnage FROM ship ORDER BY name DESC;	battle_death
SELECT name, date, result FROM battle ;	battle_death
SELECT max(killed), min(killed) FROM death;	battle_death
SELECT AVG(injured) FROM death;	battle_death
SELECT killed, injured FROM death AS T1 JOIN ship AS T2 ON T1.caused_by_ship_id = T2.id WHERE T2.tonnage = 't';	battle_death
SELECT name, result FROM battle WHERE bulgarian_commander!='Boril';	battle_death
SELECT DISTINCT T1.id, T1.name FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.ship_type = 'Brig';	battle_death
SELECT T1.id, T1.name FROM battle AS T1 JOIN death AS T2 ON T1.id = T2.caused_by_ship_id WHERE T2.killed > 10;	battle_death
SELECT T1.id, T1.name FROM ship AS T1 JOIN death AS T2 ON T1.id = T2.caused_by_ship_id GROUP BY T2.caused_by_ship_id ORDER BY count(*) DESC LIMIT 1;	battle_death
SELECT DISTINCT name FROM battle WHERE bulgarian_commander = 'Kaloyan' AND latin_commander = 'Baldwin I';	battle_death
SELECT count(DISTINCT result) FROM battle;	battle_death
SELECT count(*) FROM battle WHERE id NOT IN ( SELECT T1.id FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.tonnage = '225' );	battle_death
SELECT T1.name, T1.date FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.name = 'Lettice' OR T2.name = 'HMS Atalanta';	battle_death
SELECT T1.name, T1.result, T1.bulgarian_commander FROM battle AS T1 JOIN ship AS T2 ON T1.id = T2.lost_in_battle WHERE T2.location = 'English Channel';	battle_death
SELECT note FROM death WHERE note LIKE '%East%';	battle_death
SELECT line_1, line_2 FROM Addresses;	student_transcripts_tracking
SELECT line_1, line_2 FROM Addresses;	student_transcripts_tracking
SELECT count(*) FROM Courses;	student_transcripts_tracking
SELECT count(*) FROM Courses;	student_transcripts_tracking
SELECT course_description FROM Courses WHERE course_id = 2;	student_transcripts_tracking
SELECT course_description FROM Courses WHERE course_name = "math";	student_transcripts_tracking
SELECT zip_postcode FROM Addresses WHERE city = 'Port Chelsea';	student_transcripts_tracking
SELECT zip_postcode FROM Addresses WHERE city = 'Port Chelsea';	student_transcripts_tracking
SELECT T1.department_name, T1.department_id FROM Departments AS T1 JOIN Degree_Programs AS T2 ON T1.department_id = T2.department_id GROUP BY T1.department_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.department_name, T1.department_id FROM Departments AS T1 JOIN Degree_Programs AS T2 ON T1.department_id = T2.department_id GROUP BY T1.department_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT count(DISTINCT department_id) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(DISTINCT department_id) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(DISTINCT degree_summary_name) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(DISTINCT degree_summary_name) FROM Degree_Programs;	student_transcripts_tracking
SELECT count(*) FROM DEPARTMENTS AS T1 JOIN degree_programs AS T2 ON T1.department_id = T2.department_id WHERE T1.department_name = 'engineering';	student_transcripts_tracking
SELECT count(*) FROM Departments AS T1 JOIN Degree_Programs AS T2 ON T1.department_id = T2.department_id WHERE T1.department_name = 'engineering';	student_transcripts_tracking
SELECT section_name, section_description FROM sections;	student_transcripts_tracking
SELECT section_name, section_description FROM sections;	student_transcripts_tracking
SELECT T1.course_name, T1.course_id FROM courses AS T1 JOIN sections AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_id HAVING count(*) <= 2;	student_transcripts_tracking
SELECT course_name, course_id FROM courses WHERE course_id NOT IN ( SELECT course_id FROM sections );	student_transcripts_tracking
SELECT section_name FROM Sections ORDER BY section_name DESC;	student_transcripts_tracking
SELECT section_name FROM Sections ORDER BY section_name DESC;	student_transcripts_tracking
SELECT T1.semester_name, T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id GROUP BY T1.semester_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.semester_name, T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id GROUP BY T1.semester_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT department_description FROM Departments WHERE department_name LIKE '%computer%';	student_transcripts_tracking
SELECT department_description FROM Departments WHERE department_name LIKE '%computer%';	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T2.student_id FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T2.student_id HAVING count(*) = 2;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T2.student_id FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T2.student_id HAVING count(*) = 2;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = 'Bachelor';	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = "Bachelor";	student_transcripts_tracking
SELECT T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_summary_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_summary_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_program_id, T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_program_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.degree_program_id, T1.degree_summary_name FROM Degree_Programs AS T1 JOIN Student_Enrolment AS T2 ON T1.degree_program_id = T2.degree_program_id GROUP BY T1.degree_program_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.student_id, T1.first_name, T1.middle_name, T1.last_name, count(*) FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.first_name, T1.middle_name, T1.last_name, T1.student_id, COUNT(*) FROM Students AS T1 JOIN Student_Enrolment AS T2 ON T1.student_id = T2.student_id GROUP BY T1.student_id ORDER BY COUNT(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT semester_name FROM Semesters EXCEPT SELECT T1.semester_name FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id ;	student_transcripts_tracking
SELECT semester_name FROM SEMESTERS WHERE semester_id NOT IN ( SELECT T2.semester_id FROM STUDENT_ENROLMENT AS T1 JOIN SEMESTERS AS T2 ON T1.semester_id = T2.semester_id );	student_transcripts_tracking
SELECT T1.course_name FROM courses AS T1 JOIN student_enrolment_courses AS T2 ON T1.course_id = T2.course_id;	student_transcripts_tracking
SELECT T1.course_name FROM courses AS T1 JOIN student_enrolment_courses AS T2 ON T1.course_id = T2.course_id JOIN student_enrolment AS T3 ON T2.student_enrolment_id = T3.student_enrolment_id GROUP BY T1.course_name;	student_transcripts_tracking
SELECT T1.course_name FROM courses AS T1 JOIN student_enrolment_courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.course_name FROM courses AS T1 JOIN student_enrolment_courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_name ORDER BY count(*) DESC C LIMIT 1;	student_transcripts_tracking
SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.current_address_id = T2.address_id EXCEPT SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.current_address_id = T2.address_id JOIN Student_Enrolment AS T3 ON T1.student_id = T3.student_id;	student_transcripts_tracking
SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id EXCEPT SELECT T1.last_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id JOIN Student_Enrolment AS T3 ON T1.student_id = T3.student_id;	student_transcripts_tracking
SELECT T1.transcript_date, T1.transcript_id FROM TRANSCRIPTS AS T1 JOIN TRANSCRIPT_CONTENTS AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id HAVING count(*) >= 2;	student_transcripts_tracking
SELECT T1.transcript_date, T1.transcript_id FROM TRANSCRIPTS AS T1 JOIN TRANSCRIPT_CONTENTS AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id HAVING count(*) >= 2;	student_transcripts_tracking
SELECT cell_mobile_number FROM Students WHERE first_name = 'Timmothy' AND last_name = 'Ward';	student_transcripts_tracking
SELECT cell_mobile_number FROM Students WHERE first_name = 'Timmothy' AND last_name = 'Ward';	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT first_name, middle_name, last_name FROM Students ORDER BY date_first_registered LIMIT 1;	student_transcripts_tracking
SELECT T1.first_name FROM students AS T1 JOIN addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T1.permanent_address_id <> T1.current_address_id;	student_transcripts_tracking
SELECT first_name FROM Students WHERE permanent_address_id <> current_address_id;	student_transcripts_tracking
SELECT T1.address_id, T1.line_1, T1.line_2, T1.line_3 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.current_address_id GROUP BY T1.address_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.address_id, T1.line_1, T1.line_2 FROM addresses AS T1 JOIN students AS T2 ON T1.address_id = T2.current_address_id GROUP BY T1.address_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT AVG(transcript_date) FROM Transcripts;	student_transcripts_tracking
SELECT avg(transcript_date) FROM Transcripts;	student_transcripts_tracking
SELECT transcript_date, other_details FROM TRANSCRIPTS ORDER BY transcript_date LIMIT 1;	student_transcripts_tracking
SELECT min(transcript_date), other_details FROM Transcripts;	student_transcripts_tracking
SELECT count(*) FROM Transcripts;	student_transcripts_tracking
SELECT count(*) FROM Transcripts;	student_transcripts_tracking
SELECT max(transcript_date) FROM Transcripts;	student_transcripts_tracking
SELECT max(transcript_date) FROM Transcripts;	student_transcripts_tracking
SELECT count(*), student_enrolment_id FROM student_enrolment_courses GROUP BY student_enrolment_id;	student_transcripts_tracking
SELECT T1.course_id, count(*) FROM Courses AS T1 JOIN Student_Enrolment_Courses AS T2 ON T1.course_id = T2.course_id GROUP BY T1.course_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT T1.transcript_date, T1.transcript_id FROM TRANSCRIPTS AS T1 JOIN TRANSCRIPT_CONTENTS AS T2 ON T1.transcript_id = T2.transcript_id GROUP BY T1.transcript_id ORDER BY count(*) DESC LIMIT 1;	student_transcripts_tracking
SELECT transcript_date, transcript_id FROM TRANSCRIPTS ORDER BY transcript_id LIMIT 1;	student_transcripts_tracking
SELECT T1.semester_name FROM SEMESTERS AS T1 JOIN STUDENT_ENROLMENT AS T2 ON T1.semester_id = T2.semester_id WHERE T2.degree_program_id = 1 UNION SELECT T1.semester_name FROM SEMESTERS AS T1 JOIN STUDENT_ENROLMENT AS T2 ON T1.semester_id = T2.semester_id WHERE T2.degree_program_id = 2;	student_transcripts_tracking
SELECT T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = 'Master' INTERSECT SELECT T1.semester_id FROM Semesters AS T1 JOIN Student_Enrolment AS T2 ON T1.semester_id = T2.semester_id JOIN Degree_Programs AS T3 ON T2.degree_program_id = T3.degree_program_id WHERE T3.degree_summary_name = 'Bachelor';	student_transcripts_tracking
SELECT count(DISTINCT current_address_id) FROM Students;	student_transcripts_tracking
SELECT DISTINCT T1.line_1, T1.line_2, T1.line_3 FROM Addresses AS T1 JOIN Students AS T2 ON T1.address_id = T2.current_address_id GROUP BY T1.line_1, T1.line_2, T1.line_3;	student_transcripts_tracking
SELECT other_student_details FROM Students ORDER BY other_student_details DESC;	student_transcripts_tracking
SELECT other_student_details FROM Students ORDER BY last_name DESC;	student_transcripts_tracking
SELECT section_description FROM SECTIONS WHERE section_name = 'h';	student_transcripts_tracking
SELECT section_description FROM SECTIONS WHERE section_name = 'h';	student_transcripts_tracking
SELECT T1.first_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T2.country = 'Haiti' OR T1.cell_mobile_number = '09700166582';	student_transcripts_tracking
SELECT DISTINCT T1.first_name FROM Students AS T1 JOIN Addresses AS T2 ON T1.permanent_address_id = T2.address_id WHERE T2.country = 'Haiti' OR T1.cell_mobile_number = '09700166582';	student_transcripts_tracking
SELECT Title FROM Cartoon ORDER BY Title;	tvshow
SELECT Title FROM Cartoon ORDER BY Title;	tvshow
SELECT Title FROM Cartoon WHERE Directed_by = 'Ben Jones';	tvshow
SELECT Title FROM Cartoon WHERE Directed_by = 'Ben Jones';	tvshow
SELECT COUNT(*) FROM Cartoon WHERE Written_by = 'Joseph Kuhr';	tvshow
SELECT COUNT(*) FROM Cartoon WHERE Written_by = 'Joseph Kuhr';	tvshow
SELECT Title, Directed_by FROM Cartoon ORDER BY Original_air_date;	tvshow
SELECT T1.Title, T1.Directed_by FROM Cartoon AS T1 JOIN TV_channel AS T2 ON T1.Channel = T2.id ORDER BY T1.Original_air_date;	tvshow
SELECT Title FROM Cartoon WHERE Directed_by = 'Ben Jones' OR Directed_by = 'Brandon Vietti';	tvshow
SELECT Title FROM Cartoon WHERE Directed_by = 'Ben Jones' OR Directed_by = 'Brandon Vietti';	tvshow
SELECT Country, count(*) FROM TV_Channel GROUP BY Country ORDER BY count(*) DESC LIMIT 1;	tvshow
SELECT Country, count(*) FROM TV_Channel GROUP BY Country ORDER BY count(*) DESC LIMIT 1;	tvshow
SELECT count(DISTINCT series_name), count(DISTINCT content) FROM TV_Channel;	tvshow
SELECT count(DISTINCT series_name), count(DISTINCT content) FROM TV_Channel;	tvshow
SELECT Content FROM TV_Channel WHERE series_name = "Sky Radio";	tvshow
SELECT content FROM TV_Channel WHERE series_name = 'Sky Radio';	tvshow
SELECT Package_Option FROM TV_Channel WHERE series_name = "Sky Radio";	tvshow
SELECT Package_Option FROM TV_Channel WHERE series_name = 'Sky Radio';	tvshow
SELECT count(*) FROM TV_Channel WHERE Language = 'English';	tvshow
SELECT COUNT(id) FROM TV_Channel WHERE Language = 'English';	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language ORDER BY COUNT(*) ASC ;	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language ORDER BY COUNT(*) ASC LIMIT 1;	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language;	tvshow
SELECT Language, COUNT(*) FROM TV_Channel GROUP BY Language;	tvshow
SELECT DISTINCT T1.series_name FROM TV_Channel AS T1 INNER JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Title = 'The Rise of the Blue Beetle!';	tvshow
SELECT T1.series_name FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Title = 'The Rise of the Blue Beetle!';	tvshow
SELECT T2.Title FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T1.series_name = 'Sky Radio';	tvshow
SELECT T2.Title FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T1.series_name = 'Sky Radio';	tvshow
SELECT Episode FROM TV_series ORDER BY Rating;	tvshow
SELECT Episode FROM TV_series ORDER BY Rating;	tvshow
SELECT Episode, Rating FROM TV_series ORDER BY Rating DESC LIMIT 3;	tvshow
SELECT Episode, Rating FROM TV_series ORDER BY Rating DESC LIMIT 3;	tvshow
SELECT min(Share), max(Share) FROM TV_series;	tvshow
SELECT max(Share), min(Share) FROM TV_series;	tvshow
SELECT Air_Date FROM TV_series WHERE Episode = 'A Love of a Lifetime';	tvshow
SELECT Air_Date FROM TV_series WHERE Episode = 'A Love of a Lifetime';	tvshow
SELECT T1.Weekly_Rank FROM TV_series AS T1 JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T1.Episode = 'A Love of a Lifetime';	tvshow
SELECT weekly_rank FROM tv_series WHERE episode = "A Love of a Lifetime";	tvshow
SELECT T1.Series_name FROM TV_Channel AS T1 JOIN TV_series AS T2 ON T1.id = T2.Channel WHERE T2.Episode = 'A Love of a Lifetime';	tvshow
SELECT T2.series_name FROM TV_series AS T1 JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T1.Episode = 'A Love of a Lifetime';	tvshow
SELECT T1.Episode FROM TV_series AS T1 JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T2.series_name = "Sky Radio";	tvshow
SELECT Episode FROM TV_series AS T1 JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T2.series_name = "Sky Radio";	tvshow
SELECT count(*), directed_by FROM Cartoon GROUP BY directed_by;	tvshow
SELECT COUNT(*), directed_by FROM Cartoon GROUP BY directed_by;	tvshow
SELECT T1.Production_code, T1.Channel FROM Cartoon AS T1 JOIN TV_series AS T2 ON T1.id = T2.Channel ORDER BY T2.Air_Date DESC LIMIT 1;	tvshow
SELECT Production_code, Channel FROM Cartoon ORDER BY Original_air_date DESC LIMIT 1;	tvshow
SELECT Package_Option, series_name FROM TV_Channel WHERE Hight_definition_TV = 'yes';	tvshow
SELECT Package_Option, series_name FROM TV_Channel WHERE Hight_definition_TV = 'yes';	tvshow
SELECT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = 'Todd Casey';	tvshow
SELECT DISTINCT T2.Country FROM Cartoon AS T1 INNER JOIN TV_Channel AS T2 ON T1.Channel = T2.id WHERE T1.Written_by = 'Todd Casey';	tvshow
SELECT DISTINCT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = 'Todd Casey';	tvshow
SELECT DISTINCT T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Written_by = 'Todd Casey';	tvshow
SELECT DISTINCT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = 'Ben Jones' OR T2.Directed_by = 'Michael Chang';	tvshow
SELECT T1.series_name, T1.Country FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = 'Ben Jones' OR T2.Directed_by = 'Michael Chang';	tvshow
SELECT Pixel_aspect_ratio_PAR, Country FROM TV_Channel EXCEPT SELECT Pixel_aspect_ratio_PAR, Country FROM TV_Channel WHERE Language = 'English';	tvshow
SELECT Pixel_aspect_ratio_PAR, Country FROM TV_Channel WHERE Language!= 'English';	tvshow
SELECT id FROM TV_Channel GROUP BY Country HAVING COUNT(*) > 2;	tvshow
SELECT id FROM TV_Channel GROUP BY id HAVING COUNT(*) > 2;	tvshow
SELECT id FROM TV_Channel WHERE id NOT IN ( SELECT Channel FROM Cartoon WHERE Directed_by = 'Ben Jones' );	tvshow
SELECT id FROM TV_Channel EXCEPT SELECT T1.id FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = 'Ben Jones';	tvshow
SELECT Package_Option FROM TV_Channel EXCEPT SELECT T1.Package_Option FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = 'Ben Jones';	tvshow
SELECT DISTINCT T1.Package_Option FROM TV_Channel AS T1 JOIN Cartoon AS T2 ON T1.id = T2.Channel WHERE T2.Directed_by = 'Ben Jones';	tvshow
SELECT count(*) FROM poker_player;	poker_player
SELECT count(*) FROM poker_player;	poker_player
SELECT Earnings FROM poker_player ORDER BY Earnings DESC ;	poker_player
SELECT Earnings FROM poker_player ORDER BY Earnings DESC ;	poker_player
SELECT Final_Table_Made, Best_Finish FROM poker_player ;	poker_player
SELECT Final_Table_Made, Best_Finish FROM poker_player;	poker_player
SELECT avg(Earnings) FROM poker_player;	poker_player
SELECT avg(Earnings) FROM poker_player;	poker_player
SELECT Money_Rank FROM poker_player ORDER BY Earnings DESC LIMIT 1;	poker_player
SELECT Money_Rank FROM poker_player ORDER BY Earnings DESC LIMIT 1;	poker_player
SELECT MAX(Final_Table_Made) FROM poker_player WHERE Earnings < 200000;	poker_player
SELECT MAX(Final_Table_Made) FROM poker_player WHERE Earnings < 200000;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Earnings > 300000 ;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Earnings > 300000 ;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Final_Table_Made;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Final_Table_Made;	poker_player
SELECT T2.Birth_Date FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Earnings LIMIT 1;	poker_player
SELECT T2.Birth_Date FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Earnings LIMIT 1;	poker_player
SELECT T1.Money_Rank FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Height DESC LIMIT 1;	poker_player
SELECT T1.Money_Rank FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Height DESC LIMIT 1;	poker_player
SELECT avg(Earnings) FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Height > 200;	poker_player
SELECT avg(Earnings) FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID WHERE T2.Height > 200;	poker_player
SELECT T1.Name FROM people AS T1 JOIN poker_player AS T2 ON T1.People_ID = T2.People_ID ORDER BY T2.Earnings DESC ;	poker_player
SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ORDER BY T1.Earnings DESC;	poker_player
SELECT Nationality, COUNT(*) FROM people GROUP BY Nationality;	poker_player
SELECT Nationality, COUNT(*) FROM people GROUP BY Nationality;	poker_player
SELECT Nationality FROM people GROUP BY Nationality ORDER BY COUNT(*) DESC LIMIT 1;	poker_player
SELECT Nationality FROM people GROUP BY Nationality ORDER BY COUNT(*) DESC LIMIT 1;	poker_player
SELECT Nationality FROM people GROUP BY Nationality HAVING COUNT(*) >= 2;	poker_player
SELECT Nationality FROM people GROUP BY Nationality HAVING COUNT(*) >= 2;	poker_player
SELECT Name, Birth_Date FROM people ORDER BY Name;	poker_player
SELECT Name, Birth_Date FROM people ORDER BY Name;	poker_player
SELECT Name FROM people WHERE Nationality <> 'Russia';	poker_player
SELECT Name FROM people WHERE Nationality <> 'Russia';	poker_player
SELECT Name FROM people WHERE People_ID NOT IN ( SELECT People_ID FROM poker_player );	poker_player
SELECT Name FROM people EXCEPT SELECT T2.Name FROM poker_player AS T1 JOIN people AS T2 ON T1.People_ID = T2.People_ID ;	poker_player
SELECT count(DISTINCT nationality) FROM people;	poker_player
SELECT count(DISTINCT Nationality) FROM people;	poker_player
SELECT count(DISTINCT state) FROM AREA_CODE_STATE;	voter_1
SELECT contestant_number, contestant_name FROM CONTESTANTS ORDER BY contestant_name DESC;	voter_1
SELECT vote_id, phone_number, state FROM VOTES;	voter_1
SELECT max(area_code), min(area_code) FROM AREA_CODE_STATE;	voter_1
SELECT max(created) FROM VOTES WHERE state = 'CA';	voter_1
SELECT contestant_name FROM CONTESTANTS EXCEPT SELECT 'Jessie Alloway' AS contestant_name;	voter_1
SELECT DISTINCT state, created FROM VOTES;	voter_1
SELECT T1.contestant_number, T1.contestant_name FROM CONTESTANTS AS T1 JOIN VOTES AS T2 ON T1.contestant_number = T2.contestant_number GROUP BY T1.contestant_number HAVING COUNT(*) >= 2;	voter_1
SELECT T1.contestant_number, T2.contestant_name FROM VOTES AS T1 JOIN CONTESTANTS AS T2 ON T1.contestant_number = T2.contestant_number GROUP BY T1.contestant_number ORDER BY count(*) DESC LIMIT 1;	voter_1
SELECT count(*) FROM votes WHERE state = 'NY' OR state = 'CA';	voter_1
SELECT count(*) FROM contestants WHERE contestant_number NOT IN ( SELECT contestant_number FROM votes );	voter_1
SELECT state FROM VOTES GROUP BY state ORDER BY count(*) DESC LIMIT 1;	voter_1
SELECT T1.created, T1.state, T1.phone_number FROM VOTES AS T1 JOIN CONTESTANTS AS T2 ON T1.contestant_number = T2.contestant_number WHERE T2.contestant_name = 'Tabatha Gehling';	voter_1
SELECT T1.area_code FROM area_code_state AS T1 JOIN votes AS T2 ON T1.state = T2.state JOIN contestants AS T3 ON T2.contestant_number = T3.contestant_number WHERE T3.contestant_name = 'Tabatha Gehling' INTERSECT SELECT T1.area_code FROM area_code_state AS T1 JOIN votes AS T2 ON T1.state = T2.state JOIN contestants AS T3 ON T2.contestant_number = T3.contestant_number WHERE T3.contestant_name = 'Kelly Clauss';	voter_1
SELECT contestant_name FROM CONTESTANTS WHERE contestant_name LIKE '%Al%';	voter_1
SELECT Name FROM country WHERE IndepYear > 1950;	world_1
SELECT Name FROM country WHERE IndepYear > 1950;	world_1
SELECT COUNT(Code) FROM country WHERE GovernmentForm = 'Republic';	world_1
SELECT COUNT(Code) FROM country WHERE GovernmentForm = 'Republic';	world_1
SELECT SUM(SurfaceArea) FROM country WHERE Region = 'Caribbean';	world_1
SELECT SUM(SurfaceArea) FROM country WHERE Continent = 'Carribean';	world_1
SELECT Continent FROM country WHERE Name = 'Anguilla';	world_1
SELECT continent FROM country WHERE name = "Anguilla";	world_1
SELECT T1.Region FROM country AS T1 INNER JOIN city AS T2 ON T1.Code = T2.CountryCode WHERE T2.Name = 'Kabul';	world_1
SELECT T2.Region FROM city AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Name = 'Kabul';	world_1
SELECT Language FROM countrylanguage WHERE CountryCode = 'ARU';	world_1
SELECT T2.Language FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = "Aruba" GROUP BY T2.Language ORDER BY SUM(T2.Percentage) DESC LIMIT 1;	world_1
SELECT Population, LifeExpectancy FROM country WHERE Name = 'Brazil';	world_1
SELECT Population, LifeExpectancy FROM country WHERE Name = 'Brazil';	world_1
SELECT Region, Population FROM country WHERE Name = 'Angola';	world_1
SELECT Region, Population FROM country WHERE Name = 'Angola';	world_1
SELECT avg(lifeexpectancy) FROM country WHERE region = 'Central Africa';	world_1
SELECT AVG(LifeExpectancy) FROM country WHERE Region = 'Central Africa';	world_1
SELECT name FROM country WHERE continent = 'Asia' ORDER BY lifeexpectancy LIMIT 1;	world_1
SELECT name FROM country WHERE continent = 'Asia' ORDER BY lifeexpectancy LIMIT 1;	world_1
SELECT sum(Population), max(GNP) FROM country WHERE Continent = 'Asia';	world_1
SELECT sum(population), max(gnp) FROM country WHERE continent = 'Asia';	world_1
SELECT AVG(T1.LifeExpectancy) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.GovernmentForm = 'Republic' AND T1.Continent = 'Africa';	world_1
SELECT AVG(T1.LifeExpectancy) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Africa' AND T1.GovernmentForm = 'Republic';	world_1
SELECT SUM(SurfaceArea) FROM country WHERE Continent = 'Asia' OR Continent = 'Europe';	world_1
SELECT SUM(SurfaceArea) FROM country WHERE Continent = 'Asia' OR Continent = 'Europe';	world_1
SELECT SUM(Population) FROM city WHERE District = 'Gelderland';	world_1
SELECT SUM(Population) FROM city WHERE District = 'Gelderland';	world_1
SELECT avg(GNP), sum(Population) FROM country WHERE GovernmentForm = 'US Territory';	world_1
SELECT avg(GNP), sum(Population) FROM country WHERE GovernmentForm = 'Territory of the United States of America';	world_1
SELECT count(DISTINCT Language) FROM countrylanguage;	world_1
SELECT count(DISTINCT language) FROM countrylanguage;	world_1
SELECT count(DISTINCT GovernmentForm) FROM country WHERE Continent = 'Africa';	world_1
SELECT COUNT(DISTINCT GovernmentForm) FROM country WHERE Continent = 'Africa';	world_1
SELECT sum(T2.Percentage) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Name = 'Aruba';	world_1
SELECT count(*) FROM countrylanguage WHERE CountryCode = 'ARU';	world_1
SELECT COUNT(T1.Language) FROM countrylanguage AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Name = 'Afghanistan';	world_1
SELECT COUNT(T1.Language) FROM countrylanguage AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Name = 'Afghanistan';	world_1
SELECT T2.Name FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code GROUP BY T2.Name ORDER BY COUNT(T1.Language) DESC LIMIT 1;	world_1
SELECT T2.Name FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code GROUP BY T2.Name ORDER BY COUNT(T1.Language) DESC LIMIT 1;	world_1
SELECT T2.Continent FROM countrylanguage AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code GROUP BY T2.Continent ORDER BY COUNT(T1.Language) DESC LIMIT 1;	world_1
SELECT T2.Continent FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code GROUP BY T2.Continent ORDER BY COUNT(T1.Language) DESC LIMIT 1;	world_1
SELECT COUNT(T1.Code) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' AND T2.Language = 'Dutch';	world_1
SELECT count(*) FROM countrylanguage WHERE Language = 'English' OR Language = 'Dutch';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' INTERSECT SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'French';	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode JOIN countrylanguage AS T3 ON T1.Code = T3.CountryCode WHERE T2.Language = 'English' AND T3.Language = 'French' ;	world_1
SELECT T1.Name FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode JOIN countrylanguage AS T3 ON T1.Code = T3.CountryCode WHERE T2.Language = 'English' AND T3.Language = 'French' AND T2.IsOfficial = 'T' AND T3.IsOfficial = 'T';	world_1
SELECT T2.Name FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language = 'English' OR T1.Language = 'French';	world_1
SELECT COUNT(DISTINCT T1.Continent) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Chinese';	world_1
SELECT COUNT(T1.Continent) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Chinese';	world_1
SELECT DISTINCT T1.Region FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'English' OR T2.Language = 'Dutch';	world_1
SELECT DISTINCT T1.Region FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Dutch' OR T2.Language = 'English';	world_1
SELECT T2.Name FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language = 'English' OR T1.Language = 'Dutch';	world_1
SELECT T2.Name FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language = 'English' OR T1.Language = 'Dutch';	world_1
SELECT T2.Language FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.Continent = 'Asia' GROUP BY T2.Language ORDER BY SUM(T2.Percentage) DESC LIMIT 1;	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Continent = 'Asia' GROUP BY T1.Language ORDER BY COUNT(T1.Language) DESC LIMIT 1;	world_1
SELECT T2.Language FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.GovernmentForm = 'Republic' GROUP BY T2.Language HAVING COUNT(*) = 1;	world_1
SELECT T2.Language FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.GovernmentForm = 'Republic' GROUP BY T2.Language HAVING COUNT(*) = 1;	world_1
SELECT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode WHERE T2.Language = 'English' ORDER BY T1.Population DESC LIMIT 1;	world_1
SELECT T2.Name FROM countrylanguage AS T1 INNER JOIN city AS T2 ON T1.CountryCode = T2.CountryCode WHERE T1.Language = 'English' ORDER BY T2.Population DESC LIMIT 1;	world_1
SELECT name, population, lifeexpectancy FROM country WHERE continent = 'Asia' ORDER BY surfacearea DESC LIMIT 1;	world_1
SELECT name, population, lifeexpectancy FROM country WHERE continent = 'Asia' ORDER BY surfacearea DESC LIMIT 1;	world_1
SELECT AVG(T1.LifeExpectancy) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.IsOfficial = 'F';	world_1
SELECT AVG(T1.LifeExpectancy) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.IsOfficial = "F";	world_1
SELECT sum(population) FROM country WHERE code NOT IN ( SELECT countrycode FROM countrylanguage WHERE language = 'English' );	world_1
SELECT SUM(T2.Population) FROM countrylanguage AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language = 'English';	world_1
SELECT T2.Language FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.HeadOfState = 'Beatrix' AND T2.IsOfficial = 'T';	world_1
SELECT T2.Language FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.HeadOfState = 'Beatrix' AND T2.IsOfficial = 'T';	world_1
SELECT count(DISTINCT T1.Language) FROM countrylanguage AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.IndepYear < 1930 AND T1.IsOfficial = 'T';	world_1
SELECT COUNT(DISTINCT T2.Language) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T1.IndepYear < 1930 AND T2.IsOfficial = 'T';	world_1
SELECT Name FROM country WHERE SurfaceArea > ( SELECT MAX(SurfaceArea) FROM country WHERE Continent = 'Europe' );	world_1
SELECT Name FROM country WHERE SurfaceArea > ( SELECT MAX(SurfaceArea) FROM country WHERE Continent = 'Europe' ) ;	world_1
SELECT name FROM country WHERE population < ( SELECT min(population) FROM country WHERE continent = 'Asia' );	world_1
SELECT name FROM country WHERE population < ( SELECT max(population) FROM country WHERE continent = 'Asia' );	world_1
SELECT name FROM country WHERE population > ( SELECT max(population) FROM country WHERE continent = 'Africa' );	world_1
SELECT name FROM country WHERE population > ( SELECT max(population) FROM country WHERE continent = 'Africa' );	world_1
SELECT Code FROM country WHERE Code NOT IN ( SELECT Code FROM countrylanguage );	world_1
SELECT Code FROM country WHERE Code NOT IN ( SELECT Code FROM countrylanguage );	world_1
SELECT countrycode FROM countrylanguage WHERE language!= 'English';	world_1
SELECT T1.Code FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language!= 'English';	world_1
SELECT Code FROM country WHERE Code NOT IN ( SELECT CountryCode FROM countrylanguage WHERE Language = 'English' ) AND GovernmentForm!= 'Republic';	world_1
SELECT Code FROM country WHERE Code NOT IN ( SELECT Code FROM countrylanguage WHERE Language = 'English' );	world_1
SELECT T2.Name FROM countrylanguage AS T1 INNER JOIN city AS T2 ON T1.CountryCode = T2.CountryCode WHERE T1.Language!= 'English' INTERSECT SELECT T2.Name FROM country AS T3 WHERE T3.Continent = 'Europe' ;	world_1
SELECT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode WHERE T2.IsOfficial = 'F' AND T2.Language = 'English';	world_1
SELECT DISTINCT T1.Name FROM city AS T1 JOIN countrylanguage AS T2 ON T1.CountryCode = T2.CountryCode WHERE T2.Language = 'Chinese' AND T2.IsOfficial = 'T' AND T1.CountryCode = ( SELECT Code FROM country WHERE Continent = 'Asia' ) ;	world_1
SELECT DISTINCT T2.Name FROM countrylanguage AS T1 INNER JOIN city AS T2 ON T1.CountryCode = T2.CountryCode INNER JOIN country AS T3 ON T2.CountryCode = T3.Code WHERE T3.Continent = 'Asia' AND T1.Language = 'Chinese' AND T1.IsOfficial = 'T';	world_1
SELECT name, IndepYear, SurfaceArea FROM country ORDER BY Population LIMIT 1;	world_1
SELECT name, IndepYear, SurfaceArea FROM country ORDER BY Population LIMIT 1;	world_1
SELECT Population, Name, HeadOfState FROM country ORDER BY SurfaceArea DESC LIMIT 1;	world_1
SELECT Name, Population, HeadOfState FROM country ORDER BY SurfaceArea DESC LIMIT 1;	world_1
SELECT T1.Name, count(*) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Percentage > 3 GROUP BY T1.Name ;	world_1
SELECT T1.Name, count(*) FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode GROUP BY T1.Name HAVING count(*) > 2;	world_1
SELECT count(*), district FROM city WHERE population > ( SELECT avg(population) FROM city ) GROUP BY district;	world_1
SELECT count(*), district FROM city GROUP BY district HAVING avg(population) < population;	world_1
SELECT Name, SUM(Population), GovernmentForm FROM country WHERE LifeExpectancy > 72 GROUP BY GovernmentForm;	world_1
SELECT T2.GovernmentForm, sum(T1.Population) FROM country AS T1 JOIN country AS T2 ON T1.Code = T2.Code WHERE T2.LifeExpectancy > 72 GROUP BY T2.GovernmentForm ;	world_1
SELECT avg(lifeexpectancy), sum(population) FROM country WHERE lifeexpectancy < 72;	world_1
SELECT Continent, SUM(Population), AVG(LifeExpectancy) FROM country WHERE LifeExpectancy < 72 GROUP BY Continent ;	world_1
SELECT Name, SurfaceArea FROM country ORDER BY SurfaceArea DESC LIMIT 5;	world_1
SELECT Name, SurfaceArea FROM country ORDER BY SurfaceArea DESC LIMIT 5;	world_1
SELECT Name FROM country ORDER BY Population DESC LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population DESC LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population LIMIT 3;	world_1
SELECT Name FROM country ORDER BY Population LIMIT 3;	world_1
SELECT count(*) FROM country WHERE continent = 'Asia';	world_1
SELECT count(*) FROM country WHERE continent = 'Asia';	world_1
SELECT Name FROM country WHERE Continent = 'Europe' AND Population = 80000;	world_1
SELECT Name FROM country WHERE Population = 80000 AND Continent = 'Europe';	world_1
SELECT SUM(Population), SUM(SurfaceArea) FROM country WHERE SurfaceArea > 3000 AND Continent = 'North America';	world_1
SELECT SUM(T2.Population), SUM(T2.SurfaceArea) / COUNT(T2.Code) FROM countrylanguage AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T2.Continent = 'North America' AND T2.SurfaceArea > 3000 ;	world_1
SELECT Name FROM city WHERE Population BETWEEN 160000 AND 900000;	world_1
SELECT Name FROM city WHERE Population BETWEEN 160000 AND 900000;	world_1
SELECT Language FROM countrylanguage GROUP BY Language ORDER BY COUNT(*) DESC LIMIT 1;	world_1
SELECT language FROM countrylanguage GROUP BY language ORDER BY count(*) DESC LIMIT 1;	world_1
SELECT T1.Language FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code ORDER BY T1.Percentage DESC LIMIT 1;	world_1
SELECT T1.Code, T2.Language FROM country AS T1 JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT COUNT(T1.Code) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Spanish' ORDER BY T2.Percentage DESC LIMIT 1;	world_1
SELECT COUNT(T1.Code) FROM country AS T1 INNER JOIN countrylanguage AS T2 ON T1.Code = T2.CountryCode WHERE T2.Language = 'Spanish';	world_1
SELECT T2.Code FROM countrylanguage AS T1 INNER JOIN country AS T2 ON T1.CountryCode = T2.Code ORDER BY T1.Percentage DESC LIMIT 1;	world_1
SELECT T2.Code FROM countrylanguage AS T1 JOIN country AS T2 ON T1.CountryCode = T2.Code WHERE T1.Language = 'Spanish';	world_1
SELECT count(*) FROM conductor;	orchestra
SELECT count(*) FROM conductor;	orchestra
SELECT Name FROM conductor ORDER BY Age;	orchestra
SELECT Name FROM conductor ORDER BY Age;	orchestra
SELECT Name FROM conductor WHERE Nationality!= 'USA';	orchestra
SELECT Name FROM conductor WHERE Nationality!= 'USA';	orchestra
SELECT Record_Company FROM orchestra ORDER BY Year_of_Founded DESC;	orchestra
SELECT Record_Company FROM orchestra ORDER BY Year_of_Founded DESC;	orchestra
SELECT avg(Attendance) FROM show;	orchestra
SELECT avg(Attendance) FROM show;	orchestra
SELECT max(share), min(share) FROM performance WHERE type!= 'Live final';	orchestra
SELECT max(Share), min(Share) FROM performance WHERE Type!= "Live final";	orchestra
SELECT count(DISTINCT nationality) FROM conductor;	orchestra
SELECT count(DISTINCT nationality) FROM conductor;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC LIMIT 1;	orchestra
SELECT Name FROM conductor ORDER BY Year_of_Work DESC LIMIT 1;	orchestra
SELECT T1.Name, T2.Orchestra FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID;	orchestra
SELECT T1.Name, T2.Orchestra FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID ;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Name HAVING count(*) > 1;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T1.Name HAVING count(*) > 1;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T2.Conductor_ID ORDER BY count(*) DESC LIMIT 1;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID GROUP BY T2.Conductor_ID ORDER BY count(*) DESC LIMIT 1;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID WHERE T2.Year_of_Founded > 2008 ;	orchestra
SELECT T1.Name FROM conductor AS T1 JOIN orchestra AS T2 ON T1.Conductor_ID = T2.Conductor_ID WHERE T2.Year_of_Founded > 2008 ;	orchestra
SELECT Record_Company, COUNT(*) FROM orchestra GROUP BY Record_Company;	orchestra
SELECT Record_Company, count(*) FROM orchestra GROUP BY Record_Company;	orchestra
SELECT Major_Record_Format FROM orchestra ORDER BY Major_Record_Format;	orchestra
SELECT Major_Record_Format FROM orchestra ORDER BY Major_Record_Format;	orchestra
SELECT Record_Company FROM orchestra GROUP BY Record_Company ORDER BY COUNT(*) DESC LIMIT 1;	orchestra
SELECT Record_Company FROM orchestra GROUP BY Record_Company ORDER BY count(*) DESC LIMIT 1;	orchestra
SELECT Orchestra FROM orchestra EXCEPT SELECT T1.Orchestra FROM orchestra AS T1 JOIN performance AS T2 ON T1.Orchestra_ID = T2.Orchestra_ID;	orchestra
SELECT Orchestra FROM orchestra EXCEPT SELECT T1.Orchestra FROM orchestra AS T1 JOIN performance AS T2 ON T1.Orchestra_ID = T2.Orchestra_ID ;	orchestra
SELECT Record_Company FROM orchestra WHERE Year_of_Founded < 2003 INTERSECT SELECT Record_Company FROM orchestra WHERE Year_of_Founded > 2003;	orchestra
SELECT Record_Company FROM orchestra WHERE Year_of_Founded < 2003 INTERSECT SELECT Record_Company FROM orchestra WHERE Year_of_Founded > 2003;	orchestra
SELECT count(*) FROM orchestra WHERE Major_Record_Format = 'CD' OR Major_Record_Format = 'DVD';	orchestra
SELECT count(*) FROM orchestra WHERE Major_Record_Format = 'CD' OR Major_Record_Format = 'DVD';	orchestra
SELECT YEAR_OF_Founded FROM orchestra GROUP BY YEAR_OF_Founded HAVING COUNT(*) > 1;	orchestra
SELECT T1.Year_of_Founded FROM orchestra AS T1 JOIN performance AS T2 ON T1.Orchestra_ID = T2.Orchestra_ID GROUP BY T1.Orchestra_ID HAVING COUNT(*) > 1;	orchestra
SELECT count(*) FROM Highschooler;	network_1
SELECT count(*) FROM Highschooler;	network_1
SELECT name, grade FROM Highschooler;	network_1
SELECT name, grade FROM Highschooler;	network_1
SELECT grade FROM Highschooler;	network_1
SELECT grade FROM Highschooler;	network_1
SELECT grade FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT grade FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT name FROM Highschooler WHERE grade = 10;	network_1
SELECT name FROM Highschooler WHERE grade = 10;	network_1
SELECT ID FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT id FROM Highschooler WHERE name = 'Kyle';	network_1
SELECT count(*) FROM Highschooler WHERE grade = 9 OR grade = 10;	network_1
SELECT count(*) FROM Highschooler WHERE grade = 9 OR grade = 10;	network_1
SELECT grade, COUNT(*) FROM Highschooler GROUP BY grade;	network_1
SELECT grade, COUNT(*) FROM Highschooler GROUP BY grade;	network_1
SELECT grade FROM Highschooler ORDER BY grade DESC LIMIT 1;	network_1
SELECT grade FROM Highschooler GROUP BY grade ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT grade FROM Highschooler GROUP BY grade HAVING count(*) >= 4;	network_1
SELECT grade FROM Highschooler GROUP BY grade HAVING count(*) >= 4;	network_1
SELECT student_id, count(*) FROM Friend GROUP BY student_id;	network_1
SELECT T1.student_id, count(*) FROM Friend AS T1 JOIN Highschooler AS T2 ON T1.student_id = T2.ID GROUP BY T1.student_id;	network_1
SELECT T1.name, count(*) FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT T1.name, count(*) FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id;	network_1
SELECT T1.name FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT T1.name FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT T1.name FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id GROUP BY T1.id HAVING count(*) >= 3;	network_1
SELECT T1.name FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id HAVING count(*) >= 3;	network_1
SELECT T2.name FROM Friend AS T1 JOIN Highschooler AS T2 ON T1.friend_id = T2.id WHERE T1.student_id = 1510;	network_1
SELECT T2.name FROM Friend AS T1 JOIN Highschooler AS T2 ON T1.friend_id = T2.id WHERE T1.student_id = ( SELECT id FROM Highschooler WHERE name = 'Kyle' );	network_1
SELECT count(*) FROM Friend AS T1 JOIN Highschooler AS T2 ON T1.student_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT count(*) FROM Friend WHERE student_id = ( SELECT id FROM Highschooler WHERE name = 'Kyle' );	network_1
SELECT id FROM Highschooler WHERE id NOT IN ( SELECT student_id FROM Friend );	network_1
SELECT id FROM Highschooler WHERE id NOT IN ( SELECT student_id FROM Friend );	network_1
SELECT name FROM Highschooler WHERE ID NOT IN ( SELECT student_id FROM Friend );	network_1
SELECT name FROM Highschooler WHERE id NOT IN ( SELECT student_id FROM Friend );	network_1
SELECT T1.id FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id JOIN Likes AS T3 ON T1.id = T3.liked_id;	network_1
SELECT student_id FROM Friend INTERSECT SELECT liked_id FROM Likes;	network_1
SELECT T1.name FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.id = T2.student_id JOIN Likes AS T3 ON T1.id = T3.student_id GROUP BY T1.name HAVING count(*) > 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id JOIN likes AS T3 ON T1.id = T3.student_id;	network_1
SELECT student_id, COUNT(*) FROM Likes GROUP BY student_id;	network_1
SELECT student_id, COUNT(*) FROM Likes GROUP BY student_id;	network_1
SELECT T2.name, count(*) FROM Likes AS T1 JOIN Highschooler AS T2 ON T1.student_id = T2.id GROUP BY T1.student_id;	network_1
SELECT T1.name, count(*) FROM Highschooler AS T1 JOIN Likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id ORDER BY count(*) DESC LIMIT 1;	network_1
SELECT T1.name FROM Highschooler AS T1 JOIN Likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id HAVING count(*) >= 2;	network_1
SELECT T1.name FROM Highschooler AS T1 JOIN Likes AS T2 ON T1.id = T2.student_id GROUP BY T2.student_id HAVING count(*) >= 2;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id WHERE T1.grade > 5 GROUP BY T1.name HAVING count(*) >= 2;	network_1
SELECT T1.name FROM highschooler AS T1 JOIN friend AS T2 ON T1.id = T2.student_id WHERE T1.grade > 5 GROUP BY T1.name HAVING count(*) >= 2;	network_1
SELECT COUNT(T2.liked_id) FROM Highschooler AS T1 JOIN Likes AS T2 ON T1.ID = T2.student_id WHERE T1.name = 'Kyle';	network_1
SELECT count(*) FROM likes AS T1 JOIN highschooler AS T2 ON T1.liked_id = T2.id WHERE T2.name = 'Kyle';	network_1
SELECT avg(T1.grade) FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.ID = T2.student_id;	network_1
SELECT avg(T1.grade) FROM Highschooler AS T1 JOIN Friend AS T2 ON T1.ID = T2.student_id;	network_1
SELECT min(grade) FROM Highschooler WHERE id NOT IN ( SELECT student_id FROM Friend );	network_1
SELECT min(grade) FROM Highschooler WHERE id NOT IN ( SELECT student_id FROM Friend );	network_1
SELECT state FROM owners WHERE state IN ( SELECT state FROM professionals ) ;	dog_kennels
SELECT state FROM owners WHERE state IN ( SELECT state FROM professionals ) ;	dog_kennels
SELECT avg(T1.age) FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT avg(T1.age) FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.professional_id, T1.last_name, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T1.state = 'Indiana' GROUP BY T1.professional_id HAVING count(*) > 2;	dog_kennels
SELECT T1.professional_id, T1.last_name, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T1.state = 'Indiana' GROUP BY T1.professional_id HAVING count(*) > 2;	dog_kennels
SELECT T2.name FROM Treatments AS T1 JOIN Dogs AS T2 ON T1.dog_id = T2.dog_id WHERE T1.cost_of_treatment > 1000;	dog_kennels
SELECT T1.name FROM dogs AS T1 JOIN treatments AS T2 ON T1.dog_id = T2.dog_id JOIN owners AS T3 ON T1.owner_id = T3.owner_id WHERE T2.cost_of_treatment < 1000 ;	dog_kennels
SELECT DISTINCT first_name FROM (Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id) EXCEPT SELECT first_name FROM Dogs ;	dog_kennels
SELECT first_name FROM Owners EXCEPT SELECT first_name FROM Dogs;	dog_kennels
SELECT T1.professional_id, T1.role_code, T1.email_address FROM Professionals AS T1 LEFT JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.professional_id IS NULL ;	dog_kennels
SELECT professional_id, role_code, email_address FROM Professionals EXCEPT SELECT T1.professional_id, T1.role_code, T1.email_address FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id ;	dog_kennels
SELECT T1.owner_id, T1.first_name, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id GROUP BY T1.owner_id ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.first_name, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id GROUP BY T1.owner_id ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.professional_id, T1.role_code, T1.first_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT T1.professional_id, T1.role_code, T1.first_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT T1.breed_name FROM Breeds AS T1 JOIN Dogs AS T2 ON T1.breed_code = T2.breed_code GROUP BY T1.breed_name ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.breed_name FROM Breeds AS T1 JOIN Dogs AS T2 ON T1.breed_code = T2.breed_code GROUP BY T1.breed_name ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Treatments AS T3 ON T2.dog_id = T3.dog_id GROUP BY T1.owner_id ORDER BY SUM(T3.cost_of_treatment) DESC LIMIT 1;	dog_kennels
SELECT T2.treatment_type_description FROM treatments AS T1 JOIN treatment_types AS T2 ON T1.treatment_type_code = T2.treatment_type_code ORDER BY T1.cost_of_treatment LIMIT 1;	dog_kennels
SELECT T1.treatment_type_description FROM Treatment_Types AS T1 JOIN Treatments AS T2 ON T1.treatment_type_code = T2.treatment_type_code ORDER BY T2.cost_of_treatment LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.zip_code FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Charges AS T3 ON T2.dog_id = T3.charge_id GROUP BY T1.owner_id ORDER BY SUM(T3.charge_amount) DESC LIMIT 1;	dog_kennels
SELECT T1.owner_id, T1.zip_code FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Charges AS T3 ON T2.dog_id = T3.charge_id GROUP BY T1.owner_id ORDER BY SUM(T3.charge_amount) DESC LIMIT 1;	dog_kennels
SELECT T1.professional_id, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT T1.professional_id, T1.cell_number FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id GROUP BY T1.professional_id HAVING count(*) >= 2;	dog_kennels
SELECT T1.first_name, T1.last_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.cost_of_treatment < ( SELECT avg(cost_of_treatment) FROM Treatments ) ;	dog_kennels
SELECT T1.first_name, T1.last_name FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id WHERE T2.cost_of_treatment < ( SELECT avg(cost_of_treatment) FROM Treatments ) ;	dog_kennels
SELECT T1.date_of_treatment, T2.first_name FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id;	dog_kennels
SELECT T1.date_of_treatment, T2.first_name FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id;	dog_kennels
SELECT T1.cost_of_treatment, T2.treatment_type_description FROM Treatments AS T1 JOIN Treatment_Types AS T2 ON T1.treatment_type_code = T2.treatment_type_code;	dog_kennels
SELECT T1.cost_of_treatment, T2.treatment_type_description FROM Treatments AS T1 JOIN Treatment_Types AS T2 ON T1.treatment_type_code = T2.treatment_type_code;	dog_kennels
SELECT T1.first_name, T1.last_name, T3.size_description FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Sizes AS T3 ON T2.size_code = T3.size_code;	dog_kennels
SELECT T1.first_name, T1.last_name, T3.size_description FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id JOIN Sizes AS T3 ON T2.size_code = T3.size_code;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id;	dog_kennels
SELECT T1.name, T3.date_of_treatment FROM dogs AS T1 JOIN breeds AS T2 ON T1.breed_code = T2.breed_code JOIN treatments AS T3 ON T1.dog_id = T3.dog_id GROUP BY T1.name ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.name, T3.date_of_treatment FROM dogs AS T1 JOIN breeds AS T2 ON T1.breed_code = T2.breed_code JOIN treatments AS T3 ON T1.dog_id = T3.dog_id GROUP BY T1.name ORDER BY count(*) DESC LIMIT 1;	dog_kennels
SELECT T1.first_name, T2.name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id WHERE T1.state = 'Virginia';	dog_kennels
SELECT T2.first_name, T1.name FROM Dogs AS T1 JOIN Owners AS T2 ON T1.owner_id = T2.owner_id WHERE T2.state = 'Virginia';	dog_kennels
SELECT T2.date_arrived, T2.date_departed FROM Treatments AS T1 JOIN Dogs AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.date_arrived, T1.date_departed FROM Dogs AS T1 JOIN Treatments AS T2 ON T1.dog_id = T2.dog_id;	dog_kennels
SELECT T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id ORDER BY T2.age LIMIT 1;	dog_kennels
SELECT T1.last_name FROM Owners AS T1 JOIN Dogs AS T2 ON T1.owner_id = T2.owner_id ORDER BY T2.age LIMIT 1;	dog_kennels
SELECT email_address FROM Professionals WHERE state = 'Hawaii' OR state = 'Wisconsin';	dog_kennels
SELECT email_address FROM Professionals WHERE state = 'Hawaii' OR state = 'Wisconsin';	dog_kennels
SELECT date_arrived, date_departed FROM Dogs;	dog_kennels
SELECT date_arrived, date_departed FROM Dogs;	dog_kennels
SELECT count(*) FROM Treatments;	dog_kennels
SELECT count(*) FROM Treatments;	dog_kennels
SELECT count(DISTINCT professional_id) FROM Treatments;	dog_kennels
SELECT count(DISTINCT professional_id) FROM Treatments;	dog_kennels
SELECT role_code, street, city, state FROM Professionals WHERE city LIKE '%West%';	dog_kennels
SELECT role_code, street, city, state FROM Professionals WHERE city LIKE '%West%';	dog_kennels
SELECT first_name, last_name, email_address FROM Owners WHERE state LIKE '%North%';	dog_kennels
SELECT first_name, last_name, email_address FROM Owners WHERE state LIKE '%North%';	dog_kennels
SELECT count(*) FROM Dogs WHERE age < ( SELECT avg(age) FROM Dogs );	dog_kennels
SELECT count(*) FROM Dogs WHERE age < ( SELECT avg(age) FROM Dogs );	dog_kennels
SELECT cost_of_treatment FROM Treatments ORDER BY date_of_treatment DESC LIMIT 1;	dog_kennels
SELECT cost_of_treatment FROM Treatments ORDER BY date_of_treatment DESC LIMIT 1;	dog_kennels
SELECT count(*) FROM Dogs WHERE dog_id NOT IN ( SELECT dog_id FROM Treatments );	dog_kennels
SELECT count(*) FROM dogs WHERE dog_id NOT IN ( SELECT dog_id FROM treatments );	dog_kennels
SELECT count(*) FROM Owners WHERE owner_id NOT IN ( SELECT owner_id FROM Dogs );	dog_kennels
SELECT count(*) FROM Owners WHERE owner_id NOT IN ( SELECT owner_id FROM Dogs );	dog_kennels
SELECT count(*) FROM Professionals WHERE professional_id NOT IN ( SELECT professional_id FROM treatments );	dog_kennels
SELECT count(*) FROM Professionals WHERE professional_id NOT IN ( SELECT professional_id FROM Treatments );	dog_kennels
SELECT name, age, weight FROM Dogs WHERE abandoned_yn = 1;	dog_kennels
SELECT name, age, weight FROM Dogs WHERE abandoned_yn = 1;	dog_kennels
SELECT avg(age) FROM Dogs;	dog_kennels
SELECT avg(age) FROM Dogs;	dog_kennels
SELECT max(age) FROM Dogs;	dog_kennels
SELECT max(age) FROM Dogs;	dog_kennels
SELECT charge_type, charge_amount FROM Charges;	dog_kennels
SELECT charge_type, charge_amount FROM Charges;	dog_kennels
SELECT max(charge_amount) FROM Charges;	dog_kennels
SELECT charge_amount FROM Charges ORDER BY charge_amount DESC LIMIT 1;	dog_kennels
SELECT email_address, cell_number, home_phone FROM Professionals;	dog_kennels
SELECT email_address, cell_number, home_phone FROM Professionals;	dog_kennels
SELECT T1.breed_name, T2.size_description FROM Breeds AS T1 JOIN Sizes AS T2 ON T1.breed_code = T2.size_code;	dog_kennels
SELECT DISTINCT breed_code, size_code FROM Dogs;	dog_kennels
SELECT T2.first_name, T3.treatment_type_description FROM Treatments AS T1 JOIN Professionals AS T2 ON T1.professional_id = T2.professional_id JOIN Treatment_Types AS T3 ON T1.treatment_type_code = T3.treatment_type_code;	dog_kennels
SELECT T1.first_name, T3.treatment_type_description FROM Professionals AS T1 JOIN Treatments AS T2 ON T1.professional_id = T2.professional_id JOIN Treatment_Types AS T3 ON T3.treatment_type_code = T2.treatment_type_code;	dog_kennels
SELECT count(*) FROM singer;	singer
SELECT count(*) FROM singer;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions ;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions ASC;	singer
SELECT Birth_Year, Citizenship FROM singer ;	singer
SELECT Birth_Year, Citizenship FROM singer ;	singer
SELECT name FROM singer WHERE citizenship!="France";	singer
SELECT Name FROM singer WHERE Citizenship!= 'France';	singer
SELECT Name FROM singer WHERE Birth_Year = 1948 OR Birth_Year = 1949;	singer
SELECT Name FROM singer WHERE Birth_Year = 1948 OR Birth_Year = 1949;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions DESC LIMIT 1;	singer
SELECT Name FROM singer ORDER BY Net_Worth_Millions DESC LIMIT 1;	singer
SELECT citizenship, COUNT(*) FROM singer GROUP BY citizenship ;	singer
SELECT Citizenship, COUNT(*) FROM singer GROUP BY Citizenship;	singer
SELECT citizenship FROM singer GROUP BY citizenship ORDER BY count(*) DESC LIMIT 1;	singer
SELECT citizenship FROM singer GROUP BY citizenship ORDER BY count(*) DESC LIMIT 1;	singer
SELECT citizenship, MAX(Net_Worth_Millions) FROM singer GROUP BY citizenship ;	singer
SELECT citizenship, max(net_worth_millions) FROM singer GROUP BY citizenship;	singer
SELECT T1.Title, T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID;	singer
SELECT T1.Title, T2.Name FROM song AS T1 JOIN singer AS T2 ON T1.Singer_ID = T2.Singer_ID;	singer
SELECT DISTINCT T1.Name FROM singer AS T1 INNER JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID WHERE T2.Sales > 300000;	singer
SELECT DISTINCT T1.Name FROM singer AS T1 INNER JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID WHERE T2.Sales > 300000;	singer
SELECT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name HAVING COUNT(*) > 1;	singer
SELECT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name HAVING COUNT(*) > 1;	singer
SELECT T1.Name, sum(T2.Sales) FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name;	singer
SELECT T1.Name, SUM(T2.Sales) FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID GROUP BY T1.Name;	singer
SELECT Name FROM singer EXCEPT SELECT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID ;	singer
SELECT Name FROM singer EXCEPT SELECT T1.Name FROM singer AS T1 JOIN song AS T2 ON T1.Singer_ID = T2.Singer_ID ;	singer
SELECT Citizenship FROM singer WHERE Birth_Year < 1945 INTERSECT SELECT Citizenship FROM singer WHERE Birth_Year > 1955;	singer
SELECT citizenship FROM singer WHERE Birth_Year < 1945 INTERSECT SELECT citizenship FROM singer WHERE Birth_Year > 1955 ;	singer
SELECT count(*) FROM Other_Available_Features;	real_estate_properties
SELECT T1.feature_type_name FROM Ref_Feature_Types AS T1 INNER JOIN Other_Available_Features AS T2 ON T1.feature_type_code = T2.feature_type_code WHERE T2.feature_name = 'AirCon';	real_estate_properties
SELECT T2.property_type_description FROM Properties AS T1 JOIN Ref_Property_Types AS T2 ON T1.property_type_code = T2.property_type_code;	real_estate_properties
SELECT property_name FROM Properties WHERE property_type_code = 'House' OR property_type_code = 'Apartment' AND room_count > 1;	real_estate_properties
